<?php
/**
 * Created by PhpStorm.
 * User: Asier
 * Date: 30/07/14
 * Time: 21:51
 */

get_header();

?>
<section id="page">

    <div class="container">

        <div class="row">
            <div class="col-xs-12">
                <ol class="breadcrumb" style="margin-top: 20px">
                    <li><a href="<?php echo _u()->getUrl() ?>"><?php _e("Inicio", "ubiqa") ?></a></li>
                    <li><?php _e("Nuevo contenido", "ubiqa") ?></li>
                    <li class="active"><?php _e("Inicio de sesión", "ubiqa") ?></li>
                </ol>
            </div>
        </div>

        <div class="row">

            <div class="col-sm-6">

                <div class="panel">
                    <form class="panel-body" method="post" action="">

                        <?php if($error = _u()->get("error")){ ?>
                        <div class="alert alert-danger">
                            <p>
                                <?php echo $error ?>
                            </p>
                        </div>
                        <?php } ?>

                        <div class="row">
                            <div class="col-xs-12">
                                <?php if($message = _u()->getUserModel()->getFlash("notice")){ ?>
                                    <div class="alert alert-success"><?php echo $message ?></div>
                                <?php } ?>
                            </div>
                        </div>

                        <div class="row form-group">

                            <div class="col-xs-12">
                                <input name="username" type="text" class="form-control" placeholder="<?php _e("Email o nombre de usuario", "ubiqa") ?>">
                            </div>

                        </div>
                        <div class="row form-group">

                            <div class="col-xs-6">
                                <input name="password" type="password" class="form-control col-sm-4" placeholder="<?php _e("Clave de usuario", "ubiqa") ?>">
                            </div>
                        </div>
                        <div class="row form-group">

                            <div class="col-xs-6">
                                <button type="submit" class="btn btn-primary"><?php _e("Iniciar sesión", "ubiqa") ?></button>
                            </div>

                        </div>
<?php if(_requisites()){ ?>
                        <hr>

                        <div class="row">

                            <div class="col-xs-12">

                                <h5><?php _e("También puedes acceder con", "ubiqa") ?></h5>

                                <div class="btn-group">

                                    <a class="btn btn-default"  href="<?php echo _u()->genUrl("social_redirect", array("service"=>"facebook")) ?>"><?php _e("Facebook", "ubiqa") ?></a>
                                    <a class="btn btn-default"  href="<?php echo _u()->genUrl("social_redirect", array("service"=>"twitter")) ?>"><?php _e("Twitter", "ubiqa") ?></a>
                                    <a class="btn btn-default" href="<?php echo _u()->genUrl("social_redirect", array("service"=>"google")) ?>"><?php _e("Google", "ubiqa") ?></a>


                                </div>

                            </div>

                        </div>
<?php } ?>

                    </form>

                </div>

            </div>

        </div>

    </div>
</section>

<?php
get_footer();