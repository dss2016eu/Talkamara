<?php
/**
 * Created by PhpStorm.
 * User: asierm
 * Date: 3/10/15
 * Time: 20:16
 */

namespace Ubiqa\Controller;


use Sense\AbstractController;
use Symfony\Component\HttpFoundation\Request;

class BlogController extends AbstractController {

    function ajaxItemsAction(Request $request){

        $query = new \WP_Query(array("paged"=>$request->get("_page",1), "post_type"=>"post", "status"=>"publish"));
        $posts = $query->get_posts();



        return $this->resultTemplate("Blog/items.php", array("items"=> $posts));


    }

} 