<?php
/**
 * Created by PhpStorm.
 * User: Asier
 * Date: 26/07/14
 * Time: 17:56
 */

namespace Ubiqa\Metabox;


use Sense\AbstractMetabox;
use Sense\Sense;
use Ubiqa\Model\AgendaModel;

class CityMetabox extends AbstractMetabox {



    function setUp(){

        if(is_admin()){
            $sense = $this->getContainer();

            $sense["sense.admin_assets"]->addScript("leaflet", "http://cdn.leafletjs.com/leaflet-0.7.3/leaflet.js","1",true, array("jquery"));
            $sense["sense.admin_assets"]->addScript("city", get_template_directory_uri() . "/js/city.js","1",true, array("jquery", "leaflet"));
            $sense["sense.admin_assets"]->addStyle("leaflet", "http://cdn.leafletjs.com/leaflet-0.7.3/leaflet.css", "1");
        }

        \add_meta_box('ubiqa_city_metabox', __( 'Datos de la ciudad', 'ubiqa' ), array($this, "HTML"), 'city', 'normal', 'high' );
    }

    function HTML($post){
        include __DIR__ . "/../View/metabox/city_data.php";
    }



    function save($post_id){


        // If this is an autosave, our form has not been submitted, so we don't want to do anything.
        if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
            return;
        }


        if(isset($_POST["ubiqa_content"]) && is_array($_POST["ubiqa_content"])){



            foreach($_POST["ubiqa_content"] as $key=>$value){
                if(isset($_POST["ubiqa_content"][$key]) && $_POST["ubiqa_content"][$key]){
                    $this->getModel()->setMeta($post_id, "ubiqa_content_" . $key, $_POST["ubiqa_content"][$key]);
                }else{
                    $this->getModel()->removeMeta($post_id, "ubiqa_content_" . $key, $_POST["ubiqa_content"][$key]);
                }
            }




        }




    }



}