<?php
/**
 * Created by PhpStorm.
 * User: asierm
 * Date: 05/09/14
 * Time: 11:46
 */

namespace Ubiqa;


use Sense\AssetManager;
use Sense\Sense;
use Sense\Util;
use Symfony\Component\HttpFoundation\Request;
use Ubiqa\Form\AdminConfigForm;
use Ubiqa\Form\AdminCustomForm;
use Ubiqa\Model\AdminModel;

class Admin {


    /**
     * @var \Sense\Sense
     */
    private $container;

    function __construct(Sense $container){

        $this->container = $container;

        add_action( 'admin_menu', array($this, "setMenus") );
    }




    function configAction(){


        /**
         * @var $request Request
         */
        $request = $this->container["request"];
        /**
         * @var $util Util
         */
        $util    = $this->container["util"];

        /**
         * @var $model AdminModel
         */
        $model   = $this->container["model.admin"];



        $data    = $model->getConfigOptions();

        $form = new AdminConfigForm($data, $this->container["sense.form.builder"]);

        if($request->getMethod() == "POST"){

            $form->bind($request->get("config"));
            if($form->isValid()){
                update_option("ubiqa_config_options", $form->getValues());
            }


        }


        include __DIR__ . "/View/admin/configuration.php";

    }

    function customizeAction(){
        /**
         * @var $request Request
         */
        $request = $this->container["request"];
        /**
         * @var $util Util
         */
        $util    = $this->container["util"];

        wp_enqueue_media();


        /**
         * @var $model AdminModel
         */
        $model   = $this->container["model.admin"];

        $data    = get_option("ubiqa_custom_options", array());

        $form = new AdminCustomForm($data, $this->container["sense.form.builder"]);

        if($request->getMethod() == "POST"){

            $form->bind($request->get("custom"));
            if($form->isValid()){
                update_option("ubiqa_custom_options", $form->getValues());
            }


        }


        include __DIR__ . "/View/admin/customize.php";

    }


    function setMenus(){


        $container = $this->container;

        add_menu_page( 'ubiqa.config', 'Ubiqarama', 'manage_options', 'ubiqarama/config', array($this, "configAction"), '', 1 );

        add_submenu_page( 'ubiqarama/config', __("Personalizar diseño", "ubiqa"), __("Personalizar diseño", "ubiqa"), 'manage_options', 'ubiqarama/custom', array($this, "customizeAction"));

    }







} 