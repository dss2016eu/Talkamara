<?php setup_postdata( $post ); ?>
<?php

$user    = _u()->get("sense.model.user")->getUser();
$user_id = $user?$user->ID:time();
$likes = (string)(int) _u()->get("content")->getMeta(get_the_ID(), "ubiqa_likes");
$is_like = $user ? _u()->get("content")->isLike(get_the_ID(), $user) : null;

$is_favorite = false;
if($user){
    $is_favorite = _u()->get("content")->isFavorite(get_the_ID(), $user);
}

//$fav = (int) _u()->get("content")->getMeta(get_the_ID(), "ubiqa_favs");
/*
 * <div class="pos-center txt-center">
                    <a href="<?php echo get_permalink($post) ?>" class="btn-rounded"><?php _e("Leer más", "ubiqa") ?></a>
                </div>
 * */
?>
<div class="col-s-12 col-m-6 col-l-3 " >
    <div class="card">
        <div data-rel="<?php the_ID() ?>"
             id="card_image_<?php the_ID() ?>"
             class="card-image <?php if(_u()->isPendingVimeoThumb(get_the_ID())) echo 'vpending'  ?>">
            <?php

            if($thumb = get_the_post_thumbnail(get_the_ID(),"ubiqa_content_tall_thumb", array("data-aspect-ratio"=>"1"))){
                echo $thumb;
            }else{ ?>
                <img src="<?php echo _u()->getDefaultImageSrc(get_the_ID()) ?>" data-aspect-ratio="1">
            <?php }

            ?>
            <div class="image-overlay">

                <div class="pos-tl card-icon card-icon-<?php echo _u()->getIconClass(get_the_ID()) ?>">
                    <i class="fa"></i>
                </div>



                <?php if($user){ ?>
                    <div
                        data-url-rel="<?php echo _u()->genUrl("fav_content", array("content_id" => get_the_ID()))?>"
                        data-rel="<?php echo get_the_ID() ?>"
                        class="pos-tr fav-item fa <?php echo($is_favorite ? "fa-star" : "fa-star-o") ?>"></div>
                <?php } ?>

                <div class="pos-bl fa like-item <?php echo($is_like ? "fa-heart" : "fa-heart-o") ?>"
                     data-url-rel="<?php echo _u()->genUrl("like_content", array( "content_id" => get_the_ID(), "user_id"    => $user_id))?>"
                     data-rel="<?php echo get_the_ID() ?>">
                     <b class="like-count"><?php echo $likes ?></b>
                </div>
                <div class="pos-br fa fa-comment-o"> <b><?php comments_number( '0', '1', '%' ); ?></b></div>
            </div>
        </div>
        <div class="card-info">
            <a href="<?php echo get_permalink($post) ?>"><?php the_title() ?></a>

        </div>
    </div>

</div>
