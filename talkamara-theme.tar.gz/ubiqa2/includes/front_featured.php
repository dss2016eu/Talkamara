<?php
$_posts = _u()->get("content")->getFeaturedPosts();
if($total = count($_posts)){
?>

<div class="masonry grid featured cards">

    <?php foreach($_posts as $i=>$_post){ \setup_postdata($GLOBALS['post'] = $_post);


        $user    = _u()->get("sense.model.user")->getUser();
        $user_id = $user?$user->ID:time();
        $likes = (string)(int) _u()->get("content")->getMeta(get_the_ID(), "ubiqa_likes");
        $is_like = $user ? _u()->get("content")->isLike(get_the_ID(), $user) : null;

        $is_favorite = false;
        if($user){
            $is_favorite = _u()->get("content")->isFavorite(get_the_ID(), $user);
        }



        ?>
    <div class="col-m-12 col-l-6 masonry-item">
        <div class="card">
            <div class="card-image lazy-img featured-card-block" style="background-position:center;background-image: url('<?php echo _u()->getThumbUrl(get_the_ID(), "ubiqa_featured") ?>')">


                <div class="image-overlay">
                    <div class="pos-tl">
                        <div class="card-icon card-icon-<?php echo _u()->getIconClass(get_the_ID()) ?>">
                            <i class="fa"></i>
                        </div>
                        <h3><?php the_title()?></h3>
                        <p class="txt-italic txt-big"><?php the_excerpt() ?></p>
                    </div>
                    <div class="pos-bl  featured-button">
                        <a href="<?php the_permalink() ?>" class="btn-rounded"><i class="fa fa-eye"></i><span><?php _e("Leer más", "ubiqa") ?></span></a>
                    </div>
                    <div class="pos-br">

                        <i
                            data-url-rel="<?php echo _u()->genUrl("like_content", array( "content_id" => get_the_ID(), "user_id"    => $user_id))?>"
                            data-rel="<?php echo get_the_ID() ?>"
                            class="fa like-item <?php echo($is_like ? "fa-heart" : "fa-heart-o") ?>  txt-big"></i> <b class="txt-big like-count"><?php echo $likes ?></b>&nbsp;
                        <i class="fa fa-comment-o txt-big"></i> <b class="txt-big"><?php comments_number( '0', '1', '%' ); ?></b>

                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php } ?>

</div>

<?php } ?>