<div id="new-content-steps">
    <div class="txt-center">
        <div class="step <?php echo $step == 1 ? "active":"" ?>">1</div>
        <span><?php _e("DATOS", "ubiqa") ?></span>
    </div>
    <div class="txt-center">
        <div class="step  <?php echo $step == 2 ? "active":"" ?>">2</div>
        <span><?php _e("LOCALIZACION", "ubiqa") ?></span>
    </div>
    <div class="txt-center">
        <div class="step  <?php echo $step == 3 ? "active":"" ?>">3</div>
        <span><?php _e("TEMAS", "ubiqa") ?></span>
    </div>
</div>