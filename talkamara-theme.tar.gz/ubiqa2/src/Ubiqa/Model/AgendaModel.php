<?php
/**
 * Created by PhpStorm.
 * User: Asier
 * Date: 26/07/14
 * Time: 17:57
 */

namespace Ubiqa\Model;


use Sense\Model\AbstractModel;
use Symfony\Component\Validator\Constraints\DateTime;

class AgendaModel extends AbstractModel {


    function agendaEventsQB(\DateTime $date_from){
        return $this->createQueryBuilder("agenda")
                      ->whereMeta("ubiqa_event_data_datetime", $date_from->format('Y-m-d H:i:s'),">=","datetime")
                      ->orderBy("ubiqa_event_data_datetime", "DESC");
    }


    function ajaxEvents(\DateTime $start,\DateTime  $end){
        $query = new \WP_Query(array(
            'post_type' => 'agenda',
            'meta_query' => array(
                array(
                    'key' => 'ubiqa_event_data_datetime',
                    'value' => $start->format("Y-m-d H:i:s"),
                    'compare' => '>=',
                    'type' => 'datetime'
                ),
                array(
                    'key' => 'ubiqa_event_data_datetime',
                    'value' => $end->format("Y-m-d H:i:s"),
                    'compare' => '<=',
                    'type' => 'datetime'
                )
            )
        ));

        $items = array();
        while($query->have_posts()){
            $query->the_post();

            $start = \DateTime::createFromFormat('Y-m-d H:i:s', get_post_meta($query->post->ID, "ubiqa_event_data_datetime", true));
            //$end   = clone $start;
            //$end->modify("+2hours");
            $items[] = array(
                'id'    => $query->post->ID,
                'title' => \get_the_title($query->post->ID),
                'start' => $start->format(\DateTime::ISO8601),
                //'end'   => $end->getTimestamp(),
                'url'   => \get_permalink($query->post->ID),
                'allDay' => false,
                'color' => '#efefef'
            );

        }

        return $items;

    }


} 