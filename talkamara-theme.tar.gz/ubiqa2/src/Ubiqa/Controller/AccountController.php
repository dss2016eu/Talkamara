<?php
/**
 * Created by PhpStorm.
 * User: Asier
 * Date: 30/07/14
 * Time: 20:44
 */

namespace Ubiqa\Controller;


use Sense\AbstractController;
use Sense\Model\UserModel;
use SimpleForm\Config;
use SimpleForm\FormBuilder;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Validator\Constraints\Email;
use Symfony\Component\Validator\Validation;
use Ubiqa\Form\AccountForm;
use Ubiqa\Form\RegisterForm;
use Ubiqa\Theme;

class AccountController extends AbstractController {


    function indexAction(Request $request, \WP_Query $query){

        $model = $this->get("sense.model.user");
        $user  = $model->getUser();


        if(!$user instanceof \WP_User) return $this->resultRedirect($this->generateUrl("login"));



        $user_data = $model->toArray($user);
        $user_data["language"] = get_user_meta($user->ID, "ubiqa_lang", true);


        $this->addScript("account", get_template_directory_uri() . "/js/account.js", 1);



        $form = new AccountForm($user_data, $this->get("sense.form.builder"), Theme::getInstance()->getLanguages(true));
//        $form->offsetGet("last_name")->bind("aa", Validation::createValidator());
//
//        die($form["last_name"]->getErrorTag());

        if($request->getMethod()=="POST"){

            $form->bind($request->get("profile"));

            if($form->isValid()){

                if($model->updateUser($user, $form->getValues())){


                    $file = $form->getFile("photo");


                   update_user_meta($user->ID, "ubiqa_lang", $form->getValue("language"));

                    if(isset($file["name"])&&$file["name"]){



                        $model->uploadUserAvatarToMediaLibrary($user, $form->getFile("photo"));

                    }

                    $model->setFlash("notice", __("Datos actualizados correctamente", "ubiqa"));
                    return $this->resultRedirect($request->headers->get("referer"));
                }

            }

        }


        return $this->resultTemplate("Account/index.php", array("model" => $model, "form"=>$form));

    }

    function registerAction(Request $request, \WP_Query $query){

        /**
         * @var $model UserModel
         */
        $model = $this->get("sense.model.user");



        $form = new RegisterForm(array(), $this->get("sense.form.builder"));
        $form->setModel($model);
//        $form->offsetGet("last_name")->bind("aa", Validation::createValidator());
//
//        die($form["last_name"]->getErrorTag());

        if($request->getMethod()=="POST"){

            $form->bind($request->get("register"));

            if($form->isValid()){

                if($user = $model->createAndRegister($form->getValue("login"), $form->getValue("password"), $form->getValue("user_email"))){





                    $model->updateUser($user,
                        array("first_name"=> $form->getValue("first_name"), "last_name"=> $form->getValue("last_name")));

                    $model->setFlash("notice", __("Te has registrado correctamente", "ubiqa"));
                    return $this->resultRedirect($this->generateUrl("login"));
                }

            }

        }


        return $this->resultTemplate("Account/register.php", array("model" => $model, "form"=>$form));

    }

    function passwordAction(Request $request, \WP_Query $query){

        $model = $this->getModel();
        $user  = $model->getUser();
        if(!$user instanceof \WP_User) return $this->resultRedirect($this->generateUrl("login"));

        $error = false;

        if($request->getMethod()=="POST"){

            if($request->get("password") == $request->get("password_repeat")){
                $model->changePassword($request->get("password"), $user);
                $model->setFlash("notice", __("Datos actualizados correctamente", "ubiqa"));
                return $this->resultRedirect($request->headers->get("referer"));
            }else{
                $error = __("Las contraseñas no coinciden", "ubiqa");
            }


        }


        return $this->resultTemplate("Account/password.php", array("model" => $model, "form"=>$error));

    }

    function loginAction(Request $request, \WP_Query $query){


        $error = false;

        if($request->getMethod() == "POST"){



            if($this->getModel()->authenticate($request->get("username"), $request->get("password"))){

                return $this->resultRedirect("/");

            }else{
                $error = __("datos no válidos", "ubiqa");
            }

        }

        return $this->resultTemplate("Account/login.php", array("error"=> $error));

    }

    function resetPasswordAction(Request $request, \WP_Query $query){


        $error = false;




        if($request->getMethod() == "POST"){



            if(($user = $this->getModel()->getUserBy("login",$request->get("username"))) ||
                ($user = $this->getModel()->getUserBy("email",$request->get("username")))){


                $this->getModel()->sendRetrievePasswordLink($this->generateUrl("resetPassword"), $request->get("username"), $user);


                \wp_password_change_notification($user);


            }
            $this->getModel()->setFlash("notice", __("Te hemos enviado un email con las instrucciones para cambiar tu contraseña", "ubiqa"));
            return $this->resultRedirect($request->headers->get("referer"));

        }else{

            if($request->get("key") && $request->get("login")){

                if($user = $this->getModel()->getUserBy("login",$request->get("login"))){
                    global $wp_hasher;
                    if ( empty( $wp_hasher ) ) {
                        require_once ABSPATH . 'wp-includes/class-phpass.php';
                        $wp_hasher = new \PasswordHash( 8, true );
                    }


                    if($wp_hasher->checkPassword( $request->get("key"), $user->user_activation_key )){

                        $this->getModel()->forceAuthenticate($user);

                        $this->getModel()->setFlash("notice", __("Puedes cambiar tu contraseña desde aquí", "ubiqa"));
                        return $this->resultRedirect($this->generateUrl("password"));

                    }


                }



            }

        }

        return $this->resultTemplate("Account/resetPassword.php", array("error"=> $error));

    }

    /**
     * @return UserModel
     */
    private function getModel(){
       return $this->get("sense.model.user");;
    }

} 