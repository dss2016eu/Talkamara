jQuery(document).ready(function(){

    $('#profile_photo_selector > i').on('click', function(){
        $('#profile_photo').trigger('click');
    });
    $('#profile_photo').on('change', function(evt){
        var tgt = evt.target || window.event.srcElement,
            files = tgt.files;

        // FileReader support
        if (FileReader && files && files.length) {
            var fr = new FileReader();
            fr.onload = function () {
                document.getElementById('profile_img').src = fr.result;
            };
            fr.readAsDataURL(files[0]);
        }
    });


});