<?php
/**
 * Created by PhpStorm.
 * User: Asier
 * Date: 26/07/14
 * Time: 18:53
 */

namespace Ubiqa\Controller;


use Sense\AbstractController;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Ubiqa\Form\ContentGeoForm;
use Ubiqa\Form\ContentInfoForm;
use Ubiqa\Form\ContentTopicForm;
use Ubiqa\Form\FilterForm;
use Ubiqa\HTTPAuthenticator;
use Ubiqa\Model\AdminModel;
use Ubiqa\Model\AgendaModel;
use Ubiqa\Model\ContentModel;

class ContentController extends AbstractController {



    function ajaxProjectsAction(Request $request){


        $args = array("paged"=>$request->get("_page",1), "post_type"=>"subproject", "status"=>"publish");
        switch($request->get("_order", "date")){

            case 'views':

                $args["meta_key"] = "ubiqa_visit";
                $args["orderby"]  = array("meta_value_num"=>"DESC", "ID"=>"DESC");
                break;

            default:
                $args["orderby"] = "ID";
                $args["order"] = "DESC";


        }


        $query = new \WP_Query($args);

        if($request->get("count")){
            return  $this->resultResponse(new JsonResponse($query->max_num_pages));
        }
        $posts = $query->get_posts();



        return $this->resultTemplate("Content/ajaxProjects.php", array("items"=> $posts));


    }

    function ajaxTopicIdsAction(Request $request){

        $terms = array();
        foreach(get_terms("topic", array("hide_empty"=>true)) as $term){
            $terms[$term->term_id] = \qtrans_use(\qtrans_getLanguage(), $term->name, true);
        }

        $categories = array();
        foreach(get_terms("ubiqa_category", array("hide_empty"=>false)) as $term){
            $categories[$term->term_id] = \qtrans_use(\qtrans_getLanguage(), $term->name, true);
        }
        $cities = array();
        foreach(get_posts(array("post_type"=>"city", "posts_per_page"=>-1)) as $city){
            $cities[$city->ID] = get_the_title($city);
        }


        $form = new FilterForm($this->get("request")->get("filter", array()), $this->get("sense.form.builder"), $this->get("model.content"), $terms, $cities, $categories);

        $result = $this->get("model.content")->getTopicIds($form->getValues());



        return $this->resultResponse(new JsonResponse($result));


    }

    function ajaxRoutesAction(Request $request){


        $args = array("paged"=>$request->get("_page",1), "post_type"=>"route", "status"=>"publish");


        switch($request->get("_order", "date")){

            case 'views':

                $args["meta_key"] = "ubiqa_visit";
                $args["orderby"]  = array("meta_value_num"=>"DESC", "ID"=>"DESC");
                break;

            default:
                $args["orderby"] = "ID";
                $args["order"] = "DESC";


        }


        $query = new \WP_Query($args);

        if($request->get("count")){
            return  $this->resultResponse(new JsonResponse($query->max_num_pages));
        }

        $posts = $query->get_posts();



        return $this->resultTemplate("Content/ajaxRoutes.php", array("items"=> $posts));


    }

    function ajaxContentItemsAction(Request $request){


        $terms = array();
        foreach(get_terms("topic", array("hide_empty"=>true)) as $term){
            $terms[$term->term_id] = \qtrans_use(\qtrans_getLanguage(), $term->name, true);
        }

        $categories = array();
        foreach(get_terms("ubiqa_category", array("hide_empty"=>false)) as $term){
            $categories[$term->term_id] = \qtrans_use(\qtrans_getLanguage(), $term->name, true);
        }
        $cities = array();
        foreach(get_posts(array("post_type"=>"city", "posts_per_page"=>-1)) as $city){
            $cities[$city->ID] = get_the_title($city);
        }


        $form = new FilterForm($this->get("request")->get("filter", array()), $this->get("sense.form.builder"), $this->get("model.content"), $terms, $cities, $categories);

        $vars = $this->get("model.content")->getFilterQueryVars($form->getValues());
        $vars["paged"] = $request->get("_page", 1);
        if($request->get("map_json")){
            $vars["posts_per_page"] = -1;
            $vars["fields"] = "ids";
            unset($vars["orderby"]);
            unset($vars["order"]);
        }




        $query = new \WP_Query($vars);
        if($request->get("count")){
            return  $this->resultResponse(new JsonResponse($query->max_num_pages, 200, array("content-type"=>"application/json")));
        }
        $posts = $query->get_posts();


        if($request->get("map_json")){


            $result = array();
            foreach($posts as $post_id){
                $result[] = array(
                    'lat' => (float) _u()->get("content")->getMeta($post_id, "ubiqa_content_lat"),
                    'lon' => (float) _u()->get("content")->getMeta($post_id, "ubiqa_content_lon"),
                    'type' => _u()->get("content")->getMeta($post_id, "ubiqa_content_type"),
                    'id'  => $post_id
                );
            }

            return $this->resultResponse(new JsonResponse($result));
        }



        return $this->resultTemplate("Content/ajaxItems.php", array("items"=> $posts, "for_home" => $request->get("is_home") ));


    }

    function ajaxSearchAction(Request $request){


        $vars = array("s"=>$request->get("q"));
        $vars["paged"] = $request->get("_page", 1);


        $query = new \WP_Query($vars);
        if($request->get("count")){
            return  $this->resultResponse(new JsonResponse($query->max_num_pages, 200, array("content-type"=>"application/json")));
        }
        $posts = $query->get_posts();


        return $this->resultTemplate("Content/ajaxSearch.php", array("items"=> $posts, "for_home" => $request->get("is_home") ));


    }

    function ajaxAuthorItemsAction(Request $request){


        $vars = array("author"=>$request->get("user_id"), "post_type"=>"content");
        $vars["paged"] = $request->get("_page", 1);



        $query = new \WP_Query($vars);
        if($request->get("count")){
            return  $this->resultResponse(new JsonResponse($query->max_num_pages, 200, array("content-type"=>"application/json")));
        }
        $posts = $query->get_posts();


        return $this->resultTemplate("Content/ajaxItems.php", array("items"=> $posts, "for_home" => $request->get("is_home") ));


    }

    function ajaxAuthorFavItemsAction(Request $request){




        $user_favs_qb = $this->get("model.content")->getUserFavsQB($request->get("user_id"), $request->get("_page", 1));

        $query = new \WP_Query($user_favs_qb->getWPQueryVars());
        if($request->get("count")){
            return  $this->resultResponse(new JsonResponse($query->max_num_pages, 200, array("content-type"=>"application/json")));
        }
        $posts = $query->get_posts();


        return $this->resultTemplate("Content/ajaxItems.php", array("items"=> $posts, "for_home" => $request->get("is_home") ));


    }

    function mapPreviewAction(Request $request){
        if($id = $request->get("id")){


            $model = $this->getModel();

/*
            $item = $model->toArray(get_post($id));
            $item["related"] = array();*/
            $post = get_post($id);

            if($post instanceof \WP_Post){
                $related = $model->getRelatedArray($model->getMeta($post->ID, "ubiqa_content_lat"), $model->getMeta($post->ID, "ubiqa_content_lon"), $post->ID);



                return $this->resultTemplate("Content/previewContent.php", array("item"=> $post, "related"=>$related));

            }



        }


        return $this->resultResponse(new Response("", 404));

    }

    function ajaxGetSingleContent(Request $request){

        if($id = $request->get("id")){


            /*$model = $this->getModel();


            $item = $model->toArray(get_post($id));
            $item["related"] = array();*/


            if($post = get_post($id)){
               /* $related = $model->getRelatedArray($model->getMeta($item["id"], "ubiqa_content_lat"), $model->getMeta($item["id"], "ubiqa_content_lon"));
                foreach($related as $post){

                    if($post->ID == $item["id"]) continue;

                    $project = get_post($model->getMeta($post->ID, "ubiqa_content_subproject"));


                    $item["related"][] = array(
                        'id' => $post->ID,
                        'title' => get_the_title($post),
                        'url' => get_permalink($post),
                        'project' => get_the_title($project)
                    );
                }*/
            }

            return $this->resultTemplate("Content/previewContent.php", array("item"=> $post));

        }else{
            return $this->resultResponse(new Response("", 404));
        }




    }

    function ajaxEmbedPreviewAction(Request $request){
        if($url = $request->get("url")){


            $data="";
            $url = urldecode($url);

            if(filter_var($url, FILTER_VALIDATE_URL)){
                $data = wp_oembed_get($url);
            }


            $response = new Response((string)$data);

        }else{
            $response = new Response("No valid", 410);
        }

        $response->send();
        die();
    }


    function newLoginAction(Request $request, \WP_Query $query){

        $error="";
        if(!$user = $this->get("sense.model.user")->getUser()){

            if($request->getMethod() == "POST"){
                if($this->get("sense.model.user")->authenticate($request->get("username"), $request->get("password"))){

                    return $this->resultRedirect($this->generateUrl("add_content_info"));

                }else{
                    $error = __("datos no válidos", "ubiqa");
                }

            }

        }else{
            return $this->resultRedirect($this->generateUrl("add_content_info"));
        }

        $_SESSION["oauth_redirect_to"] = $this->generateUrl("add_content_info");



        return $this->resultTemplate("Content/newLogin.php", array(
            'error' => $error
        ));

    }

    function newInfoAction(Request $request, \WP_Query $query){

        $this->addScript("content", get_template_directory_uri() . "/js/content.js","1",array("jquery"));

        if(isset($_SESSION["oauth_redirect_to"])) unset($_SESSION["oauth_redirect_to"]);


        $user = $this->get("sense.model.user")->getUser();

        $projects = array();
        foreach($this->get("model.project")->getList() as $project){
            $projects[$project->ID] = \get_the_title($project);
        }
        $form = new ContentInfoForm(array(), $this->get("sense.form.builder"), $projects);








        if($request->getMethod() == "POST"){




            $form->bind($request->get("content_info"));

            if($form->isValid()){

                $post  = $form->save($this->get("model.content"), $user);

                if($post instanceof \WP_Post){

                    if($request->get("has_oembed") && $form["oembed_data"]->getValue()){
                        $this->get("model.content")->setMeta($post->ID, "ubiqa_content_has_oembed", 1);
                        $this->get("model.content")->setMeta($post->ID, "ubiqa_content_oembed", $form["oembed_data"]->getValue());
                    }





                    if(isset($_FILES["content_info"])){

                        $file = array();
                        foreach($_FILES["content_info"] as $key=>$value){
                            if(isset($value["file"])) $file[$key] = $value["file"];
                        }


                        if(isset($file["tmp_name"]) && $file["tmp_name"]){

                            $this->getModel()->uploadToMediaFromFile($file, $post, $form["type"]->getValue() == "image");

                        }



                    }

                    /**
                     * @var $admin_model AdminModel
                     */
                    $admin_model = $this->get("model.admin");

                    if($admin_model->getOption("has_geo")){
                        return $this->resultRedirect($this->generateUrl("add_content_geo", array("content_id"=>$post->ID)));
                    }else{
                        return $this->resultRedirect($this->generateUrl("add_content_topics", array("content_id"=>$post->ID)));
                    }


                }




            }

        }



        return $this->resultTemplate("Content/newInfo.php", array("form"=>$form));

    }

    function newGeoAction(Request $request, \WP_Query $query){


        $user = $this->get("sense.model.user")->getUser();

        $admin_model = $this->get("model.admin");
        $config      = $admin_model->getConfigOptions();
        $this->get("theme")->assign("map_config", array(

            'tile_url' => isset($config["map_tile_url"]) ? $config["map_tile_url"] : 'http://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',
            'attribution'  => isset($config["map_attribution"]) ? $config["map_attribution"] : "Ubiqarama"

        ));
        //$this->addScript("leaflet", "http://cdn.leafletjs.com/leaflet-0.7.3/leaflet.js","1");
        $this->addScript("contentedit", get_template_directory_uri() . "/js/content_edit.js","1",array( "jquery"));
        //$this->addStyle("leaflet", "http://cdn.leafletjs.com/leaflet-0.7.3/leaflet.css", "1");

        $form = new ContentGeoForm(array(), $this->get("sense.form.builder"), $this->get("model.route")->getList());
        if($request->getMethod() == "POST"){

            $form->bind($request->get("content_geo"));

            if($form->isValid()){


                $post= $form->save(\get_post($query->query_vars["content_id"]), $this->get("model.content"));

                return $this->resultRedirect($this->generateUrl("add_content_topics", array("content_id"=>$post->ID)));

            }

        }







        return $this->resultTemplate("Content/newGeo.php", array("form"=>$form));

    }


    function newTopicsAction(Request $request, \WP_Query $query){

        $user = $this->get("sense.model.user")->getUser();

        $model = $this->get("model.content");



        $item = \get_post($query->query_vars["content_id"]);
        $type = $model->getMeta($item->ID, "ubiqa_content_type");

        $this->addScript("icheck", get_template_directory_uri() . "/js/icheck.jquery.js","1",array( "jquery"));
        $this->addScript("contentedit", get_template_directory_uri() . "/js/content_edit.js","1",array( "jquery"));
        $terms = array();
        foreach(get_terms("topic", array("hide_empty"=>false)) as $term){
            $terms[$term->term_id] = \qtrans_use(\qtrans_getLanguage(), $term->name, true);
        }

        $categories = array();
        foreach(get_terms("ubiqa_category", array("hide_empty"=>false)) as $term){
            $categories[$term->term_id] = \qtrans_use(\qtrans_getLanguage(), $term->name, true);
        }

        $form = new ContentTopicForm(array(), $this->get("sense.form.builder"), $terms, $categories);
        if($request->getMethod() == "POST"){


            $form->bind($request->get("content_topic", array()));

            if($form->isValid()){


                $post = $form->save($item, $this->get("model.content"));
                $this->get("model.content")->publish($post);
                if($request->get("restart")){
                    return $this->resultRedirect($this->generateUrl("add_content_info", array()));
                }else{
                    return $this->resultRedirect($this->generateUrl("user_content"));
                }



            }

        }


        return $this->resultTemplate("Content/newTopic.php", array("form"=>$form, "item"=>$item, "content_type"=>$type));

    }

    function userAction(Request $request, \WP_Query $query){

        $user = $this->get("sense.model.user")->getUser();



        $this->get("model.content")->getUserContentQB($user->ID, $query->query_vars["paged"]?:1)->updateMainQuery();



        return $this->resultTemplate("Account/content.php", array("items"=>array(), "user"=>$user));

    }

    function editAction(Request $request, \WP_Query $query){



        if($post = \get_post($query->query_vars["content_id"])){

            $admin_model = $this->get("model.admin");
            $config      = $admin_model->getConfigOptions();

            $this->get("theme")->assign("map_config", array(

                'tile_url' => isset($config["map_tile_url"]) ? $config["map_tile_url"] : 'http://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',
                'attribution'  => isset($config["map_attribution"]) ? $config["map_attribution"] : "Ubiqarama"

            ));



            $this->addScript("content", get_template_directory_uri() . "/js/content.js","1",array("jquery"));

            $this->addScript("icheck", get_template_directory_uri() . "/js/icheck.jquery.js","1",array( "jquery"));
           // $this->addScript("leaflet", "http://cdn.leafletjs.com/leaflet-0.7.3/leaflet.js","1");
            $this->addScript("contentedit", get_template_directory_uri() . "/js/content_edit.js","1",array( "jquery"));
           // $this->addStyle("leaflet", "http://cdn.leafletjs.com/leaflet-0.7.3/leaflet.css", "1");

            $projects = array();
            foreach($this->get("model.project")->getList() as $project){
                $projects[$project->ID] = \get_the_title($project);
            }
            $info_form = new ContentInfoForm(array(), $this->get("sense.form.builder"), $projects);
            $info_form->getBuilder()->add("status", "choice", array("choices"=>array(
                "publish" => __("Publicado", "ubiqa"),
                "pending" => __("Pendiente", "ubiqa"),
                "draft" => __("Borrador", "ubiqa"),
            ), "class"=>"form-control", "label"=>__("Estado de publicación", "ubiqa")));

            $info_form->setValues($post, $this->get("model.content"));
            $info_form["status"]->setValue($post->post_status);

            $oembed_data = array(
                'has_value' => $this->get("model.content")->getMeta($post->ID, "ubiqa_content_has_oembed"),
                'data'       =>  $this->get("model.content")->getMeta($post->ID, "ubiqa_content_oembed"),
            );

            $info_form["oembed_data"]->setValue(htmlentities($this->get("model.content")->getMeta($post->ID, "ubiqa_content_oembed")));

            $geo_form = new ContentGeoForm(array(), $this->get("sense.form.builder"), $this->get("model.route")->getList(),true);
            $geo_form->geo_required = false;
            $geo_form->setValues($post, $this->get("model.content"));

            $terms = array();
            foreach(get_terms("topic", array("hide_empty"=>false)) as $term){
                $terms[$term->term_id] = \qtrans_useDefaultLanguage($term->name);
            }

            $categories = array();
            foreach(get_terms("ubiqa_category", array("hide_empty"=>false)) as $term){
                $categories[$term->term_id] = \qtrans_use(\qtrans_getLanguage(), $term->name, true);
            }

            $topic_form = new ContentTopicForm(array(), $this->get("sense.form.builder"), $terms, $categories);
            $topic_form->setValues($post, $this->get("model.content"));



            if($request->getMethod() == "POST"){

                $info_form->bind($request->get("content_info"));
                $geo_form->bind($request->get("content_geo"));


                $topic_form->bind($request->get("content_topic"));

                if($info_form->isValid() && $geo_form->isValid() && $topic_form->isValid()){



                    $post = $info_form->save(
                        $this->get("model.content"),
                        $this->get("sense.model.user")->getUser(),
                        $post,
                        $info_form["status"]->getValue()
                    );

                    if($request->get("has_oembed") && $info_form["oembed_data"]->getValue()){
                        $this->get("model.content")->setMeta($post->ID, "ubiqa_content_has_oembed", 1);
                        $this->get("model.content")->setMeta($post->ID, "ubiqa_content_oembed", $info_form["oembed_data"]->getValue());
                    }else{
                        $this->get("model.content")->setMeta($post->ID, "ubiqa_content_has_oembed", "");
                        $this->get("model.content")->setMeta($post->ID, "ubiqa_content_oembed", "");
                    }




                    $geo_form->save($post, $this->get("model.content"));
                    $topic_form->save($post, $this->get("model.content"));


                    if(isset($_FILES["content_info"])){

                        $file = array();
                        foreach($_FILES["content_info"] as $key=>$value){
                            if(isset($value["file"])) $file[$key] = $value["file"];
                        }

                        if(isset($file["tmp_name"]) && $file["tmp_name"]){

                            $this->getModel()->uploadToMediaFromFile($file, $post, $info_form["type"]->getValue() == "image");

                        }



                    }




                    $this->get("sense.model.user")->setFlash("notice", __("Datos actualizados correctamente", "ubiqa"));
                    return $this->resultRedirect($request->headers->get("referer"));

                }


            }



        }

        return $this->resultTemplate("Content/edit.php", array("item"=>$post, "oembed" => $oembed_data, "info_form"=>$info_form, "geo_form"=>$geo_form, "topic_form"=>$topic_form));

    }

    function removeAction(Request $request, \WP_Query $query){


        $this->get("model.content")->remove($query->query_vars["content_id"], $this->get("sense.model.user")->getUser());

        return $this->resultRedirect($request->headers->get("referer"));

    }

    function userFavsAction(Request $request, \WP_Query $query){

        $user = $this->get("sense.model.user")->getUser();



        $this->get("model.content")->getUserFavsQB($user->ID, $query->query_vars["paged"]?:1)->updateMainQuery();

        //$query->query_vars = $this->get("model.content")->getUserFavs($user->ID, $query->query_vars["paged"]?:1)->query_vars;






        return $this->resultTemplate("Account/fav.php");

    }

    function addFavAction(Request $request, \WP_Query $query){

//        $user = $this->get("sense.model.user")->getUser();
//
//        $this->get("model.content")->addFav($query->query_vars["content_id"], $user?$user->ID: time());
//
//        return $this->resultRedirect($request->headers->get("referer"));

        $user = $this->get("sense.model.user")->getUser();

        $is_like = (bool)$this->get("model.content")->isFavorite($query->query_vars["content_id"], $user);


        if($is_like){
            $this->get("model.content")->removeFav($query->query_vars["content_id"], $user->ID);
        }else{
            $this->get("model.content")->addFav($query->query_vars["content_id"], $user->ID);
        }



        return $this->resultResponse(new JsonResponse(array("is_fav"=>!$is_like, "count"=>$this->get("model.content")->getMeta($query->query_vars["content_id"], "ubiqa_favs"))));

    }

    function removeFavAction(Request $request, \WP_Query $query){

        $user = $this->get("sense.model.user")->getUser();

        $this->get("model.content")->removeFav($query->query_vars["content_id"], $user->ID);

        return $this->resultRedirect($request->headers->get("referer"));

    }

    function addLikeAction(Request $request, \WP_Query $query){

        $user = $this->get("sense.model.user")->getUser();

        $is_like = $user ? (bool)$this->get("model.content")->isLike($query->query_vars["content_id"], $user) : false;




        if($is_like){
            $this->get("model.content")->removeLike($query->query_vars["content_id"], $query->query_vars["user_id"]);
        }else{

            $this->get("model.content")->addLike($query->query_vars["content_id"], $query->query_vars["user_id"]);
        }



        return $this->resultResponse(new JsonResponse(array("is_fav"=>!$is_like, "count"=>$this->get("model.content")->getMeta($query->query_vars["content_id"], "ubiqa_likes"))));

    }

    function removeLikeAction(Request $request, \WP_Query $query){

        $this->get("model.content")->removeLike($query->query_vars["content_id"], $query->query_vars["user_id"]);

        return $this->resultRedirect($request->headers->get("referer"));

    }


    function ajaxSetVimeoThumbnailAction(Request $request, \WP_Query $query){

        $post = get_post($request->get("id"));
        $model   = $this->get("model.admin");

        $data = $model->getConfigOptions();


        if($this->getModel()->getMeta($post->ID, "ubiqa_content_pending_thumbnail_ttl", time())<time()){
            die();
        }

        if(isset($data["vimeo_api_client_id"]) && $data["vimeo_api_client_id"]){


            $vimeo_url = $this->getModel()->getMeta($post->ID, "ubiqa_content_content_url");

            if(false !== strpos($vimeo_url, "vimeo")){



                $video_id  = str_replace("https://vimeo.com/", "", $vimeo_url);

                sleep(1);
                $lib = new \Vimeo\Vimeo($data["vimeo_api_client_id"], $data["vimeo_api_client_secret"]);
                $lib->setToken($data["vimeo_api_access_token"]);
                $response = $lib->request("/videos/{$video_id}/pictures");



                if(isset($response["body"]["data"][0]["sizes"])){

                    $data = array_pop($response["body"]["data"][0]["sizes"]);


                    if($data["link"]){
                        $this->getModel()->setExternalImageToPost($data["link"], $post->ID, "", true);

                        $this->getModel()->removeMeta($post->ID, "ubiqa_content_pending_thumbnail");
                        $this->getModel()->removeMeta($post->ID, "ubiqa_content_pending_thumbnail_ttl");
                        $thumb = wp_get_attachment_image_src( get_post_thumbnail_id($post->ID), 'ubiqa_content_tall_thumb' );

                        return $this->resultResponse(new JsonResponse(array("src"=> $thumb && isset($thumb['0']) ? $thumb['0'] : $data["link"])));
                    }


                }



            }





            return $this->resultResponse(new JsonResponse());

        }




    }

    /**
     * @return ContentModel
     */
    function getModel(){

        return $this->get("model.content");
    }



} 