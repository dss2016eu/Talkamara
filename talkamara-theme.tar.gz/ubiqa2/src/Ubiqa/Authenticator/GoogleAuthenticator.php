<?php
/**
 * Created by PhpStorm.
 * User: Asier
 * Date: 16/04/14
 * Time: 17:01
 */

namespace Ubiqa\Authenticator;



class GoogleAuthenticator implements AuthenticatorInterface {

    protected $client;
    protected $oauth;
    protected $redirect_url;
    protected $user_id, $email;
    protected $user;
    protected $storage;

    function __construct($app_name,
                         $google_client_id,
                         $google_client_secret,
                         $google_redirect_url,
                         $google_developer_key,
                         UserTokenStorage $storage){

        $this->redirect_url = $google_redirect_url;
        $this->storage      = $storage;

        $this->client = new \Google_Client();
        $this->client->setScopes(array(
            'https://www.googleapis.com/auth/plus.me',
            'https://www.googleapis.com/auth/userinfo.email',
            'https://www.googleapis.com/auth/userinfo.profile',
        ));
        $this->client->setApplicationName($app_name);
        $this->client->setClientId($google_client_id);
        $this->client->setClientSecret($google_client_secret);
        $this->client->setRedirectUri($google_redirect_url);
        $this->client->setDeveloperKey($google_developer_key);

        $this->oauth =  new \Google_Service_Oauth2($this->client);
    }

    function setRedirectUrl($url){
        $this->redirect_url = $url;
    }

    function getEmail(){
        return $this->email;
    }


    function setUserToken($user_id){
        if($token= $this->storage->getUserToken($user_id, "google")){
            $this->client->setAccessToken($token);
        }
    }

    function setAccessToken($token){
        $this->client->setAccessToken($token);
        if($this->client->isAccessTokenExpired()){

return;

            $token = json_decode($token, true);
            $refresh_token = $token["refresh_token"];

            try{

                $this->client->refreshToken($refresh_token);
                $user_id = $this->isAuthenticated();
                $this->persistToken($user_id, $this->client->getAccessToken());

            }catch(\Exception $e){

                return;
            }

        }


        $this->isAuthenticated();
    }

    function persistToken($user_id, $token){
        $this->storage->setTokenToUser($user_id, $token, "google");
    }

    function isAuthenticated(){
        if(!$this->user_id){

            if($this->client->isAccessTokenExpired()) return false;

            $user = $this->oauth->userinfo->get();
            $this->user_id = isset($user["id"]) ? $user["id"] : null;
            $this->email   = isset($user["email"]) ? $user["email"] : null;
        }
        return $this->user_id;
    }


    function getUser(){
        return $this->user ? $this->user : $this->user = $this->storage->getUserByEmail($this->email);
    }

    function authenticate($oauth_code=null){

        $this->client->authenticate($oauth_code);
        $is_auth = $this->isAuthenticated();

        if($user = $this->getUser()){

            $this->storage->setTokenToUser($user->ID, $this->client->getAccessToken(), "google", $this->user_id);
        }

        return $is_auth;

    }


    function getAuthUrl(){
        return $this->client->createAuthUrl();
    }





} 