<?php
/**
 * Created by PhpStorm.
 * User: asierm
 * Date: 15/08/14
 * Time: 20:19
 */

namespace Ubiqa\Form;


use SimpleForm\AbstractForm;
use SimpleForm\FormBuilder;
use Ubiqa\Model\ContentModel;

class FilterForm extends AbstractForm {


    /**
     * @var ContentModel
     */
    private $_model;

    private $_topics;

    private $_categories;

    private $_cities;

    function __construct($data, FormBuilder $builder, ContentModel $model, $topics=array(), $cities=array(), $categories=array()){

        $this->_model = $model;
        $this->_topics = $topics;
        $this->_cities = $cities;
        $this->_categories = $categories;
        $this->_cities[""] = __("Todas", "ubiqa");
        $this->_categories[""] = __("Todas", "ubiqa");
        parent::__construct($data, $builder);

    }



    function configure(){

        $this->setName("filter");

        $builder = $this->getBuilder();

        $ages = array();
        foreach(array("",10,20,30,40,50,60,70,80,90) as $age){

            $ages[$age] = $age;

        }


        $project_choices = array(""=>__("Todos", "ubiqa"));
        foreach($this->_model->getProjects() as $project)
        {
            $project_choices[$project->ID] = \get_the_title($project);
        }

       // $this->_categories[""] = __("Todos", "ubiqa");



        $languages = array(__("Todos", "ubiqa"));
        foreach(_u()->getLanguages($iso_as_key=true) as $iso=>$label){
            $languages[$iso] = $label;
        }



        $builder->add("content_type", "choice", array(
            "expanded" => true,
            "multiple" => true,
            "required" => false,
            "style" =>"display:none",
            "label"    => __("Tipo de contenido", "ubiqa"),
            "choices"  => array("image" => __("Imagen", "ubiqa"),"video" => __("Video", "ubiqa"), "audio"=> __("Audio", "ubiqa"), )
        ))
        ->add("subproject", "choice", array(
                "choices"  => $project_choices,
                "required" => false,
                "label"    => __("Proyecto", "ubiqa"),
                "class"    => "form-control"
         ))
            ->add("ubiqa_category", "choice", array(
                "choices"  =>  $this->_categories,
                "required" => false,
                "label"    => __("ubiqa_category", "ubiqa"),
                "class"    => "form-control"
            ))
        ->add("search", "text", array("placeholder" => __("Buscar", "ubiqa"), "required" => false,"class"=>"form-control"))
        ->add("city", "choice", array("choices"=>$this->_cities,"required" => false,"class"=>"form-control"))
        ->add("topic", "choice", array("choices"=>$this->_topics, "label"=> __("Temáticas", "ubiqa"), "class"=>"form-control", "multiple"=>true, "expanded"=>true))
        ->add("is_interview", "input", array( "type"=>"checkbox", "expanded"=>true, "multiple"=>true, "only_input"=>true, "required" => false,"class"=>"" , "checked_value"=> 1))
        ->add("age_from", "choice", array("choices" => $ages, "required" => false,"class"=>"form-control",  "label"=> __("Desde", "ubiqa")))
        ->add("age_to", "choice", array("choices" => $ages, "required" => false,"class"=>"form-control",  "label"=> __("hasta", "ubiqa")))
        ->add("language", "choice", array("choices" => $languages, "required" => false,"class"=>"form-control",  "label"=> __("Idioma", "ubiqa")))
        ->add("genre", "choice", array("required" => false,"class"=>"form-control",  "label"=> __("Género", "ubiqa"), "choices"=> array(""=>__("Todos", "ubiqa"),"male"=>__("Hombre", "ubiqa"), "female"=>__("Mujer", "ubiqa"))))
        ;

    }

} 