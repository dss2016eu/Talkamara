<h3><?php _e("Localización", "ubiqa") ?></h3>
<h5><?php _e("Coordenadas", "ubiqa") ?></h5>
<p>
    <input type="text"
           value="<?php echo $this->_model->getMeta($post->ID, "ubiqa_content_lon") ?>"
           name="ubiqa_content[lon]"
           id="content_geo_lon"
           placeholder="<?php _e("Longitud", "ubiqa") ?>">
    <input type="text"
           value="<?php echo $this->_model->getMeta($post->ID, "ubiqa_content_lat") ?>"
           name="ubiqa_content[lat]"
           id="content_geo_lat"
           placeholder="<?php _e("Latitud", "ubiqa") ?>">
</p>
<h5><?php _e("País", "ubiqa") ?></h5>
<p>
    <input type="text"
           value="<?php echo $this->_model->getMeta($post->ID, "ubiqa_content_country") ?>"
           name="ubiqa_content[country]"
           id="content_geo_country"
           placeholder="<?php _e("País", "ubiqa") ?>">
</p>
<script type="text/javascript">

    var latlon = {lat: <?php echo $this->_model->getMeta($post->ID, "ubiqa_content_lat", "null") ?>,lon: <?php echo $this->_model->getMeta($post->ID, "ubiqa_content_lon", "null") ?>};

</script>

<div style="height: 400px" id="city_map_container">

</div>