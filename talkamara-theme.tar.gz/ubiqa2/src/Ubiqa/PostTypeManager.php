<?php
/**
 * Created by PhpStorm.
 * User: Asier
 * Date: 30/06/14
 * Time: 13:43
 */

namespace Ubiqa;


class PostTypeManager {


    function init(){
        $this->registerAgenda();
        $this->registerContent();
        $this->registerSubproject();
        $this->registerRoute();
        $this->registerTopicTaxonomy();
        $this->registerCity();

        add_post_type_support( 'page', 'excerpt' );

    }

    function registerTopicTaxonomy(){

        \register_taxonomy(
            'topic',
            array('content', 'post', 'agenda'),
            array(
                'label' => __( 'Temática', "ubiqa" ),
                'rewrite' => array( 'slug' => 'topic' ),
                'hierarchical' => false,
                'show_admin_column' => true
            )
        );
        \add_action('topic_add_form', 'qtrans_modifyTermFormFor');
        \add_action('topic_edit_form', 'qtrans_modifyTermFormFor');

        \register_taxonomy(
            'ubiqa_category',
            array('content', 'post', 'agenda', 'route'),
            array(
                'label' => __( 'Categoría general', "ubiqa" ),
                'rewrite' => array( 'slug' => 'general-category' ),
                'hierarchical' => true,
                'show_admin_column' => true
            )
        );
        \add_action('ubiqa_category_add_form', 'qtrans_modifyTermFormFor');
        \add_action('ubiqa_category_edit_form', 'qtrans_modifyTermFormFor');

    }

    function registerSubproject(){
        \register_post_type( 'subproject',
            array(
                'labels' => array(
                    'name' => __( 'Proyectos' , 'ubiqa'),
                    'singular_name' => __( 'Proyecto' , 'ubiqa')
                ),
                'public'      => true,
                'has_archive' => true,
                'rewrite'     => array('slug' => 'projects'),
                'supports' => array( 'title', 'editor', 'excerpt', 'thumbnail' )
            )
        );
    }

    function registerAgenda(){
        \register_post_type( 'agenda',
            array(
                'labels' => array(
                    'name' => __( 'Agenda' , 'ubiqa'),
                    'singular_name' => __( 'Agenda' , 'ubiqa')
                ),
                'public'      => true,
                'has_archive' => true,
                'rewrite'     => array('slug' => 'agenda'),
                'supports' => array( 'title', 'editor', 'comments', 'excerpt', 'thumbnail' )
            )
        );
    }

    function registerRoute(){
        \register_post_type( 'route',
            array(
                'labels' => array(
                    'name' => __( 'Rutas' , 'ubiqa'),
                    'singular_name' => __( 'Ruta' , 'ubiqa')
                ),
                'public'      => true,
                'has_archive' => true,
                'rewrite'     => array('slug' => 'route'),
                'supports' => array( 'title', 'editor', 'excerpt', 'thumbnail' )
            )
        );
    }

    function registerCity(){
        \register_post_type( 'city',
            array(
                'labels' => array(
                    'name' => __( 'Localidades' , 'ubiqa'),
                    'singular_name' => __( 'Localidad' , 'ubiqa')
                ),
                'public'      => true,
                'has_archive' => true,
                'rewrite'     => array('slug' => 'city'),
                'supports' => array( 'title', 'excerpt' )
            )
        );
        add_action( 'admin_enqueue_scripts', function(){
            if ( 'city' == get_post_type() )
                wp_dequeue_script( 'autosave' );
        });
    }

    function registerContent(){
        \register_post_type( 'content',
            array(
                'labels' => array(
                    'name' => __( 'Contenido' , 'ubiqa'),
                    'singular_name' => __( 'Contenido' , 'ubiqa')
                ),
                'public'      => true,
                'has_archive' => true,
                'rewrite'     => array('slug' => 'content'),
                'supports' => array( 'title', 'editor', 'comments', 'excerpt', 'thumbnail' )
            )
        );
    }
} 