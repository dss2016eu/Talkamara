<?php
/**
 * Created by PhpStorm.
 * User: asierm
 * Date: 15/08/14
 * Time: 18:14
 */

namespace Ubiqa\Interceptor;


use Sense\AbstractInterceptor;

class RouteInterceptor extends AbstractInterceptor {


    function execute(\WP_Query $wp_query){


        if(!$this->isExecuted()){

            $this->addScript("leaflet", "http://cdn.leafletjs.com/leaflet-0.7.3/leaflet.js","1");
            $this->addScript("leaflet.cluster", get_template_directory_uri() . "/js/leaflet.markercluster.js","1");
            //$this->addScript("leaflet_overlap", get_template_directory_uri() . "/js/leaflet/overlap.js","1",array("leaflet", "jquery"));
            $this->addScript("route", get_template_directory_uri() . "/js/route.js","1",array("leaflet", "jquery"));
            $this->addStyle("leaflet", "http://cdn.leafletjs.com/leaflet-0.7.3/leaflet.css", "1");
            $this->addStyle("leaflet_cluster",  get_template_directory_uri() . "/css/leaflet.markercluster.css", "1");
            $_route = $this->get("model.content")->getOneBy("name", $wp_query->query_vars["name"], "route");

            if($_route instanceof \WP_Post){
                $visit = (int) get_post_meta($_route->ID, "ubiqa_visit", true);
                update_post_meta($_route->ID, "ubiqa_visit", ++$visit);
            }



            $items = $this->get("model.route")->getContentsArray($this->get("model.content")->getOneBy("name", $wp_query->query_vars["name"], "route"));

            $markers_info = array();
            foreach($items as $i=>$item){
                $markers_info[] = array(
                    "id" => $item->ID,
                    "type" => $this->get("model.content")->getMeta($item->ID, "ubiqa_content_type"),
                    "lat" => $this->get("model.content")->getMeta($item->ID, "ubiqa_content_lat"),
                    "lon" => $this->get("model.content")->getMeta($item->ID, "ubiqa_content_lon"),
                    "position" => $this->get("model.content")->getMeta($item->ID, "ubiqa_content_route_position")?:$i,
                );
            }



            $this->assignToView("contents", $items);
            $this->assignToView("markers_info", $markers_info);

        }


    }

    function executeForArchive(\WP_Query $wp_query){


        if(!$this->isExecuted()){

            /**
             * @var $asset_manager AssetManager
             */
            $asset_manager = $this->get("sense.theme_assets");
            $asset_uri     = $this->get("%wp.template_uri%");


            $asset_manager->addScript('route', $asset_uri . '/js/routes.js', 1, true, array());

        }


    }

} 