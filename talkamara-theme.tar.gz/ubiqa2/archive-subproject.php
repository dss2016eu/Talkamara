<?php get_header() ?>

    <div class="bg-white-2">
        <ul class="breadcrumb container inline">
            <li class="breadcrumb-item"><a href="<?php echo _u()->getUrl() ?>"><?php _e("inicio", "ubiqa") ?></a></li>
            <li class="breadcrumb-item"><?php _e("proyectos", "ubiqa") ?></li>
        </ul>
    </div>

    <section class="bg-white-2">
        <div class="container">
            <div class="txt-right container">
                <label class="air-h"><?php _e("Ordenar por", "ubiqa") ?></label>
                <select name="order" id="order_selector" class="inline">
                    <option value="date"><?php _e("Fecha", "ubiqa") ?></option>
                    <option value="views"><?php _e("Vistas", "ubiqa") ?></option>
                </select>
            </div>
            <hr>
            <div id="project_grid" class="masonry grid routes cards"></div>
            <div class="air">
                <div id="loading" class="spinner" style="display: none"><div></div></div>
                <button id="load_more" class="btn-default full-w"><?php _e("Ver más", "ubiqa") ?></button>
            </div>
    </section>



    <script type="text/javascript">
        var posts_url = "<?php echo _u()->genUrl("ajax_project_items") ?>";
    </script>

<?php get_footer() ?>