<?php
/**
 * Created by PhpStorm.
 * User: Asier
 * Date: 27/06/14
 * Time: 19:06
 */
//update_option('siteurl','http://1ub.simettric.com');
//update_option('home','http://1ub.simettric.com');










add_action( 'after_setup_theme', function(){
    //die(get_locale());
    load_theme_textdomain('ubiqa', get_template_directory() . '/languages');
} );


require "vendor/autoload.php";
require "Vimeo.php";
/*
require "includes/wp_bootstrap_navwalker.php";
require "includes/side_navwalker.php";
require "includes/CustomPostTypeArchiveInNavMenu.php";
*/

$sense = new \Sense\Sense(\Ubiqa\Theme::getInstance(), __DIR__);

$sense["model.project"] = function($c){
    return new \Ubiqa\Model\ProjectModel();
};

$sense["model.route"] = function($c){
    return new \Ubiqa\Model\RouteModel();
};

$sense["model.content"] = function($c){
    return new \Ubiqa\Model\ContentModel();
};

$sense["model.user"] = function($c){
    return new \Sense\Model\UserModel();
};

$sense["model.admin"] = function($c){
    return new \Ubiqa\Model\AdminModel($c);
};

$sense["security.http"] = function($c){
    $httpsec = new \Ubiqa\HTTPAuthenticator($c["sense.model.user"]);
    $httpsec->init($c["request"]);

    return $httpsec;
};

$sense["social.authenticator"] = function($c){
    global $wpdb;
    $back_url = $c["theme"]->genUrl("social_auth", array(), true);

    return new \Ubiqa\WPMultiLogin($wpdb, $c["model.user"], $back_url, $c["model.admin"]);
};



$sense["theme"]->assign("content", $sense["model.content"]);
$sense["theme"]->assign("model.project", $sense["model.project"]);

$sense["vimeo"] = function($c){

    $data = $c["model.admin"]->getConfigOptions();

    if(!isset($data["vimeo_api_client_id"])){
        echo("No se ha configurado una api para vimeo"); return;
    }


    return new \Vimeo($data["vimeo_api_client_id"], $data["vimeo_api_client_secret"], $data["vimeo_api_access_token"]);
    //return new \Vimeo("3ae21c6ca4a477db3024e09a78673eca876ce752","17c6e6dd08c208b99b360d303ca8fa3a4a2bd98e", "1d1165a234271b019564bec9a56dde3f");
};


$sense["requisites"] = function($c){
    $data =  $c["model.admin"]->getConfigOptions();


    return (isset($data["vimeo_api_client_id"]) && $data["google_api_app_name"] && $data["facebook_api_appid"] && $data["twitter_api_consumer_key"]);



};

add_action( 'admin_notices', function() use($sense){

    if(!$sense["requisites"]){
?>
        <div class="updated">
            <p><?php _e( 'Debe configurar los parámetros de vimeo e inicios de sesión en el theme ubiqa correctamente', 'ubiqa' ); ?></p>
        </div>
<?php
    }

});




\register_nav_menus( array(
    'primary' => __( 'Menú de navegación', 'ubiqa' ),
) );

$post_types = new \Ubiqa\PostTypeManager();
\add_action('init', array($post_types, "init"));


new \Ubiqa\Admin($sense);

new \Ubiqa\Metabox\ContentMetabox($sense["model.content"], $sense);
new \Ubiqa\Metabox\AgendaMetabox(new \Ubiqa\Model\AgendaModel(), $sense);
new \Ubiqa\Metabox\PostMetabox($sense["model.content"], $sense);
new \Ubiqa\Metabox\CityMetabox($sense["model.content"], $sense);
new \Ubiqa\CustomPostTypeArchiveInNavMenu();








//todo interceptors
add_action('pre_get_posts', function(WP_Query $query) use($sense){


    if( !is_admin() ){

        if(\is_search() ){

            $interceptor = new \Ubiqa\Interceptor\SearchInterceptor($sense);
            $interceptor->execute($query);

        }

        if($query->is_post_type_archive("agenda") ){

            $interceptor = new \Ubiqa\Interceptor\AgendaInterceptor($sense);
            $interceptor->execute($query);

        }

        if($query->is_post_type_archive("subproject") ){

            $interceptor = new \Ubiqa\Interceptor\ProjectInterceptor($sense);
            $interceptor->execute($query);

        }

        if($query->is_post_type_archive("route") ){

            $interceptor = new \Ubiqa\Interceptor\RouteInterceptor($sense);
            $interceptor->executeForArchive($query);

        }

        if(\is_post_type_archive("content") ){

            $interceptor = new \Ubiqa\Interceptor\ContentInterceptor($sense);
            $interceptor->execute($query);

        }



        if(is_author()){
            $interceptor = new \Ubiqa\Interceptor\AuthorInterceptor($sense);
            $interceptor->execute($query);
        }


        if(is_single() && isset($query->query_vars["post_type"]) && $query->query_vars["post_type"] == "route"){



            $interceptor = new \Ubiqa\Interceptor\RouteInterceptor($sense);
            $interceptor->execute($query);
        }

        if(is_single() && isset($query->query_vars["post_type"]) && $query->query_vars["post_type"] == "subproject"){



            $interceptor = new \Ubiqa\Interceptor\ProjectInterceptor($sense);
            $interceptor->executeDetail($query);
        }

        if(is_single() && isset($query->query_vars["post_type"]) && $query->query_vars["post_type"] == "content"){



            $interceptor = new \Ubiqa\Interceptor\SingleContentInterceptor($sense);
            $interceptor->execute($query);
        }

        if($blog_page = get_post(get_option( 'page_for_posts', -1 ))){

            $current_object = get_queried_object();
            if($current_object instanceof \WP_Post){
                if($blog_page && $current_object->ID==$blog_page->ID){

                    $interceptor = new \Ubiqa\Interceptor\BlogInterceptor($sense);
                    $interceptor->execute($query);

                }
            }


        }

    }




});


//todo ajax
$agenda_ajax = function() use($sense){

    $controller = new \Ubiqa\Controller\AgendaController($sense);
    $controller->ajaxCalendarAction();
    exit();
};
add_action( 'wp_ajax_ubiqa.agenda.calendar', $agenda_ajax);
add_action( 'wp_ajax_nopriv_ubiqa.agenda.calendar', $agenda_ajax);

$sigle_content_ajax = function() use($sense){

    $controller = new \Ubiqa\Controller\ContentController($sense);
    $controller->ajaxGetSingleContent(\Symfony\Component\HttpFoundation\Request::createFromGlobals());
    exit();
};

add_action( 'wp_ajax_nopriv_ubiqa.content.singlecontent', $sigle_content_ajax);
add_action( 'wp_ajax_ubiqa.content.singlecontent', $sigle_content_ajax);

$config_routing = new \Ubiqa\Config\RoutingConfig($sense["router"]);
$config_routing->setRoutes($sense["router"]);

$sense->init();


//custom options to theme
//add_action('init', function() use ($sense){
//
//
//
//});

/**
 * @var $model \Ubiqa\Model\AdminModel
 */
$model = $sense["model.admin"];

$sense["theme"]->setUtil($sense["util"]);
$sense["theme"]->setConfigurableOptions($model->getConfigOptions(), $model->getCustomOptions());

function _u(){
    return \Ubiqa\Theme::getInstance();
};

function _requisites(){
    global $sense;
    return $sense["requisites"];
}

//redirecciones
add_action("init",function(){



    global $pagenow;

    $redirect = false;
    if (( 'wp-login.php' == $pagenow ) && (!is_user_logged_in())) {
        $redirect = true;
    }

    if(( 'admin-ajax.php' != $pagenow ) && is_admin() && !current_user_can( 'delete_others_pages' ) ){
        $redirect = true;
    }

    if($redirect){
        wp_redirect(_u()->genUrl("home"));
        exit();
    }



});


register_sidebar( array(
    'id'          => 'footer_left',
    'name'        => __( 'Pie de página izquierdo', "ubiqa" ),
    'description' => __( 'Este sidebar incluye la información del footer.', "ubiqa" ),
    'before_widget' => '<div id="%1$s" class="widget %2$s">',
    'after_widget'  => '</div>',
    'before_title'  => '<span class="txt-bold">',
    'after_title'   => '</span><br><br>'
) );
register_sidebar( array(
    'id'          => 'footer_center',
    'name'        => __( 'Pie de página central', "ubiqa" ),
    'description' => __( 'Este sidebar incluye la información del footer.', "ubiqa" ),
    'before_widget' => '<div id="%1$s" class="widget %2$s">',
    'after_widget'  => '</div>',
    'before_title'  => '<span class="txt-bold">',
    'after_title'   => '</span><br><br>'
) );
register_sidebar( array(
    'id'          => 'footer_right',
    'name'        => __( 'Pie de página derecho', "ubiqa" ),
    'description' => __( 'Este sidebar incluye la información del footer.', "ubiqa" ),
    'before_widget' => '<div id="%1$s" class="widget %2$s">',
    'after_widget'  => '</div>',
    'before_title'  => '<span class="txt-bold">',
    'after_title'   => '</span><br><br>'
) );
register_sidebar( array(
    'id'          => 'footer_credits',
    'name'        => __( 'Pie de página para créditos', "ubiqa" ),
    'description' => __( 'Este sidebar incluye la información del footer.', "ubiqa" ),
    'before_widget' => '<div id="%1$s" class="widget %2$s">',
    'after_widget'  => '</div>',
    'before_title'  => '<div><b>',
    'after_title'   => '</b></div><br>'
) );
add_filter( 'show_admin_bar', '__return_false' );
add_filter('the_content','make_clickable');

add_filter('upload_mimes', function($mime_types){
    $mime_types["amr"] = "audio/amr";
    $mime_types["flac"] = "audio/flac";
    $mime_types["mka"] = "audio/x-matroska";
    $mime_types["3gp"] = "audio/3gpp";
    $mime_types["mp3mpeg"] = "audio/mpeg";
    $mime_types["mp3custom"] = "audio/mp3";

    return $mime_types;
}, 1, 1);





/*add_action("init", function(){


    if(is_admin()) return;

    if(!get_current_user_id()) return;


    if(isset($_GET["change"])){

        global $q_config;
        $q_config['language'];

        update_user_meta(get_current_user_id(), "ubiqa_lang", $q_config['language']);



    }


});*/
/**
 *
 */
function cut_excerpt(){
    return 10;
}

add_filter('excerpt_length', function(){
    return 20;
},10);