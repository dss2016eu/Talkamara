<?php
/**
 * Created by PhpStorm.
 * User: asierm
 * Date: 05/09/14
 * Time: 12:37
 */

namespace Ubiqa\Model;


use Sense\Sense;
use Sense\Util;

class AdminModel  {


    /**
     * @var \Sense\Sense
     */
    private $container;

    function __construct(Sense $sense){
        $this->container = $sense;
    }


    function getConfigOptions(){

        $options = get_option("ubiqa_config_options", array());

        if(!count($options)){
            $options = $this->getDefaultConfigOptions();
            update_option("ubiqa_config_options", $options);
        }

        return $options;
    }

    function getCustomOptions(){

        $options = get_option("ubiqa_custom_options", array());

        if(!count($options)){
            $options = $this->getDefaultConfigOptions();
            update_option("ubiqa_custom_options", $options);
        }

        return $options;
    }

    function getOption($key, $scope="config"){
        /**
         * @var $util Util
         */
        $util    = $this->container["util"];


        $options = array();
        switch($scope){
            case "config":
                return $util->getArrayValue($key, $this->getConfigOptions());
            break;

            case "custom":
                return $util->getArrayValue($key, $this->getCustomOptions());
        }


        return null;
    }



    function getDefaultConfigOptions(){



        return array(
            "has_interview"   => 1,
            "has_routes"      => 0,
            "has_geo"         => 1,
            "map_tile_url"    => "http://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png",
            "map_attribution" => "Data by Open Street Maps & Ubiqarama.org",
            "vimeo_api_token" => "",
            "tos_page_id"     => 0,
        );



    }

} 