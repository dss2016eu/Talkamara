<?php
/**
 * Created by PhpStorm.
 * User: asierm
 * Date: 15/08/14
 * Time: 20:33
 */

namespace Ubiqa\Interceptor;


use Sense\AbstractInterceptor;
use Ubiqa\Form\FilterForm;

class ContentInterceptor  extends  AbstractInterceptor{


    function execute(\WP_Query $query){

        if(!$this->isExecuted()){

            $_filter = $this->get("request")->get("filter", array("age_from"=>10, "age_to"=>90, "language"=>"es"));
            $include_terms_id = array();



            $terms = array();
            foreach(get_terms("topic", array("hide_empty"=>true, "include"=>$include_terms_id)) as $term){
                $terms[$term->term_id] = \qtrans_use(\qtrans_getLanguage(), $term->name, true);
            }

            $categories = array();
            foreach(get_terms("ubiqa_category", array("hide_empty"=>false)) as $term){
                $categories[$term->term_id] = \qtrans_use(\qtrans_getLanguage(), $term->name, true);
            }



            $cities = array();
            foreach(get_posts(array("post_type"=>"city", "posts_per_page"=>-1)) as $city){
                $cities[$city->ID] = get_the_title($city);
            }


            $form = new FilterForm($this->get("request")->get("filter"), $this->get("sense.form.builder"), $this->get("model.content"), $terms, $cities, $categories);
            $this->get("theme")->assign("filter_vars", $form->getValues());




            $admin_model = $this->get("model.admin");
            $config      = $admin_model->getConfigOptions();

            $this->get("theme")->assign("map_config", array(

                'tile_url' => isset($config["map_tile_url"]) ? $config["map_tile_url"] : 'http://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',
                'attribution'  => isset($config["map_attribution"]) ? $config["map_attribution"] : "Ubiqarama"

            ));



            $this->get("theme")->assign("filter_form", $form);
            /**
             *
             */

            $this->addScript("leaflet.cluster", get_template_directory_uri() . "/js/leaflet.markercluster.js","1");

            $this->addScript("leaflet_markers", get_template_directory_uri() . "/js/leaflet/famarkers/leaflet.awesome-markers.min.js","1",array( "jquery"));
            $this->addScript("icheck", get_template_directory_uri() . "/js/icheck.jquery.js","1",array( "jquery"));
            $this->addScript("content_manager", get_template_directory_uri() . "/js/content_manager.js","1",array( "jquery"));
            $this->addScript("contents", get_template_directory_uri() . "/js/contents.js","1",array( "jquery", "content_manager"));
            //$this->addStyle("leaflet", "http://cdn.leafletjs.com/leaflet-0.7.3/leaflet.css", "1");
            $this->addStyle("leaflet_cluster",  get_template_directory_uri() . "/css/leaflet.markercluster.css", "1");

            $this->addStyle("leaflet_markers",  get_template_directory_uri() . "/js/leaflet/famarkers/leaflet.awesome-markers.css", "1");







        }


    }

} 