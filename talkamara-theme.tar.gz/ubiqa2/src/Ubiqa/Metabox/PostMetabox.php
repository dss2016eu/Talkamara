<?php
/**
 * Created by PhpStorm.
 * User: Asier
 * Date: 26/07/14
 * Time: 17:56
 */

namespace Ubiqa\Metabox;


use Sense\AbstractMetabox;
use Sense\Sense;
use Ubiqa\Model\AgendaModel;

class PostMetabox extends AbstractMetabox {



    function setUp(){

        \add_meta_box('ubiqa_post_metabox', __( 'Ubiqa', 'ubiqa' ), array($this, "HTML"), 'post', 'side', 'high' );
    }

    function HTML($post){
        include __DIR__ . "/../View/metabox/post_data.php";
    }



    function save($post_id){


        // If this is an autosave, our form has not been submitted, so we don't want to do anything.
        if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
            return;
        }


        if(isset($_POST["ubiqa_post_data"])){

            if(isset($_POST["ubiqa_post_data"]["subproject"]) && $_POST["ubiqa_post_data"]["subproject"]){
                $this->getModel()->setMeta($post_id, "ubiqa_content_subproject", $_POST["ubiqa_post_data"]["subproject"]);
            }
        }


    }



}