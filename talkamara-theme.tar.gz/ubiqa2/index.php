<?php get_header();  if ( have_posts() ) { while ( have_posts() ) { the_post();   ?>

    <section class="bg-white">

        <div class="container grid air-b">
            <div class="col-s-12 col-m-8 col-l-9">
                        <div class="flx-1">
                            <a href="<?php the_permalink() ?>"><h1><?php the_title() ?></h1></a>
                        </div>
            </div>

        </div>
    </section>
    <hr>


<?php }} get_footer() ?>