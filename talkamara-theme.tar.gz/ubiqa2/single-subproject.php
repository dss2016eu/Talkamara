<?php get_header();

if ( have_posts() ) { while ( have_posts() ) { the_post();

$author = \get_user_by( "id", get_the_author_meta("ID") );


?>

<div class="bg-white-2">
    <ul class="breadcrumb container inline">
        <li class="breadcrumb-item"><a href="<?php echo _u()->getUrl() ?>"><?php _e("inicio", "ubiqa") ?></a></li>
        <li class="breadcrumb-item"><a href="<?php echo PROJECTS_URL ?>"><?php _e("proyectos", "ubiqa") ?></a></li>
        <li class="breadcrumb-item"><?php the_title() ?></li>
    </ul>
</div>



<section class="bg-white-1">
    <div class="container">
        <div class="flx-h-m">
            <div class="flx-1">
                <h1><?php the_title() ?></h1>
            </div>
            <div>
                <?php include "includes/single-share.php" ?>
            </div>
        </div>
        <hr>
    </div>
    <div class="container air-v txt-big">
        <?php the_content() ?>
    </div>
</section>


<!-- posts section -->
<section class="bg-white-1">
<div class="container">
<h2 class="txt-center"><?php _e("Últimos contenidos del proyecto", "ubiqa") ?></h2>

<div id="content_grid" class="grid cards masonry">

</div>

<div class="air">
    <div id="loading" class="spinner" style="display: none"><div></div></div>
    <button id="load_more" class="btn-default full-w"><?php _e("Cargar más", "ubiqa") ?></button>
</div>
</div>
</section>
<!-- /posts section -->

<script type="text/javascript">
    var project_id = <?php echo get_the_ID() ?>;
</script>

<?php }} get_footer() ?>