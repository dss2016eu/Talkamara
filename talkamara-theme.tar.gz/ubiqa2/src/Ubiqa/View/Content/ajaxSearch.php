<?php

$items = _u()->get("items");


    foreach($items as $post){

        setup_postdata( $post );
        include get_template_directory() . "/includes/search-card.php";

    }





?>