<?php
/**
 * Created by PhpStorm.
 * User: Asier
 * Date: 5/08/14
 * Time: 12:50
 */

namespace Ubiqa\Form;

use SimpleForm\AbstractForm;
use SimpleForm\FormBuilder;
use Symfony\Component\Config\Definition\Exception\Exception;
use Symfony\Component\Validator\Constraints\Email;
use Symfony\Component\Validator\Constraints\NotBlank;
use Symfony\Component\Validator\Constraints\NotNull;
use Symfony\Component\Validator\Constraints\Length;
use Ubiqa\Model\ContentModel;

class ContentInfoForm extends AbstractForm{


    public $languages = array("es"=>"Español", "en"=>"Inglés", "eu"=>"Euskera");
    public $projects = array();
    public $types    = array();


    function __construct($data=array(), FormBuilder $builder, $projects){

        $this->projects = $projects;
        $this->languages = _u()->getLanguageArray();

        parent::__construct($data, $builder);



    }



    function setValues(\WP_Post $post, ContentModel $model){

        $this["type"]->setValue($model->getMeta($post->ID, "ubiqa_content_type"));
        $this["url"]->setValue($model->getMeta($post->ID, "ubiqa_content_content_url"));

//die($model->getMeta($post->ID, "ubiqa_content_content_url"));

        $this["project"]->setValue($model->getMeta($post->ID, "ubiqa_content_subproject"));

        $titles = \qtrans_split($post->post_title);
        $descriptions = \qtrans_split($post->post_content);

        //die(var_dump($titles));

        foreach($titles as $iso=>$title){
            $this["title_" . $iso]->setValue(htmlspecialchars($title));
        }
        foreach($descriptions as $iso=>$description){
            $this["description_" . $iso]->setValue(htmlspecialchars($description));
        }

    }

    function configure(){

        $this->types     = array("image"=>__("Imagen", "ubiqa"), "audio"=>__("Audio", "ubiqa"),"video"=>__("Video", "ubiqa"));

        $this->setName("content_info");

        $builder = $this->getBuilder();

        $builder->add("type", "choice", array("choices"=>$this->types, "label"=>__("Tipo de contenido"), "class"=>"form-control"));


        $i=0;
        foreach($this->languages as $iso=>$lang){
            $builder->add("title_" . $iso, "text", array("label"=> sprintf(__("Título en %s", "ubiqa"), $lang), "class"=>"form-control  ", "required"=>$i==0));
            $builder->add("description_" . $iso, "textarea", array("label"=>sprintf(__("Descripción en %s", "ubiqa"), $lang), "class"=>"form-control  ", "required"=>false));
            $i++;
        }
        $builder->add("project", "choice", array("choices"=>$this->projects, "label"=>__("Proyecto", "ubiqa"), "class"=>"form-control"));

        $builder->add("file", "input", array("type"=>"file", "data-text"=>"filename"));
        $builder->add("url", "input", array("type"=>"url", "label"=>__("Enlazar archivo", "ubiqa"), "required"=> false, "class"=>"form-control"));
        $builder->add("oembed_data", "input", array("type"=>"hidden", "required"=> false));


    }

    /**
     * @param ContentModel $model
     * @param \WP_User $user
     * @return \WP_Post
     */
    function save(ContentModel $model, \WP_User $user, \WP_Post $post=null, $status="draft"){
        $titles = $contents = array();
        $first_lang = "";
        foreach($this->languages as $iso=>$lang){

            if(!$first_lang){
                $first_lang = $iso;
            }

            $titles[$iso] = $this->getValue("title_" . $iso);
            $contents[$iso] = $this->getValue("description_".$iso);
        }


        $data = array(
            "post_title" => \qtrans_join($titles),
            "post_content" => \qtrans_join($contents),
            "post_author" => $user->ID,
            "post_type" => "content"
        );

        if(!$post){

            $data["post_date"] = \date("Y-m-d H:i:s");
        }





        if(!$post || $post->post_name){
            $data["post_name"] = \sanitize_title($titles[$first_lang]."-".time());
        }


        if($post && $status){
            $data["post_status"] = $status;
        }

        $post = !$post ? $model->create($data) : $model->update($post, $data);

        if(!$post instanceof \WP_Post){
            return null;
        }



        $metas = array(
            "ubiqa_content_type" => $this["type"]->getValue(),
            "ubiqa_content_subproject" => $this["project"]->getValue(),
            "ubiqa_content_content_url" => $this["url"]->getValue()
        );


        $model->updateMetas($post, $metas);

        return $post;

    }

} 