<?php
/**
 * Created by PhpStorm.
 * User: Asier
 * Date: 30/06/14
 * Time: 14:49
 */

namespace Ubiqa;


use Sense\AbstractTheme;
use Sense\Util;

class Theme extends AbstractTheme{



    private $_custom_options=array();
    private $_config_options=array();

    public $is_front = false;


    function setUp(){

        add_action('widgets_init', function(){
            //register_widget('Ubiqa\Widget\FooterWidget');
        });

        \add_theme_support( 'post-thumbnails', array( 'post', 'page', 'agenda', 'content', 'subproject', "route" ) );

        \add_image_size( 'ubiqa_blog_thumb', 400, 400, true );
        \add_image_size( 'ubiqa_content_tall_thumb', 200);
        \add_image_size( 'ubiqa_single_head', 400, 200, true );

        \add_image_size( 'ubiqa_featured', 600, 400, true );
        \add_image_size( 'ubiqa_blog', 254, 200, true );
        \add_image_size( 'ubiqa_avatar', 400, 400, true );

        \add_filter('image_resize_dimensions', function($payload, $orig_w, $orig_h, $new_w, $new_h, $crop){
            if( $crop &&
                (
                    $new_h == 300 && $new_w == 550 ||
                    $new_h == 200 && $new_w == 254

                )


            ){
                if($new_w > $orig_w){
                    $aspect_ratio = $orig_w / $orig_h;
                    $size_ratio = max($new_w / $orig_w, $new_h / $orig_h);

                    $crop_w = round($new_w / $size_ratio);
                    $crop_h = round($new_h / $size_ratio);

                    $s_x = floor( ($orig_w - $crop_w) / 2 );
                    $s_y = floor( ($orig_h - $crop_h) / 2 );

                    return array( 0, 0, (int) $s_x, (int) $s_y, (int) $new_w, (int) $new_h, (int) $crop_w, (int) $crop_h );

                }
            }
        }, 10, 6);

        $this->setRoles();
    }



    function setRoles(){

        if(!get_role('ubiqa_content_manager')){
            $role = get_role("editor");

            $_role = add_role('ubiqa_content_manager', __("Gestor de contenido y rutas", "ubiqa"));
            foreach($role->capabilities as $cap=>$value){

                if(in_array($cap, array('manage_categories'.'manage_links'.'moderate_comments'))!==false){

                    $_role->add_cap($cap, false);

                }else{
                    $_role->add_cap($cap, $value);
                }


            }
        }


    }



    function setConfigurableOptions(array $config, array $custom){
        $this->_config_options = $config;
        $this->_custom_options = $custom;
    }


    function getCustomOption($key){
        return $this->_util->getArrayValue($key, $this->_custom_options);
    }

    function getConfigOption($key){
        return $this->_util->getArrayValue($key, $this->_config_options);
    }

    function getAvatarUrl(\WP_User $user){

        if($src = $this->getUserModel()->getUserAvatarUrlFromMediaLibrary($user, "ubiqa_avatar")){
            return $src;
        }


        \preg_match("/src='(.*?)'/i", get_avatar($user->ID), $matches);
        return isset($matches[1]) ? $matches[1] : null;



    }

    function getCustomStyles(){


        $style = "";
        if($this->_util->getArrayValue("h1_color", $this->_custom_options)){
            $style .= sprintf("h1{color:%s;}", $this->getCustomOption("h1_color"));
        }
        if($this->_util->getArrayValue("h2_color", $this->_custom_options)){
            $style .= sprintf("h2{color:%s;}", $this->getCustomOption("h2_color"));
        }
        if($this->_util->getArrayValue("h4_color", $this->_custom_options)){
            $style .= sprintf("h4{color:%s;}", $this->getCustomOption("h4_color"));
        }
        if($this->_util->getArrayValue("a_color", $this->_custom_options)){
            $style .= sprintf("a,a:hover{color:%s;}", $this->getCustomOption("a_color"));
        }
        if($this->_util->getArrayValue("button_color", $this->_custom_options)){
            $style .= sprintf(".btn.btn-primary{background-color:%s;border-color:%s}", $this->getCustomOption("button_color"), $this->getCustomOption("button_color"));
        }
        if($this->_util->getArrayValue("button_text_color", $this->_custom_options)){
            $style .= sprintf(".btn.btn-primary{color:%s;}", $this->getCustomOption("button_text_color"));
        }

       return $style;

    }



    function getPostTypeLabel($post_type){
        //Get post type
        $post_type_obj = get_post_type_object($post_type);
        //Get post type's label
        return apply_filters('post_type_archive_title', $post_type_obj->labels->name );
    }



    function getContentVideo($post_id, $width="100%", $height="430px"){
        $html = _u()->get("content")->getOEmbedHtml($post_id, "ubiqa_video_oembed_data", $width, $height);
        //$html = preg_replace('/( width)="[0-9]*"/i', "", $html);
        //$html = preg_replace('/(width)\:"[0-9]*"/i', "", $html);
        //$html = preg_replace('/(style)\:"[0-9]*"/i', "", $html);
        $html = str_replace("<iframe", "<iframe class='video' onload='update_grid' ", $html);

        return $html;

    }



    function getThumbUrl($post_id, $size){

        $url = wp_get_attachment_url( get_post_thumbnail_id($post_id), $size );

                if($url){
                    echo $url;
                }else{
                    return _u()->getDefaultImageSrc(get_the_ID());
                }


    }

    function getAuthorAvatar(\WP_Post $post){

        $avatar = $this->getUserModel()->getUserAvatarUrlFromMediaLibrary(\get_userdata($post->post_author), "ubiqa_avatar");


        return $avatar?:$this->getDefaultImageSrc($post->ID);
    }

    function getContentView($post_id, $in_container=false){

        if(_u()->get("content")->getMeta($post_id, "ubiqa_content_has_oembed")) {

            return _u()->get("content")->getMeta($post_id, "ubiqa_content_oembed");


        }else{

            if(_u()->get("content")->getMeta($post_id, "ubiqa_content_type") == "image")

                return get_the_post_thumbnail( $post_id, "full", array("class"=>"img-responsive") ) ;

            if(_u()->get("content")->getMeta($post_id, "ubiqa_content_type") == "video"){

                return $in_container ? ('<div class="video_container">'. _u()->getContentVideo($post_id) .'</div>') : _u()->getContentVideo($post_id);




            }

            if(_u()->get("content")->getMeta($post_id, "ubiqa_content_type") == "audio"){

                return _u()->getAudioTag($post_id);
            }

        }
    }

    function getContentThumb($post_id){

        $html="";

        if(_u()->get("content")->getMeta($post_id, "ubiqa_content_has_oembed")) {

            $html = _u()->get("content")->getMeta($post_id, "ubiqa_content_oembed");

            //$html = preg_replace('/( width)="[0-9]*"/i', "", $html);
            //$html = preg_replace('/(width)\:"[0-9]*"/i', "", $html);
            //$html = preg_replace('/(style)\:"[0-9]*"/i', "", $html);
            $html = str_replace("<iframe", "<iframe onload='update_grid' style='width:100%'", $html);

            return $html;


        }else {

            if (get_the_post_thumbnail($post_id)) {
                echo get_the_post_thumbnail($post_id);
            }
        }

    }

    function isPendingVimeoThumb($post_id){
        return _u()->get("content")->getMeta($post_id, "ubiqa_content_pending_thumbnail");
    }


    function getLanguages($iso_as_key=false){
        global $q_config;
        $_langs = \qtrans_getSortedLanguages();
        $langs = array();
        foreach($_langs as $iso){


            if($iso_as_key){
                $langs[$iso] = \qtrans_getLanguageName($iso);
            }else{
                $url = \qtrans_convertURL('', $iso, false, true);
                if(false===strpos($url, "change=")){
                    $url .= ( ( false===strpos($url, "?")?"?":"&" ) ."change=true");
                }


                $langs[$url] = \qtrans_getLanguageName($iso);
            }

        }
        return $langs;
    }

    function getLanguageArray(){
        global $q_config;
        $_langs = \qtrans_getSortedLanguages();
        $langs = array();
        foreach($_langs as $iso){
            $langs[$iso] = \qtrans_getLanguageName($iso);
        }
        return $langs;
    }

    function getUrl($url="/"){
        return $this->transUrl(\home_url($url));
    }

    function transUrl($url){
        return \qtrans_convertURL($url);
    }

    function getIconClass($post_id){

       switch($this->get("content")->getMeta($post_id, "ubiqa_content_type")){

           default:
               return "file";

           case 'video':
               return "video";
           break;

           case 'audio':
               return "sound";
           break;

           case 'image':
               return "camera";



       }



    }

    function getDefaultImageSrc($post_id){

        switch($this->get("content")->getMeta($post_id, "ubiqa_content_type")){


            case 'video':
                return get_template_directory_uri()  . "/images/defaults/video_place.png";
                break;

            case 'audio':
                return get_template_directory_uri()  . "/images/defaults/audio_place.png";
                break;

            case 'image':
                return get_template_directory_uri()  . "/images/defaults/photo_place.png";



        }

        if(get_post_type($post_id) == "route"){
            return get_template_directory_uri()  . "/images/defaults/ruta_place.png";
        }


            return get_template_directory_uri()  . "/images/defaults/post_place.png";



    }


    /**
     * Add breadcrumbs functionality to your WordPress theme
     *
     * Once you have included the function in your functions.php file
     * you can then place the following anywhere in your theme templates
     * if(function_exists('bavota_breadcrumbs')) bavota_breadcrumbs();
     *
     * @c.bavota - http://bavotasan.com
     */
    function bavota_breadcrumbs() {
        if(!is_home()) {
            echo '<nav class="breadcrumb">';
            echo '<a href="'.home_url('/').'">'.get_bloginfo('name').'</a><span class="divider">/</span>';
            if (is_category() || is_single()) {
                the_category(' <span class="divider">/</span> ');
                if (is_single()) {
                    echo ' <span class="divider">/</span> ';
                    the_title();
                }
            } elseif (is_page()) {
                echo the_title();
            }
            echo '</nav>';
        }
    }


    function getAudioTag($post_id){


        $src = _u()->get("content")->getMeta($post_id, "ubiqa_content_content_url");


        //eliminamos el idioma de la url por si la modifica un plugin
        if(false!==strpos($src, qtrans_getLanguage() . "/")){

        	$src = str_replace("/" . qtrans_getLanguage() . "/", "/", $src);
        }




        $html5 = <<<HTML
                <audio controls>
                    <source src="{{url}}" type="{{mime}}">
                </audio>
HTML;
;

        $html = <<<HTML
<div class="audio" style="padding: 20px; text-align: center">
  <a href="{{url}}" class="btn btn-default">
  <span class="glyphicon glyphicon-volume-up"></span>
 {{text}}</a>
</div>

HTML;
;




        if(false !== strpos($src, ".mp3")){
            $html5 = str_replace("{{url}}", $src, $html5);
            return str_replace("{{mime}}", "audio/mpeg", $html5);
        }else if(false !== strpos($src, ".mp4") || false !== strpos($src, ".m4a") || false !== strpos($src, ".aac")){
            $html5 = str_replace("{{url}}", $src, $html5);
            return str_replace("{{mime}}", "audio/mp4", $html5);
        }else{
            $fallback = str_replace("{{url}}", $src, $html);
            return str_replace("{{text}}", __("escuchar audio", "ubiqa"), $fallback);
        }

    }




} 
