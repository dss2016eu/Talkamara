jQuery(document).ready(function($){

    var grid = $("#user_grid");

    var spiner = $("#user_loading");

    var user_page = 1;

    var _user_count=0;

    var fgrid = $("#fav_grid");

    var fspiner = $("#fav_loading");

    var fuser_page = 1;

    var f_user_count=0;







    function getContent(self){
        $.get(window.user_url, {user_id: window.user_id, _page: user_page}, function(data){

            var items = $(data);
            user_page++;

            if(!data || _user_count < user_page){
                $(self).fadeOut();
            }

            imagesLoaded(items, function() {
                grid.append(items).masonry("appended", items).masonry('layout');
            });

            spiner.fadeOut();
            $(self).removeAttr("disabled");

        });
    }

    function getFavsContent(self){
        $.get(window.user_favs_url, {user_id: window.user_id, _page: fuser_page}, function(data){

            var items = $(data);
            fuser_page++;

            if(!data || f_user_count < fuser_page){
                $(self).fadeOut();
            }

            imagesLoaded(items, function() {
                fgrid.append(items).masonry("appended", items).masonry('layout');
            });

            fspiner.fadeOut();
            $(self).removeAttr("disabled");

        });
    }

    $("#user_load_more").click(function(){

        var self = this;
        $(self).attr("disabled", "disabled");
        spiner.show();

        if(!_user_count){

            $.getJSON(window.user_url, {q: window.search, count:true}, function(data) {
                _user_count = data;
                getContent(self);
            })

        }else if(_user_count >= user_page){

            getContent(self);

        }else{
            $(self).fadeOut();
        }




    }).trigger("click");


    $("#fav_load_more").click(function(){

        var self = this;
        $(self).attr("disabled", "disabled");
        fspiner.show();

        if(!f_user_count){

            $.getJSON(window.user_favs_url, {q: window.search, count:true}, function(data) {
                f_user_count = data;
                getFavsContent(self);
            })

        }else if(f_user_count >= fuser_page){

            getFavsContent(self);

        }else{
            $(self).fadeOut();
        }




    }).trigger("click");

});
