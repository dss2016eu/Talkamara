function update_grid(){



    setTimeout(function(){
        jQuery('#posts').isotope('layout');
    }, 10000);



};



jQuery(document).ready(function($){





    if($('.owl-carousel').html()) {


        var carousel = $('.owl-carousel');
        if (carousel.children().length > 1){
            carousel.owlCarousel({
                // autoplay:true,
                // autoplayTimeout:5000,
                smartSpeed:1000,
                loop:true,
                margin:0,
                // nav:true,
                // navText: ["",""],
                items: 1
            });
            $("#carousel .move.next").on('click', function(){
                carousel.trigger("next.owl.carousel");
            });
            $("#carousel .move.prev").on('click', function(){
                carousel.trigger("prev.owl.carousel");
            });
        } else {
            carousel.addClass('owl-theme owl-loaded one-elem');
        }












    }

    if($("#content_grid").attr("id") && window.is_home){


        //portada contenido
        var grid   = $("#content_grid");
        var spiner = $(".spinner");



        var content = new ContentManager(
            grid,
            null,
            window.contents_ajax_url,
            null,
            null,
            null,
            spiner );



        $("#load_more").click(function(e){
            content.reload([{name: "is_home", value: true}], this);
        }).trigger("click");
    }



    $("#language_select").change(function(){

        window.location.href = $(this).val();

    });


    $(document).on("click",".like-item", function(e){


        e.preventDefault();


        var url = $(this).attr("data-url-rel");
        var self  = $(this);

        var target_icon = self;
        if(self.hasClass("icon_in_i")){
            target_icon = self.find("i");
        }

        $.getJSON(url, function(data){


            self.parent().find(".like-count").html(data.count);
            if(data.is_fav){
                target_icon.removeClass("fa-heart-o").fadeOut('fast', function(){
                    $(this).addClass("fa-heart").fadeIn();
                });
            }else{
                target_icon.removeClass("fa-heart").fadeOut('fast', function(){
                    $(this).addClass("fa-heart-o").fadeIn();
                });
            }

        });

    });

    $(document).on("click",".fav-item",function(e){


        var url = $(this).attr("data-url-rel");
        var self  = $(this);



        $.getJSON(url, function(data){

            var target_icon = self;
            if(self.hasClass("icon_in_i")){
                target_icon = self.find("i");
            }

            self.parent().find(".fav-count").html(data.count);
            if(data.is_fav){
                target_icon.removeClass("fa-star-o").fadeOut('fast', function(){
                    $(this).addClass("fa-star").fadeIn();
                });
            }else{
                target_icon.removeClass("fa-star").fadeOut('fast', function(){
                    $(this).addClass("fa-star-o").fadeIn();
                });
            }

        });

    });







    if(typeof google != 'undefined' && google.maps){

        var map_places = window.positions || [];
        var map        = null;

        var map_initialize = function() {

            var LatLng = new google.maps.LatLng(37.3772, -5.9869);

            var mapOptions = {
                zoom: 4,
                disableDefaultUI: true,
                zoomControl: true,
                zoomControlOptions: {
                    position: google.maps.ControlPosition.RIGHT_CENTER
                },
                scrollwheel: false,
                center: LatLng,
                mapTypeId: google.maps.MapTypeId.ROADMAP
            };

            map = new google.maps.Map(document.getElementById('map_container'), mapOptions);
            map.setZoom(14);

            for(var i in map_places){
                if(map_places[i].lat){


                    (function(){


                                var post_id = map_places[i].id;
                                var position = new google.maps.LatLng(map_places[i].lat, map_places[i].lon);

                                google.maps.event.addListener(new google.maps.Marker({

                                    position: position,
                                    map: map,
                                    title: map_places[i].lat.toString()

                                }), 'click', function() {


                                    $.ajax({
                                        url:  ajaxurl,
                                        type: 'POST',
                                        data: {action: 'ubiqa.content.singlecontent', id: post_id},
                                        dataType: 'json',
                                        success: function(item){

                                            var content = $('#modal_content');

                                            content.find(".title").first().html(item.title);
                                            content.find(".content").first().html(item.content);
                                            content.find(".link").first().attr("href", item.link);

                                            var embed = content.find(".content_prev_html").first();

                                            switch (item.type){

                                                case 'video':

                                                    embed.html(item.embed_html);

                                                    break;


                                                case 'image':

                                                    embed.html(item.thumb_html);

                                                    break;

                                                case 'audio':

                                                    embed.html(item.audio_html);


                                            }



                                            $('#modal_content').modal('show');
                                        }
                                    });







                                });
                    })();


                }
            }

            map_adjustPosition();

        };

        map_adjustPosition = function () {
            var lat = 0, lng = 0;

            if (map_places.length == 0) {
                return false;
            }

            //  Make an array of the LatLng's of the markers you want to show
            var LatLngList = [];

            for(var i in map_places){

               LatLngList[i] = new google.maps.LatLng (map_places[i].lat, map_places[i].lon)

            }

//  Create a new viewpoint bound
            var bounds = new google.maps.LatLngBounds ();
//  Go through each...
            for (var i = 0, LtLgLen = LatLngList.length; i < LtLgLen; i++) {
                //  And increase the bounds to take this point
                bounds.extend (LatLngList[i]);
            }
//  Fit these bounds to the map
            map.fitBounds (bounds);


        };

        map_initialize();



    }



    $(".container").fitVids();

});
