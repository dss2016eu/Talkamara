jQuery(document).ready(function($){

    var grid = $("#search_grid");

    var spiner = $("#loading");

    var page = 1;

    var _count=0;






    function getContent(self){
        $.get(window.search_url, {q: window.search, _page: page}, function(data){

            var items = $(data);
            page++;

            if(!data || _count < page){
                $(self).fadeOut();
            }

            imagesLoaded(items, function() {
                grid.append(items).masonry("appended", items).masonry('layout');
            });

            spiner.fadeOut();
            $(self).removeAttr("disabled");

        });
    }

    $("#load_more").click(function(){

        var self = this;
        $(self).attr("disabled", "disabled");
        spiner.show();

        if(!_count){

            $.getJSON(window.search_url, {q: window.search, count:true}, function(data) {
                _count = data;
                getContent(self);
            })

        }else if(_count >= page){

            getContent(self);

        }else{
            $(self).fadeOut();
        }




    }).trigger("click");




});
