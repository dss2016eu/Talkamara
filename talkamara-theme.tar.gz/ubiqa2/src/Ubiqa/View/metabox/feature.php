<p>
    <label>
        <input <?php if($this->_model->getMeta($post->ID, \Ubiqa\Model\ContentModel::META_FEATURE_CONTENT)) echo "checked" ?>
            type="checkbox"
            value="1"
            name="ubiqa_feature[content]"> <?php _e("Contenido destacado", "ubiqa") ?>
    </label>
</p>

<p>
    <label>
        <input <?php if($this->_model->getMeta($post->ID, \Ubiqa\Model\ContentModel::META_FEATURE_SLIDER)) echo "checked" ?>
            type="checkbox"
            value="1"
            name="ubiqa_feature[slider]"> <?php _e("Contenido en carousel de portada", "ubiqa") ?>
    </label>
</p>