<?php
/**
 * Created by PhpStorm.
 * User: Asier
 * Date: 30/07/14
 * Time: 21:51
 */

get_header();

$form = _u()->get("form");

$step = 2;

?>



    <div class="bg-white-2">
        <ul class="breadcrumb container inline">
            <li class="breadcrumb-item"><a href="<?php echo _u()->getUrl() ?>"><?php _e("inicio", "ubiqa") ?></a></li>
            <li class="breadcrumb-item"><a href="<?php echo CONTENTS_URL ?>"><?php _e("contenido", "ubiqa") ?></a></li>
            <li class="breadcrumb-item"><?php _e("nuevo contenido", "ubiqa") ?></li>
        </ul>
    </div>


    <section class="bg-white-2" id="new-content">

        <form method="post" action="" enctype="multipart/form-data">

            <div class="container bg-white">


                <?php include 'newSteps.php' ?>

                <div class="air bg-white-1 new-content-sub">
                    <div class="new-content-sub">

                        <div class="grid">
                            <div class="col-s-12 col-m-6 air-r no-air-s-h">
                                <div class="form-field">
                                    <label for=""><?php _e("CIUDAD", "ubiqa") ?></label>
                                    <?php echo $form["city"]->getInputTag() ?>
                                </div>
                            </div>
                            <div class="col-s-12 col-m-12 col-l-12">
                                <div class="form-field">
                                    <label for=""><?php _e("DIRECCIÓN", "ubiqa") ?></label>
                                    <?php echo $form["address"]->getInputTag() ?>
                                </div>
                            </div>
                        </div>
                        <br>
                        <div class="bg-white-2">
                            <div id="map_container" style="height: 400px"></div>
                        </div>

                        <div class="grid air-t">
                            <div class="col-s-12 col-m-6 air-r no-air-s-h">
                                <div class="form-field-l form-field-m">
                                    <label for="" class="col-s-12 col-m-4 txt-right"><?php _e("LATITUD", "ubiqa") ?></label>
                                    <?php echo $form["lat"]->getInputTag() ?>
                                </div>
                            </div>
                            <div class="col-s-12 col-m-6 air-l no-air-s-h">
                                <div class="form-field-l form-field-m">
                                    <label for="" class="col-s-12 col-m-4 txt-right"><?php _e("LONGITUD", "ubiqa") ?></label>
                                    <?php echo $form["lon"]->getInputTag() ?>
                                </div>
                            </div>
<?php if(_u()->getConfigOption("has_routes")){ ?>

                            <div class="col-s-12 col-m-6 air-r no-air-s-h">
                                <div class="form-field-l form-field-m">
                                    <label for="" class="col-s-12 col-m-4 txt-right"><?php _e("RUTA", "ubiqa") ?></label>
                                    <?php echo $form["route"]->getInputTag() ?>
                                </div>
                            </div>
                            <div class="col-s-12 col-m-6 air-l no-air-s-h">
                                <div class="form-field-l form-field-m">
                                    <label for="" class="col-s-12 col-m-4 txt-right"><?php _e("POSICIÓN RUTA", "ubiqa") ?></label>
                                    <?php echo $form["route_position"]->getInputTag() ?>
                                </div>
                            </div>
<?php } ?>
                        </div>


                    </div>

                </div>



                <div class="new-content-sub air-v txt-right">
                    <button type="submit" class="btn-rounded" ><?php _e("Siguiente", "ubiqa") ?></button>
                </div>
            </div>

        </form>

    </section>




<?php
get_footer();