jQuery(document).ready(function($){

    var grid = $("#project_grid");

    var spiner = $("#loading");

    var page = 1;

    var order  = "date";

    var _count=0;



    $("#order_selector").change(function(){

        grid.html("");
        order = $(this).val();
        grid.masonry("reloadItems").masonry('layout');
        page = 1;

        $("#load_more").trigger("click");

    });


    function getContent(self){
        $.get(window.posts_url, {_page: page, _order: order}, function(data){

            var items = $(data);
            page++;

            if(!data || _count < page){
                $(self).fadeOut();
            }

            imagesLoaded(items, function() {
                grid.append(items).masonry("appended", items).masonry('layout');
            });

            spiner.fadeOut();
            $(self).removeAttr("disabled");

        });
    }

    $("#load_more").click(function(){

        var self = this;
        $(self).attr("disabled", "disabled");
        spiner.show();

        if(!_count){

            $.getJSON(window.posts_url, {_page: page, _order: order, count:true}, function(data) {
                _count = data;
                getContent(self);
            })

        }else if(_count >= page){

            getContent(self);

        }else{
            $(self).fadeOut();
        }




    }).trigger("click");




});
