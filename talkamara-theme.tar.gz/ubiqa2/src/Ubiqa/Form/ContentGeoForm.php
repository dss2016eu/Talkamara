<?php
/**
 * Created by PhpStorm.
 * User: Asier
 * Date: 5/08/14
 * Time: 12:50
 */

namespace Ubiqa\Form;

use SimpleForm\AbstractForm;
use SimpleForm\FormBuilder;
use Symfony\Component\Validator\Constraints\Email;
use Symfony\Component\Validator\Constraints\NotBlank;
use Symfony\Component\Validator\Constraints\NotNull;
use Symfony\Component\Validator\Constraints\Length;
use Ubiqa\Model\ContentModel;

class ContentGeoForm extends AbstractForm{

    private $_routes = array();

    public  $geo_required = true;

    function __construct($data=array(), FormBuilder $builder, $routes=array(), $is_edit=false){

        $this->geo_required = !$is_edit;
        $this->_routes = array(0=>__("Ninguna ruta seleccionada", "ubiqa"));

        //$this->_routes[0] = "";
        foreach($routes as $route){
            $this->_routes[$route->ID] = get_the_title($route);
        }

        parent::__construct($data, $builder);



    }


    function setValues(\WP_Post $post, ContentModel $model){

        $this["city"]->setValue($model->getMeta($post->ID, "ubiqa_content_city"));
        $this["address"]->setValue($model->getMeta($post->ID, "ubiqa_content_address"));
        $this["lat"]->setValue($model->getMeta($post->ID, "ubiqa_content_lat"));
        $this["lon"]->setValue($model->getMeta($post->ID, "ubiqa_content_lon"));
        $this["route"]->setValue($model->getMeta($post->ID, "ubiqa_content_route"));
        $this["route_position"]->setValue($model->getMeta($post->ID, "ubiqa_content_route_position", 0));

    }


    function configure(){


        $this->setName("content_geo");

        $builder = $this->getBuilder();

        $cities = array(0=>"");
        foreach(get_posts(array("post_type"=>"city", "posts_per_page"=>-1)) as $city){
            $cities[$city->ID] = (get_the_title($city). ", ".get_post_meta($city->ID, "ubiqa_content_country", true) );
        }

        $builder->add("city", "choice", array("label"=> __("Ciudad", "ubiqa"),
            "choices"=>$cities, "class"=>"form-control geo_input", "required"=>false));
        /*$builder->add("country", "text", array(
            "label"=> __("País", "ubiqa"), "class"=>"form-control geo_input", "required"=>false));*/
        $builder->add("address", "textarea", array(
            "label"=> __("Dirección", "ubiqa"),
            "class"=>"form-control geo_input",
            "required"=>false));


        $builder->add("lat", "text", array("label"=> __("Latitud", "ubiqa"), "class"=>"form-control"));
        $builder->add("lon", "text", array("label"=> __("Longitud", "ubiqa"), "class"=>"form-control"));

        $builder->add("route_position", "input", array( "type"=>"number", "label"=> __("Posición en la ruta", "ubiqa"), "class"=>"form-control", "required"=>false));
        $builder->add("route", "choice", array(
            "choices" => $this->_routes, "label"=> __("Ruta", "ubiqa"), "class"=>"form-control",
            "required"=>false));



    }

    /**
     * @param \WP_Post $post
     * @param ContentModel $model
     * @return \WP_Post
     */
    function save(\WP_Post $post, ContentModel $model){





        $metas = array(
            "ubiqa_content_city"            => $this["city"]->getValue(),
            "ubiqa_content_address"         => $this["address"]->getValue(),
            "ubiqa_content_route"           => $this["route"]->getValue(),
            "ubiqa_content_route_position"  => $this["route_position"]->getValue(),
            "ubiqa_content_lat"             => $this["lat"]->getValue(),
            "ubiqa_content_lon"             => $this["lon"]->getValue()
        );

        if(!$this["lat"]->getValue() && !$this["lon"]->getValue() && $this["city"]->getValue()){
            $city = $this["city"]->getValue();
            $metas["ubiqa_content_lat"] = $model->getMeta($city, "ubiqa_content_lat");
            $metas["ubiqa_content_lon"] = $model->getMeta($city, "ubiqa_content_lon");
        }

        $model->updateMetas($post, $metas);

        return $post;
    }

} 