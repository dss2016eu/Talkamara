<?php
/**
 * Created by PhpStorm.
 * User: Asier
 * Date: 16/04/14
 * Time: 17:01
 */

namespace Ubiqa\Authenticator;

class FacebookAuthenticator implements AuthenticatorInterface {

    protected $client;
    protected $oauth;
    protected $redirect_url;
    protected $user_id, $email;
    protected $user;
    protected $storage;

    private $login_url;

    function __construct($params=array(),
                         UserTokenStorage $storage){

        $this->redirect_url = $params["redirect_uri"];
        $this->storage      = $storage;

        $this->client = new \Facebook($params);



    }

    function setRedirectUrl($url){
        $this->redirect_url = $url;
    }

    function setAvatar($user){
        $url = sprintf("https://graph.facebook.com/%d/picture?redirect=false&type=large", \get_user_meta($user->ID, "facebook_user_id"));
        $_raw = file_get_contents($url);
        if($avatar = json_decode($_raw)){
            if(isset($avatar->data) && !$avatar->data->is_silhouette){
                \update_user_meta( $user->ID, 'user_thumb', $avatar->data->url );
            }
        }
    }

    function getEmail(){
        return $this->email;
    }

//    function setAccessToken($token){
//        $this->client->setAccessToken($token);
//        if($this->client->isAccessTokenExpired()){
//
//
//
//            $token = json_decode($token, true);
//            $refresh_token = $token["refresh_token"];
//
//            try{
//
//                $this->client->refreshToken($refresh_token);
//                $user_id = $this->isAuthenticated();
//                $this->persistToken($user_id, $this->client->getAccessToken());
//
//            }catch(\Exception $e){
//
//                return;
//            }
//
//        }
//
//
//        $this->isAuthenticated();
//    }

    function persistToken($user_id, $token){
        $this->storage->setTokenToUser($user_id, $token, "facebook");
    }

    function isAuthenticated(){
        if(!$this->user_id){
            $this->user_id = $this->client->getUser();
            if($this->user_id){
                $social_user = $this->client->api('/me','GET');

                $this->email   = isset($social_user["email"]) ? $social_user["email"] : null;
            }

        }
        return $this->user_id;
    }


    function getUser(){
        return $this->user ? $this->user : $this->user = $this->storage->getUserByEmail($this->email);
    }

    function authenticate($_oauth_code=null){

        $is_auth = $this->isAuthenticated();

        if($user = $this->getUser()){
            $this->storage->setTokenToUser($user->ID, $this->client->getAccessToken(), "facebook", $this->user_id);
        }

        return $is_auth;

    }


    function getAuthUrl(){
        return $this->client->getLoginUrl(array("redirect_uri"=>$this->redirect_url, "scope"=>"email"));
    }





} 