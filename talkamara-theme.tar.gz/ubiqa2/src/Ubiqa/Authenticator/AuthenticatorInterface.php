<?php
/**
 * Created by PhpStorm.
 * User: Asier
 * Date: 16/04/14
 * Time: 16:59
 */

namespace Ubiqa\Authenticator;


interface AuthenticatorInterface {

    function authenticate($_oauth_code=null);

    function setRedirectUrl($url);

    function isAuthenticated();

    function getUser();

    function getAuthUrl();

} 