<?php get_header() ?>


    <div class="bg-white-2">
        <ul class="breadcrumb container inline">
            <li class="breadcrumb-item"><a href="<?php echo _u()->getUrl() ?>"><?php _e("inicio", "ubiqa") ?></a></li>
            <li class="breadcrumb-item"><?php _e("contenidos", "ubiqa") ?></li>
        </ul>
    </div>

    <?php include 'includes/content-filter.php' ?>

    <div class="spinner"  style="display: none"><div></div></div>
    <!-- /aside -->


    <div data-tabs="content-main">

        <div class="container flx-h tabs-container">
            <div class="flx-1"></div>
            <div class="tab fa fa-th active" data-tab-show="content-cards"> <span class="hide-s"><?php _e("Ver en grid", "ubiqa") ?></span></div>
<?php  if(_u()->getConfigOption("has_geo")){ ?>
            <div class="tab fa fa-map-marker" data-tab-show="content-map"> <span class="hide-s"><?php _e("Ver en mapa", "ubiqa") ?></span></div>
<?php } ?>
        </div>

        <section class="bg-white-1" data-tab-content="content-map" style="display: none">

            <article id="map_wrapper" class="app-content container">

                <div id="map_content_preview" class="content-info"  style="display: none">
                </div>

                <div class="content-map">
                    <div id="map" class="content-right-map"></div>
                </div>


            </article>

        </section>

        <section class="bg-white-1" data-tab-content="content-cards">

            <div class="container">

                <div id="content_grid" class="grid masonry cards"></div>

                <div class="air">
                    <div class="spinner" style="display: none"><div></div></div>
                    <button id="load_more" class="btn-default full-w"><?php _e("Cargar más", "ubiqa") ?></button>
                </div>

            </div>



        </section>
    </div>


    <script type="text/javascript">

        var contents_map_ajax_url =  "<?php echo _u()->genUrl("ajax_content_items", array("map_json"=>true)) ?>";
        var preview_ajax_url =  "<?php echo _u()->genUrl("ajax_content_mapitem") ?>";
        var topic_ajax_ids_url = "<?php echo _u()->genUrl("ajax_content_topic_ids") ?>";



    </script>

<?php get_footer() ?>