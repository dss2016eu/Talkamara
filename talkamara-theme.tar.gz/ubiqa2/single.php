<?php get_header();  if ( have_posts() ) { while ( have_posts() ) { the_post();   ?>

    <section class="bg-white">

        <div class="container grid air-b">
            <div class="col-s-12 col-m-8 col-l-9">
                <div class="container">
                    <div class="flx-h-m">
                        <div class="flx-1">
                            <h1><?php the_title() ?></h1>
                        </div>
                        <div>
                            <?php include 'includes/single-share.php' ?>
                        </div>
                    </div>
                </div>
                <hr>
                <div class="txt-big">
                    <?php the_content() ?>
                </div>
            </div>
            <div class="col-s-12 col-m-4 col-l-3 txt-center air-b">
                <div class="form-blocks no-margin-r-l">


                    <?php
                    $list = get_the_term_list(get_the_ID(), "category", '<ul class="tags-borderer txt-center inline"><li class="tag">', '</li><li class="tag">', '</li></ul>' );

                    if($list){
                        ?>

                        <div class="form-block">
                            <?php _e("CATEGORÍAS", "ubiqa") ?><hr><?php echo $list ?>
                        </div>
                    <?php } ?>




                    <?php
                    $list = get_the_term_list(get_the_ID(), "topic", '<ul class="tags-borderer txt-center inline"><li class="tag">', '</li><li class="tag">', '</li></ul>' );

                    if($list){
                        ?>

                        <div class="form-block">
                            <?php _e("TEMAS", "ubiqa") ?><hr><?php echo $list ?>
                        </div>
                    <?php } ?>

                </div>
            </div>
            <div class="bg-white air-t air-b container grid border-t border-b col-12">
                <div class="float-left previous-post">
                    <?php next_post_link('%link','<i class="fa fa-chevron-left"></i> %title'); ?>
                </div>
                <div class="float-right next-post">
                    <?php previous_post_link('%link','%title <i class="fa fa-chevron-right"></i>'); ?>
                </div>
            </div>
        </div>
    </section>


    <?php $post_id = get_the_ID(); include 'includes/comments.php' ?>


<?php }} get_footer() ?>