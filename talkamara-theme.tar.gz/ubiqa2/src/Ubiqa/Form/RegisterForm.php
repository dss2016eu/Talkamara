<?php
/**
 * Created by PhpStorm.
 * User: Asier
 * Date: 5/08/14
 * Time: 12:50
 */

namespace Ubiqa\Form;

use Sense\Model\UserModel;
use SimpleForm\AbstractForm;
use Symfony\Component\Validator\Constraints\Callback;
use Symfony\Component\Validator\Constraints\Email;
use Symfony\Component\Validator\Constraints\NotBlank;
use Symfony\Component\Validator\Constraints\NotNull;
use Symfony\Component\Validator\Constraints\Length;
use Symfony\Component\Validator\ConstraintViolation;
use Symfony\Component\Validator\Context\ExecutionContextInterface;

class RegisterForm extends AbstractForm{

    /**
     * @var UserModel
     */
    private $_model;

    function setModel(UserModel $model){
        $this->_model = $model;
    }


    function checkUsernameAvailableCallback($value, ExecutionContextInterface $context){


        $user = $this->_model->getUserBy("login", $value);

        if($user instanceof \WP_User){
            $context->getViolations()->add(
              new ConstraintViolation(__("El nombre de usuario está en uso", "ubiqa"), "", array(), "root", "login", $value)
            );
        }

    }

    function checkEmailAvailableCallback($value, ExecutionContextInterface $context){



        $user = $this->_model->getUserByEmail( $value);
        if($user instanceof \WP_User){
            $context->getViolations()->add(
                new ConstraintViolation(__("El email está en uso", "ubiqa"), "", array(), "root", "email", $value)
            );
        }

    }

    function configure(){

        $this->setName("register");

        $builder = $this->getBuilder();
        $builder->add("login", "text", array("label"=>__("Nombre de inicio de sesión", "ubiqa"), "class"=>"form-control", "validators"=>array(
            new Callback(array("callback" => array($this, "checkUsernameAvailableCallback")))
        )));
        $builder->add("first_name", "text", array("label"=>__("Nombre", "ubiqa"), "class"=>"form-control",
            "validators"=>array(new  NotBlank(), new Length(array("min"=>3)
        ))));
        $builder->add("last_name", "text", array(
            "label"=>__("Apellidos", "ubiqa"),
            "class"=>"form-control",
            "validators"=>array(new  NotBlank(), new Length(array("min"=>3)
        ))));
        $builder->add("user_email", "input", array(
            "label"=>__("Email", "ubiqa"),
            "type"=>"email",
            "class"=>"form-control",
            "required"=>true,
            "validators"=> array(
                new NotNull(),
                new Email(),
                new Callback(array("callback"=>array($this, "checkEmailAvailableCallback")))
        )));
        $builder->add("password", "input", array("type"=>"password", "label"=>__("Contraseña", "ubiqa"), "class"=>"form-control"));
        $builder->add("password_repeat", "input", array("type"=>"password", "label"=>__("Repetir contraseña", "ubiqa"), "class"=>"form-control"));


        $builder->add("accept_tos", "input", array("type"=>"checkbox", "value"=>1, "style"=>"height:auto"));

    }

} 