<?php
/**
 * Created by PhpStorm.
 * User: Asier
 * Date: 16/04/14
 * Time: 17:27
 */

namespace Ubiqa;


use Sense\Model\UserModel;
use Symfony\Component\HttpFoundation\Request;
use Ubiqa\Authenticator\AuthenticatorInterface;
use Ubiqa\Authenticator\FacebookAuthenticator;
use Ubiqa\Authenticator\GoogleAuthenticator;
use Ubiqa\Authenticator\TwitterAuthenticator;
use Ubiqa\Authenticator\UserTokenStorage;
use Ubiqa\Model\AdminModel;

class WPMultiLogin {



    protected $request;
    protected $storage;
    protected $db;
    protected $base_redirect_url;
    /**
     * @var \Sense\Model\UserModel
     */
    private $userModel;

    private $fb, $google, $twitter;


    /**
     * @var AuthenticatorInterface
     */
    protected $authenticator;

    /**
     * @var AdminModel
     */
    protected $adminModel;


    function __construct($wpdb, UserModel $userModel, $base_redirect, AdminModel $adminModel){

        $this->request = Request::createFromGlobals();
        $this->db      = $wpdb;
        $this->storage = new UserTokenStorage($this->db);
        $this->base_redirect_url = $base_redirect;

        $this->adminModel = $adminModel;

        $this->fb      = $this->createFacebookAuthenticator();
        $this->google  = $this->createGoogleAuthenticator();
        $this->twitter = $this->createTwitterAuthenticator();

        $this->userModel = $userModel;


    }





    function createGoogleAuthenticator(){

        $data = $this->adminModel->getConfigOptions();

        return new GoogleAuthenticator(
            $data["google_api_app_name"],
            $data["google_api_client_id"],
            $data["google_api_client_secret"],
            ($this->base_redirect_url . "?__oauth_back=google"),
            $data["google_api_developer_key"],
            new UserTokenStorage($this->db)
        );

        /*return new GoogleAuthenticator(
            "ubiqa",
            "625341740608-q5p8mqj8qh40p6lfo82gukvra5f6av5n.apps.googleusercontent.com",
            "HNj48Ir5T45ZBMC3o8LP6Rqg",
            ($this->base_redirect_url . "?__oauth_back=google"),
            "AIzaSyApVYCeS3DKcP6UHi6tAHqSVvYmaUfKFbA",
            new UserTokenStorage($this->db)
        );*/
    }

    function createFacebookAuthenticator(){

        $data = $this->adminModel->getConfigOptions();
        return new FacebookAuthenticator(array(
            'appId'  => $data["facebook_api_appid"],
            'secret' => $data["facebook_api_secret"],
            'redirect_uri'       =>  ($this->base_redirect_url . '?__oauth_back=facebook'),
            'allowSignedRequest' => false // optional but should be set to false for non-canvas apps
        ), new UserTokenStorage($this->db));

    }

    function createTwitterAuthenticator(){

        $data = $this->adminModel->getConfigOptions();
        return new TwitterAuthenticator(
            $data["twitter_api_consumer_key"],
            $data["twitter_api_consumer_secret"],
            ($this->base_redirect_url . "?__oauth_back=twitter"),
            new UserTokenStorage($this->db)
        );
    }

    private function forceLogin(\WP_User $user){
        wp_set_current_user( $user->ID, $user->user_login );
        wp_set_auth_cookie( $user->ID );
        do_action( 'wp_login', $user->user_login );
    }

    private function createUserByEmail($email){

        $parts    = explode("@", $email);
        $username = ($parts[0] . time());

        $random_password = wp_generate_password( $length=12, $include_standard_special_chars=false );

        $user = $this->userModel->createAndRegister($username, $random_password, $email);

        wp_new_user_notification( $user->ID, $random_password );

        return $user;


    }

    function loginListener(){
        if($this->request->get("__oauth_back")){

            ini_set("display_errors", 1);
            $auth = null;

            switch($this->request->get("__oauth_back")){
                case 'google':

                    if($this->request->get("code")){
                        $auth = $this->google;

                        $auth->authenticate($this->request->get("code"));
                    }

                break;

                case 'twitter':

                    if($this->request->get("oauth_verifier")){
                        $auth = $this->twitter;

                        $auth->authenticate($this->request->get("oauth_verifier"));
                    }

                    break;

                case 'facebook':


                        $auth = $this->createFacebookAuthenticator();
                        $auth->authenticate("");


                break;
            }


            if(!$auth) return;
            
            if($auth->isAuthenticated()){




                if($this->request->get("__oauth_back") == "twitter" && !$auth->getUser()){
                    $_SESSION["twitter_user_id"] = $auth->getId();

                    return "twitter_email_required";
                }
                if(!$user = $auth->getUser()){

                    $user = $this->createUserByEmail($auth->getEmail());
                }

                if($auth instanceof FacebookAuthenticator && !\get_user_meta( $user->ID, 'user_thumb')){
                    $auth->setAvatar($user);
                }

                $this->forceLogin($user);

                $url_redirect = $this->getRedirectToInSession() ?:"/";
                wp_redirect($url_redirect);
                exit();

            }


        }
    }

    function removeTwitterSessionVariables(){
        unset($_SESSION["twitter_user_id"]);
    }

    function setTwitterIdToEmailUser($email, $user_id){

        $auth = $this->twitter;

        if($user = $this->userModel->getUserByEmail($email)){
            $this->forceLogin($user);
        }else{
            $user = $this->createAndLoginUser($email);
        }

        $auth->setSocialIdToUser($user, $user_id);
    }

    function createAndLoginUser($email){
        $user = $this->createUserByEmail($email);

        $this->forceLogin($user);

        return $user;
    }

    function setAuthenticator(AuthenticatorInterface $auth){
        $this->authenticator = $auth;
    }

    function getUser(){
       return  $this->authenticator->getUser();
    }

    function setRedirectToInSession($to){
        if(!$to){
            unset($_SESSION["oauth_redirect_to"]);
        }else{
            $_SESSION["oauth_redirect_to"] = $to;
        }

    }

    function getRedirectToInSession(){
        return isset($_SESSION["oauth_redirect_to"]) ? $_SESSION["oauth_redirect_to"] : null;


    }

    function getLoginUrl($service){

        switch($service){
            case 'google':
                $this->authenticator = $this->google;
            break;
            case 'facebook':
                $this->authenticator = $this->fb;
            break;
            case "twitter":
                $this->authenticator = $this->twitter;
        }


       return  $this->authenticator->getAuthUrl();
    }






} 