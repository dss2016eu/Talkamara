<div class="col-m-6 col-l-3">
    <div class="card">
        <div class="card-image  lazy-img ">
            <?php

            if($thumb = get_the_post_thumbnail(get_the_ID(),"ubiqa_blog_thumb", array("data-aspect-ratio"=>"1"))){
                echo $thumb;
            }else{ ?>
                <img src="<?php echo _u()->getDefaultImageSrc(get_the_ID()) ?>" data-aspect-ratio="1">
            <?php
            }

            ?>
            <div class="image-overlay">
                <div class="pos-center txt-center">
                    <a href="<?php the_permalink() ?>" class="btn-rounded"><?php _e("Leer más", "ubiqa") ?></a>
                </div>
                <div class="pos-br">
                    <i class="fa fa-comment-o txt-big"></i> <b><?php echo get_comments_number($post, '0', '1', '%' ); ?></b>
                </div>
            </div>
        </div>
        <div class="card-info">
            <a href="<?php echo get_permalink($post) ?>"><?php echo get_the_title($post) ?></a>
        </div>
    </div>
</div>