/**
 * Created by asierm on 6/3/15.
 */
jQuery(document).ready(function($){


    if($("#city_map_container").attr("id")){

        var map    = null;
        var bounds = null;

        var osmUrl    ='https://{s}.tiles.mapbox.com/v3/simettric.jcc2bc4j/{z}/{x}/{y}.png';
        //http://otile1.mqcdn.com/tiles/1.0.0/map/{z}/{x}/{y}.png
        //https://stamen-tiles-{s}.a.ssl.fastly.net/toner/{z}/{x}/{y}.png
        //http://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png
        var osmAttrib ='';
        var osm       = new L.TileLayer(osmUrl, {minZoom: 1, maxZoom: 19, attribution: osmAttrib});
        var latlon    = L.latLng(window.latlon.lat?window.latlon.lat:43.26, window.latlon.lon?window.latlon.lon:-2.94);


        map = L.map("city_map_container", {
            scrollWheelZoom: false
        });

        map.addLayer(osm);
        var marker = L.marker(latlon,{draggable: true}).addTo(map).on('dragend', function(event){
            var marker = event.target;
            var position = marker.getLatLng();
            //marker.setLatLng(new L.LatLng(position.lat, position.lng),{draggable:'true'});
            map.panTo(new L.LatLng(position.lat, position.lng));

            $("#content_geo_lat").val(position.lat);
            $("#content_geo_lon").val(position.lng);



        });
        map.setView(latlon, 15);


        function updateMap(){
            if(window.latlon.lat && window.latlon.lon) return;

            if($("#title").val() && $("#content_geo_country").val()){

                var query = $("#title").val() + "," + $("#content_geo_country").val();




                $.getJSON("http://nominatim.openstreetmap.org/search/" + query + "?format=json", function(data){

                    if(data.length){
                        var latlon = L.latLng(data[0].lat, data[0].lon);
                        marker.setLatLng(latlon);
                        map.panTo(latlon);

                        $("#content_geo_lat").val(latlon.lat);
                        $("#content_geo_lon").val(latlon.lng);
                    }

                });


            }

        }


        $("#title").keyup(function(e){


            updateMap();

        });
        $("#content_geo_country").keyup(function(){
            updateMap();
        });

    }


});