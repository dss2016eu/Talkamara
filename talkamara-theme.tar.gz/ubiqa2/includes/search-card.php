
<div class="col-m-6 col-l-3"><div class="card">
    <div class="card-image lazy-img">
        <?php

        if($thumb = get_the_post_thumbnail(get_the_ID(),"ubiqa_blog_thumb", array("data-aspect-ratio"=>"1"))){
            echo $thumb;
        }else{ ?>
            <img src="<?php echo _u()->getDefaultImageSrc(get_the_ID()) ?>" data-aspect-ratio="1">
        <?php
        }

        ?>
        <div class="image-overlay">
            <div class="pos-center txt-center">
                <a href="<?php echo the_permalink() ?>" class="btn-rounded"><?php _e("Ver", "ubiqa") ?></a>
            </div>
        </div>
    </div>
    <div class="card-info">
        <p><b><?php the_title() ?></b></p>
    </div>
</div></div>