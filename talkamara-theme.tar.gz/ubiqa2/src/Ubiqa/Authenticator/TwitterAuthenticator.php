<?php
/**
 * Created by PhpStorm.
 * User: Asier
 * Date: 30/05/14
 * Time: 18:48
 */

namespace Ubiqa\Authenticator;


use TwitterOAuth\Api;

class TwitterAuthenticator implements AuthenticatorInterface {

    private $url, $key, $secret, $callback, $redirect_url, $conn, $token, $storage, $access_token, $is_authenticated;

    private $user_id, $user;


    function __construct($consumer_key, $consumer_secret, $oauth_callback, UserTokenStorage $storage){

        $this->key = $consumer_key;
        $this->secret = $consumer_secret;
        $this->callback = $oauth_callback;


        $this->storage = $storage;

    }

    function getRequestToken(){

    }

    function authenticate($_oauth_code=null){


        if(isset($_SESSION['oauth_token'])){
            $this->conn   = new Api($this->key, $this->secret, $_SESSION['oauth_token'], $_SESSION['oauth_token_secret']);
            $this->access_token = $this->conn->getAccessToken($_oauth_code);
            //die(var_dump($this->conn->http_code));
            if($this->conn->http_code == 200){
                $data = $this->conn->get('account/verify_credentials');

                $this->is_authenticated = isset($data->id) && $data->id;
                $this->user_id = $data->id;


            }
        }





    }

    function setRedirectUrl($url){
        $this->redirect_url = $url;
    }

    function isAuthenticated(){
        return $this->is_authenticated;
    }

    function getId(){
        return $this->user_id;
    }

    function getUser(){
        if(!$this->user){
            if($this->user_id){
               $this->user = $this->storage->getUserBySocialId($this->user_id, "twitter");
            }
        }

        return $this->user;
    }

    function setSocialIdToUser(\WP_User $user, $user_id){

        $this->storage->setTokenToUser($user->ID, "", "twitter", $user_id);
    }

    function getAuthUrl(){

        if(!$this->url){
            $this->conn   = new Api($this->key, $this->secret);
            $this->token  = $this->conn->getRequestToken($this->callback);
            switch ($this->conn->http_code) {
                case 200:
                    $_SESSION['oauth_token'] = $this->token['oauth_token'];
                    $_SESSION['oauth_token_secret'] = $this->token['oauth_token_secret'];
                    $this->url = $this->conn->getAuthorizeURL($this->token["oauth_token"]);

                    break;
                default:
                    //echo 'Could not connect to Twitter. Refresh the page or try again later.';
            }
        }
        return $this->url;
    }


} 