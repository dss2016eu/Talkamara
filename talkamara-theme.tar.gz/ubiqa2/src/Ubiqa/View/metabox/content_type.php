<div id="content_type_metas">

    <div style="float:left; width: 250px">

        <p>
            <label>
                <input type="radio"
                    <?php if($this->_model->getMeta($post->ID, "ubiqa_content_type", "image")  == "image") echo "checked" ?>
                          name="ubiqa_content[type]"
                          class="content_type "
                          data-rel="image"
                          value="image"> <?php _e("Imagen", "ubiqa") ?></label>
        </p>
        <p>
            <label><input type="radio"
                    <?php if($this->_model->getMeta($post->ID, "ubiqa_content_type")  == "video") echo "checked" ?>
                          name="ubiqa_content[type]"
                          class="content_type"
                          data-rel="video"
                          value="video"> <?php _e("Video", "ubiqa") ?></label>
        </p>
        <p>
            <label><input type="radio"
                    <?php if($this->_model->getMeta($post->ID, "ubiqa_content_type")  == "audio") echo "checked" ?>
                          name="ubiqa_content[type]"
                          class="content_type"
                          data-rel="audio"
                          value="audio"> <?php _e("Audio", "ubiqa") ?></label>
        </p>

    </div>

    <div style="float:left; width: 500px; padding: 10px 20px; border: 1px solid #eee">

        <h3><?php _e("Enlace a contenido", "ubiqa") ?></h3>
        <p>
            <input type="url"
                   value="<?php echo $this->_model->getMeta($post->ID, "ubiqa_content_content_url") ?>"
                   name="ubiqa_content[content_url]"
                   placeholder="<?php _e("Enlace a contenido", "ubiqa") ?>">
        </p>
        <p>
            <?php if($this->_model->getMeta($post->ID, "ubiqa_content_type") == "image") echo get_the_post_thumbnail( $post->ID, "ubiqa_featured", array() ) ?>

            <?php

                if($this->_model->getMeta($post->ID, "ubiqa_content_type") == "video"){

                    echo $this->_model->getOembedHtml($post->ID, "ubiqa_video_oembed_data", 500, 440);
                }

            ?>
        </p>

        <h3><?php _e("Proyecto", "ubiqa") ?></h3>
        <p>
            <select style="margin-top: -2px"  name="ubiqa_content[subproject]">
                <option><?php _e("Ningún proyecto asociado", "ubiqa") ?></option>
                <?php foreach($this->_container["model.project"]->getList() as $project ){ ?>
                    <option <?php if($this->_model->getMeta($post->ID, "ubiqa_content_subproject")  == $project->ID) echo "selected='selected'" ?>
                        value="<?php echo $project->ID ?>"><?php echo \get_the_title($project) ?></option>
                <?php } ?>
            </select>
        </p>

        <h3><?php _e("Localización", "ubiqa") ?></h3>
        <h5><?php _e("Coordenadas", "ubiqa") ?></h5>
        <p>
            <input type="text"
                   value="<?php echo $this->_model->getMeta($post->ID, "ubiqa_content_lon") ?>"
                   name="ubiqa_content[lon]"
                   id="content_geo_lon"
                   placeholder="<?php _e("Longitud", "ubiqa") ?>">
            <input type="text"
                   value="<?php echo $this->_model->getMeta($post->ID, "ubiqa_content_lat") ?>"
                   name="ubiqa_content[lat]"
                   id="content_geo_lat"
                   placeholder="<?php _e("Latitud", "ubiqa") ?>">
        </p>

        <script type="text/javascript">
            var map_config = <?php echo json_encode($map_config) ?>;
            var latlon = {lat: <?php echo $this->_model->getMeta($post->ID, "ubiqa_content_lat", "null") ?>,lon: <?php echo $this->_model->getMeta($post->ID, "ubiqa_content_lon", "null") ?>};

        </script>


        <h5><?php _e("Dirección", "ubiqa") ?></h5>
        <p>

            <label for="content_geo_city"><?php _e("Ciudad", "ubiqa") ?></label>
            <?php $city_id = $this->_model->getMeta($post->ID, "ubiqa_content_city") ?>
            <select name="ubiqa_content[city]" class="geo_input" id="content_geo_city">
                <?php foreach($cities as $id=>$city){ ?>
                <option <?php if($id == $city_id){ ?>selected="selected" <?php } ?>
                    value="<?php echo $id ?>"><?php echo $city ?></option>
                <?php } ?>
            </select>
        </p>
        <p>
            <textarea  class="geo_input"
                       id="content_geo_address"
                       style="width: 100%"
                       placeholder="<?php _e("Dirección", "ubiqa") ?>"
                       name="ubiqa_content[address]"><?php echo $this->_model->getMeta($post->ID, "ubiqa_content_address") ?></textarea>
        </p>

        <div style="height: 400px" id="map_container">

        </div>


        <h5><?php _e("Ruta", "ubiqa") ?></h5>
        <p>
            <select
                   value="<?php echo $this->_model->getMeta($post->ID, "ubiqa_content_route") ?>"
                   name="ubiqa_content[route]">

                <option
                    <?php if(!$this->_model->getMeta($post->ID, "ubiqa_content_route")) echo 'selected="selected"' ?>
                    value=""><?php _e("Ninguna ruta seleccionada", "ubiqa") ?></option>

                <?php foreach($route_model->getList() as $route){ ?>

                    <option
                        <?php if($this->_model->getMeta($post->ID, "ubiqa_content_route")==$route->ID) echo 'selected="selected"' ?>
                    value="<?php echo $route->ID ?>"><?php echo get_the_title($route) ?></option>

                <?php } ?>

            </select>
            <input type="number"
                   value="<?php echo $this->_model->getMeta($post->ID, "ubiqa_content_route_position") ?>"
                   name="ubiqa_content[route_position]"
                   placeholder="">
        </p>


        <div class="hide-image content_type_option">
            <h3><?php _e("Entrevista", "ubiqa") ?></h3>

            <?php

            $languages[""]= __("No definido", "ubiqa") ;
            foreach(_u()->getLanguages(true) as $iso=>$label){
                $languages[$iso] = $label;
            }

            ?>
            <p>
                <label><input type="checkbox" <?php if($this->_model->getMeta($post->ID, "ubiqa_content_is_interview")) echo "checked" ?> name="ubiqa_content[is_interview]"  value="1"> <?php _e("¿es una entrevista?", "ubiqa") ?></label>
            </p>
            <p >

                <select style="margin-top: -2px"  name="ubiqa_content[genre]">
                    <option><?php _e("Género no indicado", "ubiqa") ?></option>
                    <option <?php if($this->_model->getMeta($post->ID, "ubiqa_content_genre")  == "male") echo "selected='selected'" ?> value="male"><?php _e("Hombre", "ubiqa") ?></option>
                    <option <?php if($this->_model->getMeta($post->ID, "ubiqa_content_genre")  == "female") echo "selected='selected'" ?> value="female"><?php _e("Mujer", "ubiqa") ?></option>
                </select>
                <input type="number" value="<?php echo $this->_model->getMeta($post->ID, "ubiqa_content_age") ?>" name="ubiqa_content[age]" placeholder="<?php _e("Edad", "ubiqa") ?>"> <?php _e("años", "ubiqa") ?>
            </p>
            <p>
                <label for="content_language"><?php _e("Idioma", "ubiqa") ?></label>
                <?php $lang_id = $this->_model->getMeta($post->ID, "ubiqa_content_language") ?>
                <select name="ubiqa_content[language]" class="geo_input" id="content_language">

                    <?php foreach($languages as $id=>$language){ ?>
                        <option <?php if($id == $lang_id){ ?>selected="selected" <?php } ?>
                                value="<?php echo $id ?>"><?php echo $language ?></option>
                    <?php } ?>
                </select>
            </p>
        </div>

    </div>

    <div style="clear:both"></div>

</div>