<html>

<head>



    <?php wp_head() ?>

    <style>
        body {
            background:#ccc;
            color: #000;
            margin: 0px;
            padding: 20px;
            font-family: helvetica, arial, sans-serif;
            height: 160px;
        }
        h4{
            font-family: helvetica, arial, sans-serif;
        }

    </style>

</head>

<body>


       <?php if($link = _u()->get("form_link")){ ?>





           <form id="upload" action="<?php echo $link ?>" method="post" enctype="multipart/form-data">

               <p>
                   <input type="file" id="vimeo_file" name="file_data" required="required" class="form-control">
               </p>

               <p>
                   <button type="submit" class="btn btn-primary" id="upload_to_vimeo"><?php _e("Subir vídeo a vimeo") ?></button>

               </p>

           </form>


           <script type="text/javascript">

                jQuery(document).ready(function($){


                    $("#upload_to_vimeo").click(function(e){

                        e.preventDefault();
                        var input = $("#content_info_url", parent.document);


                        parent.jQuery("#vimeo_loading").show();
                        if($("#vimeo_file").val())
                            $(this).html('<?php _e("Subiendo, espere por favor...", "ubiqa") ?>').attr("disabled", "disabled");

                        $("#upload").submit();
                    });
                });


           </script>


       <?php }else{ ?>

           <div class="alert alert-success">
               <?php _e("Video subido correctamente a Vimeo", "ubiqa") ?>
           </div>

           <?php wp_footer() ?>

            <script type="text/javascript">

                jQuery(document).ready(function($) {

                    parent.jQuery("#content_info_url").val('<?php echo _u()->get("video_link") ?>').trigger("blur");

                });


            </script>

<?php } ?>


</body>

</html>