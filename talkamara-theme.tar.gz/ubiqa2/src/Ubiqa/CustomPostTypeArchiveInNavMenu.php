<?php
/*
Plugin Name: Add Custom Post Types Archive to Nav Menus
Plugin URI: http://www.andromeda-media.de/
Description: Extends the WP Nav Menu with your Custom Post Type archive pages. The Plugin provides a new meta box in the WP Nav Menus options page. There you can choose your own Custom Post Types to add their archive to your navigation. For Example: if you have a post type called 'videos' to present your videos on your site, with the help of this plugin you can set it as fully functional navigation point in your WP Nav Menu.
Author: andromeda_media
Version: 1.1
Author URI: http://www.andromeda-media.de/
License: GPL v3
Text Domain: andromedamedia
Domain Path: /languages

Add Custom Post Types Archive to Nav Menus
Copyright (C) 2012, andromeda media - info@andromeda-media.de

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/



namespace Ubiqa;



    class CustomPostTypeArchiveInNavMenu {

        function __construct() {

            add_action( 'admin_head-nav-menus.php', array( $this, 'cpt_navmenu_metabox' ) );
            add_filter( 'wp_get_nav_menu_items', array( $this,'cpt_archive_menu_filter'), 10, 3 );

            add_action( 'save_post', array($this, 'setCounterToZeroOnSave') );
        }


        function setCounterToZeroOnSave($post_id){

            if(!get_post_meta($post_id, "ubiqa_visit", true)){
                update_post_meta($post_id, "ubiqa_visit", 0);
            }

        }

        function cpt_navmenu_metabox() {

            add_meta_box( 'add-cpt', __('Ubiqarama', 'ubiqa'), array( &$this, 'cpt_navmenu_metabox_content' ), 'nav-menus', 'side', 'default' );
        }

        function cpt_navmenu_metabox_content() {


            $post_types = get_post_types( array( 'show_in_nav_menus' => true), 'object' );

            if( $post_types ) :
                foreach ( $post_types as $post_type ) {
                    $post_type->classes = array();
                    $post_type->type = $post_type->name;
                    $post_type->object_id = $post_type->name;
                    $post_type->title = $post_type->labels->name;
                    $post_type->attr_title = $post_type->labels->name;
                    $post_type->object = 'cpt-archive';
                    $post_type->menu_item_parent = 0;
                    $post_type->url  = get_post_type_archive_link($post_type->name);
                    $post_type->db_id = 0;
                    $post_type->target = null;
                    $post_type->xfn = null;
                }
                $walker = new \Walker_Nav_Menu_Checklist( array() );

                echo '<div id="cpt-archive" class="posttypediv">';
                echo '<div id="tabs-panel-cpt-archive" class="tabs-panel tabs-panel-active">';
                echo '<ul id="ctp-archive-checklist" class="categorychecklist form-no-clear">';
                echo walk_nav_menu_tree( array_map('wp_setup_nav_menu_item', $post_types), 0, (object) array( 'walker' => $walker) );
                echo '</ul>';
                echo '</div><!-- /.tabs-panel -->';
                echo '</div>';
                echo '<p class="button-controls">';
                echo '<span class="add-to-menu">';
                echo '<input type="submit" class="button-secondary submit-add-to-menu" value="' . __('Añadir al menu', 'ubiqa') . '" name="add-ctp-archive-menu-item" id="submit-cpt-archive" />';
                echo '</span>';
                echo '</p>';

            endif;
        }

        function cpt_archive_menu_filter( $items, $menu, $args ) {

            foreach( $items as $item ) {
                if( $item->object != 'cpt-archive' ) continue;
                $item->url = function_exists('qtrans_convertURL') ?  qtrans_convertURL(get_post_type_archive_link( $item->type )) : get_post_type_archive_link( $item->type );

                if( get_query_var( 'post_type' ) == $item->type ) {
                    $item->classes[] = 'current-menu-item';
                    $item->current = true;
                }

                if($item->type == "post" && $this->isBlogPage()){
                    $item->classes[] = 'current-menu-item';
                    $item->current = true;
                }
            }

            return $items;
        }


        function isBlogPage(){
            if($name = get_query_var("pagename")){

                $post = get_page_by_path($name);
                if($post instanceof \WP_Post){
                    if($post->ID == get_option( 'page_for_posts', -1 )){
                        return true;
                    }
                }

            }
        }
    }


