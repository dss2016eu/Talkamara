<?php
/**
 * Created by PhpStorm.
 * User: Asier
 * Date: 16/04/14
 * Time: 17:48
 */

namespace Ubiqa\Authenticator;


class UserTokenStorage {

    protected $wpdb;

    function __construct($db){
        $this->wpdb = $db;
    }

    function setTokenToUser($user_id, $token, $service_name, $social_user_id=null){
        update_user_meta($user_id, $service_name . "_token", $token);
        if($social_user_id) update_user_meta($user_id, $service_name . "_user_id",  $social_user_id);
    }

    function getUserByEmail($email){
        return get_user_by( "email", $email );
    }

    function getUserBySocialId($id, $service_name){
        $users = get_users(array('meta_key' => $service_name . "_user_id", 'meta_value' => $id));

        foreach($users as $user){
            return $user;
        }
    }
    function setUserSocialUserId($user_id, $social_id, $service_name){
        return update_user_meta($user_id, $service_name . "_user_id",  $social_id);
    }

    function getUserToken($user_id, $service_name){
        return get_user_meta($user_id, $service_name . "_token", true);
    }

    function getUserSocialUserId($user_id, $service_name){
        return get_user_meta($user_id, $service_name . "_user_id", true);
    }


} 