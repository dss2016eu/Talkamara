var map    = null;
var bounds = null;
var map_config = window.map_config;

var osmUrl    = map_config.tile_url;
var osmAttrib = map_config.attribution;

jQuery(document).ready(function($){


    $(".container").fitVids();

    if($("#content-map").attr("id")){


        var osm       = new L.TileLayer(osmUrl, {minZoom: 1, maxZoom: 19, attribution: osmAttrib});

        map = L.map('content-map', {
            scrollWheelZoom: false,
            zoomControl: false
        });
        new L.Control.Zoom({ position: 'bottomright' }).addTo(map);


        map.addLayer(osm);

        var position = new L.latLng(window.lat, window.lon);
        //
        L.marker(position).addTo(map);

        map.setView([window.lat, window.lon], 14);

    }




});





