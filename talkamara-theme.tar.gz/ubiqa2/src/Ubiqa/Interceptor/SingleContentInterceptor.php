<?php
/**
 * Created by PhpStorm.
 * User: asierm
 * Date: 15/08/14
 * Time: 20:33
 */

namespace Ubiqa\Interceptor;


use Sense\AbstractInterceptor;
use Ubiqa\Form\FilterForm;

class SingleContentInterceptor  extends  AbstractInterceptor{


    function execute(\WP_Query $query){

        if(!$this->isExecuted()){




            $admin_model = $this->get("model.admin");
            $config      = $admin_model->getConfigOptions();

            $this->get("theme")->assign("map_config", array(

                'tile_url' => isset($config["map_tile_url"]) ? $config["map_tile_url"] : 'http://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',
                'attribution'  => isset($config["map_attribution"]) ? $config["map_attribution"] : "Ubiqarama"

            ));




            $this->addScript("leaflet", "http://cdn.leafletjs.com/leaflet-0.7.3/leaflet.js","1");
            $this->addScript("leaflet_markers", get_template_directory_uri() . "/js/leaflet/famarkers/leaflet.awesome-markers.min.js","1",array("leaflet", "jquery"));
            $this->addScript("icheck", get_template_directory_uri() . "/js/icheck.jquery.js","1",array( "jquery"));
            $this->addScript("content", get_template_directory_uri() . "/js/content.detail.js","1",array("leaflet", "jquery"));
            $this->addStyle("leaflet", "http://cdn.leafletjs.com/leaflet-0.7.3/leaflet.css", "1");
            $this->addStyle("leaflet_markers",  get_template_directory_uri() . "/js/leaflet/famarkers/leaflet.awesome-markers.css", "1");







        }


    }

} 