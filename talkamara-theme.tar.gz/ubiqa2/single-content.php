<?php get_header();

if ( have_posts() ) { while ( have_posts() ) { the_post();

    $author = \get_user_by( "id", get_the_author_meta("ID") );


    ?>

    <?php

    $user    = _u()->get("sense.model.user")->getUser();

    $user_id = $user?$user->ID:time();
    //$likes = (string)(int) _u()->get("content")->getMeta(get_the_ID(), "ubiqa_likes");
    $is_like = $user ? _u()->get("content")->isLike(get_the_ID(), $user) : null;



    $is_favorite = false;
    if($user){
        $is_favorite = _u()->get("content")->isFavorite(get_the_ID(), $user);
        //die(var_dump($is_favorite));
    }

    ?>

    <div class="bg-white-2">
        <ul class="breadcrumb container inline">
            <li class="breadcrumb-item"><a href="<?php echo _u()->getUrl() ?>"><?php _e("inicio", "ubiqa") ?></a></li>
            <li class="breadcrumb-item"><a href="<?php echo CONTENTS_URL ?>"><?php _e("contenidos", "ubiqa") ?></a></li>
            <li class="breadcrumb-item"><?php the_title() ?></li>
        </ul>
    </div>

    <section class="bg-white">
        <div class="grid container">
            <div class="col-m-8 col-l-9">
                <div class="container">
                    <div class="flx-h-m">
                        <div class="flx-1">
                            <h1><?php the_title() ?></h1>
                        </div>
                        <div>
                            <?php include "includes/single-share.php" ?>
                            <a href="#"

                               data-url-rel="<?php echo _u()->genUrl("like_content", array( "content_id" => get_the_ID(), "user_id"    => $user_id))?>"
                               data-rel="<?php echo get_the_ID() ?>"
                               class="btn-rounded like-item s icon_in_i">
                                <i class="fa   <?php echo($is_like ? "fa-heart" : "fa-heart-o") ?>"></i> &nbsp;Like
                            </a>


                            <?php if($user){ ?>
                                <a href="#" class="btn-rounded fav-item icon_in_i"
                                   data-url-rel="<?php echo _u()->genUrl("fav_content", array("content_id" => get_the_ID()))?>"
                                   data-rel="<?php echo get_the_ID() ?>"
                                    >
                                    <i class="fa <?php echo($is_favorite ? "fa-star" : "fa-star-o") ?>"></i> &nbsp;Fav
                                </a>
                            <?php } ?>
                        </div>
                    </div>
                </div>
                <hr>

                <?php echo _u()->getContentView(get_the_ID(), true) ?>


                <div class="content-container">

                    <?php
                    if($city = _u()->get("content")->getMeta(get_the_ID(), "ubiqa_content_city")){

                        if(is_numeric($city)){
                            $city = get_post($city);
                            if($city){
                                $city = get_the_title($city);

                    ?>

                    <div class="map-text-container">
                        <div id="content-map" style="width: 400px; height: 200px; position: relative; overflow: hidden; transform: translateZ(0px); background-color: rgb(229, 227, 223);">
                        </div>
                        <div class="map-text-title-container">
                            <h4><span class="uppercase"><?php _e("Localidad", "ubiqa") ?></span> | <span class="capitalize"><?php echo $city ?>
                                    <?php if($country = _u()->get("content")->getMeta(get_the_ID(), "ubiqa_content_country")){ ?>
                                        ,&nbsp; <?php echo $country ?>
                                    <?php } ?></span></h4>
                        </div>
                    </div>

                    <?php  }

                        }
                    }
                    ?>


                    <?php the_content() ?>
                </div>


            </div>
            <div class="col-s-12 col-m-4 col-l-3 txt-center">
                <div class="form-blocks auto-margin-s no-margin-r-l">
                    <div class="form-block">
                        <div class="img-rounded auto-margin">
                            <img src="<?php echo _u()->getAvatarUrl( $author, 400 ); ?>">
                        </div>
                        <br>
                        <div class="air">
                            <b class="txt-big"><?php  the_author_posts_link() ?></b>
                        </div>
                        <div>
                            <span class="txt-italic"><?php the_author_meta('description') ?></span>
                        </div>
                        <?php if($author->ID == get_current_user_id()){ ?>
                        <div class="air-t">
                            <a href="<?php echo _u()->genUrl("user_content_edit", array("content_id"=>get_the_ID())) ?>" id="edit_content" class="btn-rounded"><span><?php _e("Editar Contenido", "ubiqa") ?></span></a>
                        </div>
                        <?php } ?>
                    </div>
                    <div class="form-block">
                        <?php _e("TODOS LOS CONTENIDOS", "ubiqa") ?>
                    </div>

<?php

     if($project = _u()->get("content")->getMeta(get_the_ID(), "ubiqa_content_subproject")){
?>
                    <div class="form-block">
                        <?php _e("PROYECTO", "ubiqa") ?>:
                        <span class="txt-italic txt-big"><a href="<?php echo get_the_permalink($project) ?>"><?php echo get_the_title($project) ?></a></span>
                    </div>
<?php } ?>

                    <?php
                    $list = get_the_term_list(get_the_ID(), "ubiqa_category", '<ul class="tags-borderer txt-center inline"><li class="tag">', '</li><li class="tag">', '</li></ul>' );

                    if($list){
                    ?>

                    <div class="form-block">
                        <?php _e("CATEGORÍAS", "ubiqa") ?><hr><?php echo $list ?>
                    </div>
                    <?php } ?>




                    <?php
                    $list = get_the_term_list(get_the_ID(), "topic", '<ul class="tags-borderer txt-center inline"><li class="tag">', '</li><li class="tag">', '</li></ul>' );

                    if($list){
                        ?>

                        <div class="form-block">
                            <?php _e("TEMAS", "ubiqa") ?><hr><?php echo $list ?>
                        </div>
                    <?php } ?>


<?php

if(_u()->getConfigOption("has_routes") && $route = _u()->get("content")->getMeta(get_the_ID(), "ubiqa_content_route")){

    if($route = get_post($route)){

?>
                    <div class="form-block">
                        <?php _e("RUTA", "ubiqa") ?>:
                        <span class="txt-italic txt-big"><a href="<?php echo get_permalink($route) ?>"><?php echo get_the_title($route) ?></a></span>

                    </div>

<?php }} ?>

                </div>
            </div>
            <div class="air-t air-b container grid border-t border-b col-12">
                <div class="float-left previous-post">
                    <?php next_post_link('%link','<i class="fa fa-chevron-left"></i> %title'); ?>
                </div>
                <div class="float-right next-post">
                    <?php previous_post_link('%link','%title <i class="fa fa-chevron-right"></i>'); ?>
                </div>
            </div>
        </div>
    </section>


    <?php $post_id = get_the_ID(); include 'includes/comments.php' ?>

    <script type="text/javascript">
        var lat = <?php echo _u()->get("content")->getMeta(get_the_ID(), "ubiqa_content_lat")?:"null" ?>;
        var lon = <?php echo _u()->get("content")->getMeta(get_the_ID(), "ubiqa_content_lon")?:"null" ?>;
    </script>


<?php }} get_footer() ?>