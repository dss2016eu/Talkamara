<?php
get_header();
if ( have_posts() ) { while ( have_posts() ) {
    the_post();

    $project_id = get_post_meta(get_the_ID(), "ubiqa_content_subproject", true);

    ?>

    <div class="bg-white-2">
        <ul class="breadcrumb container inline">
            <li class="breadcrumb-item"><a href="<?php echo _u()->getUrl() ?>"><?php _e("inicio", "ubiqa") ?></a></li>
            <li class="breadcrumb-item"><a href="<?php echo AGENDA_URL ?>"><?php _e("agenda", "ubiqa") ?></a></li>
            <li class="breadcrumb-item"><?php the_title() ?></li>
        </ul>
    </div>

    <section class="no-air-b bg-white no-air-t">
        <div class="container air-t">
            <div class="col-m-12 col-l-12">
                <div class="container">
                    <div class="flx-h-m">
                        <div class="flx-1">
                            <h1><?php the_title() ?></h1>
                        </div>
                        <div>
                            <?php include 'includes/single-share.php' ?>
                        </div>
                    </div>
                </div>
                <hr>
                <div class="air-b grid-overflowed" style="height:40px;">

                    <div class="col-l-8 col-m-8 col-s-12 float-left event-data">
                        <span class="txt-italic txt-dark air-r"><i class="fa fa-calendar air-r"></i><?php echo _u()->getMeta("ubiqa_event_data_date") ?>&nbsp;<?php echo _u()->getMeta("ubiqa_event_data_time") ?></span>
                        <span class="txt-dark air-l project"><i class="fa fa-book air-r"></i><?php _e("PROYECTO", "ubiqa") ?> | <?php
        if($project_id) {

            $project = get_post($project_id);

            ?>

            <a href="<?php echo get_permalink($project->ID) ?>" class="txt-italic"><?php echo get_the_title($project) ?></a>

        <?php } else{ ?>

            <span class="txt-italic"><?php _e("No indicado", "ubiqa") ?></span>
        <?php } ?>


                        </span>
                    </div>
                    <div class="col-l-4 col-m-4 col-s-12 txt-right float-left">

                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="no-air-t">
        <div class="grid container ">
            <div class="col-m-12 col-l-12 txt-small">
               <?php the_content() ?>
            </div>
        </div>
    </section>




<?php }} get_footer() ?>