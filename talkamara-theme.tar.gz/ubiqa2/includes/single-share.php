<button class="btn-rounded" id="share-content" data-open-context="share">
    <i class="fa fa-share-alt"></i> <span>&nbsp;<?php _e("Compartir", "ubiqa") ?></span>
    <ul data-context-menu="share" class="border">
        <li data-action="share" >

            <a href="https://www.facebook.com/sharer/sharer.php?u=<?php the_permalink() ?>"
               target="_blank"
               data-action="share">
                <i class="fa fa-facebook"></i> &nbsp;Facebook
            </a>

        </li>
        <li>


            <a href="https://twitter.com/home?status=<?php the_permalink() ?>"
               target="_blank"
               data-action="share">
                <i class="fa fa-twitter"></i> &nbsp;Twitter
            </a>

        </li>
        <li>

            <a href="mailto:?&body=<?php the_permalink() ?>"
               target="_blank"
               data-action="share">
                <i class="fa fa-envelope"></i> &nbsp;<?php _e("Email", "ubiqa") ?>
            </a>

        </li>
    </ul>
</button>