jQuery(document).ready(function() {

    var grid   = $("#content_grid");
    var spiner = $(".spinner");



    var content = new ContentManager(
        grid,
        null,
        window.contents_ajax_url,
        null,
        null,
        null,
        spiner );







    $("#load_more").click(function(e){
        content.reload([{name: "filter[subproject]", value: window.project_id}], this);
    }).trigger("click");



});
