<?php $form = _u()->get("filter_form"); ?>

<!-- aside -->
<aside id="main-aside" class="app-aside">
    <div class="aside-indicator border">
        <i class="fa fa-angle-double-right oninactive"></i>
        <i class="fa fa-angle-double-left onactive"></i>
    </div>
    <div class="container">
        <form id="filter_form">

            <div id="content_search" class="form bg-white-1 air">
                <div class="grid form-row">
                    <?php  if(_u()->getConfigOption("has_geo")){ ?>
                    <div class="col-s-12 col-m-4 col-l-4 form-field">
                        <label for="city"><?php _e("CIUDAD", "ubiqa") ?></label>
                        <?php echo $form["city"]->getInputTag()   ?>
                    </div>
                    <?php } ?>
                    <div class="col-s-12 col-m-4 col-l-4 form-field">
                        <label for="project"><?php _e("PROYECTO", "ubiqa") ?></label>
                        <?php echo $form["subproject"]->getInputTag()   ?>
                    </div>
                    <div class="col-s-12 col-m-4 col-l-4 form-field">
                        <label for="search_field" class="hide-s">&nbsp;</label>
                        <div class="flx-1 form-search-wrapper">
                            <?php echo $form["search"]->getInputTag()  ?>
                            <i class="fa fa-search"></i>
                        </div>
                    </div>
                </div>
                <div class="grid form-row">
                    <div class="col-s-12 col-m-8 col-l-7 form-field">
                        <label for="content_type"><?php _e("TIPO DE CONTENIDO", "ubiqa") ?></label>
                        <?php //echo $form["content_type"]->getInputTag()   ?>
                        <ul class="tags tags-icons inline">
                            <li class="tag"><i class="fa fa-camera fa-lg checkbox_container ">
                                    <input value="image"
                                           name="filter[content_type][]" type="checkbox" ></i></li>
                            <li class="tag"><i class="fa fa-volume-up fa-lg checkbox_container "><input type="checkbox" value="audio"
                                                                                                               name="filter[content_type][]" ></i></li>
                            <li class="tag"><i class="fa fa-video-camera fa-lg checkbox_container "><input value="video"
                                                                                                                  name="filter[content_type][]" type="checkbox" ></i></li>
                        </ul>
<!--                        <ul class="tags tags-icons inline">-->
<!--                            <li class="tag"><i class="fa fa-camera fa-lg"></i></li>-->
<!--                            <li class="tag active"><i class="fa fa-volume-up fa-lg"></i></li>-->
<!--                            <li class="tag"><i class="fa fa-code fa-lg"></i></li>-->
<!--                            <li class="tag active"><i class="fa fa-file fa-lg"></i></li>-->
<!--                        </ul>-->
                    </div>
                    <?php if(_u()->getConfigOption("has_ubiqa_category")){ ?>
                    <div class="col-s-12 col-m-4 col-l-5 form-field">
                        <label for="categories"><?php _e("CATEGORIAS", "ubiqa") ?></label>
                        <?php echo $form["ubiqa_category"]->getInputTag()   ?>
                    </div>
                    <?php } ?>
                </div>

                <div id="more-filters">
                    <div class="grid form-row">
                        <div class="form-field">
                            <label for="topics"><?php _e("TEMAS", "ubiqa") ?></label>
                            <div id="topic_filter" class="tags tags-borderer inline">
                                <?php echo $form["topic"]->getInputTag()  ?>
                            </div>
                            <?php /*<ul class="tags tags-borderer inline">
                            <li class="tag active"><?php _e("Ocio", "ubiqa") ?></li>
                        </ul>*/?>
                        </div>
                    </div>
                    <?php  if(_u()->getConfigOption("has_interview")){ ?>
                        <div class="grid form-row mobile-interview">
                            <div class="form-field">
                                <ul class="interviews tags tags-icons inline">
                                    <li class="tag"><i class="fa fa-check-circle fa-lg-inter checkbox_container"><?php echo $form["is_interview"]->getInputTag();  ?></i></li>
                                </ul>
                                <label for="entrevista_ch"><?php _e("ENTREVISTA", "ubiqa") ?></label>
                            </div>
                        </div>

                        <div class="grid form-row">
                            <div class="col-s-12 col-m-3 form-field" data-interview>
                                <label for="age_from"><?php _e("EDAD", "ubiqa") ?></label>
                                <div class="flx-h">
                                    <div class="flx-1">
                                        <?php echo $form["age_from"]->getInputTag()   ?>
                                    </div>
                                    <div>&nbsp;&nbsp;</div>
                                    <div class="flx-1">
                                        <?php echo $form["age_to"]->getInputTag()   ?>
                                    </div>
                                </div>
                            </div>
                            <div class="col-s-12 col-m-3 form-field" data-interview>
                                <label for="genre"><?php _e("GÉNEROS", "ubiqa") ?></label>
                                <?php echo $form["genre"]->getInputTag()   ?>
                            </div>
                            <div class="col-s-12 col-m-3 form-field" data-interview>
                                <label for="language_selector"><?php _e("IDIOMAS", "ubiqa") ?></label>
                                <?php echo $form["language"]->getInputTag()   ?>
                            </div>
                        </div>

                    <?php } ?>
                </div>
            </div>
            <button type="button" class="btn-default bg-dark" data-slide-activate="more-filters">
                <i class="fa fa-chevron-down" id="filter-arrow"></i>
                <span data-more-filters><?php _e("Más filtros", "ubiqa") ?></span>
                <span data-less-filters><?php _e("Menos filtros", "ubiqa") ?></span>
            </button>
        </form>
    </div>


</aside>

<?php /*

 <div class="grid form-row">
                        <div class="col-s-12 col-m-3 form-field">

                            <?php echo $form["is_interview"]->getInputTag();//<input type="checkbox" id="entrevista_ch">  ?>
                            <?php

                            //<label for="entrevista_ch" class="air-h float-left-s"><?php _e("ENTREVISTA", "ubiqa")</label>
                            ?>
                        </div>
                        <div class="col-s-12 col-m-3 form-field" data-interview>
                            <label for="age_from"><?php _e("EDAD", "ubiqa") ?></label>
                            <div class="flx-h">
                                <div class="flx-1">
                                    <?php echo $form["age_from"]->getInputTag()   ?>
                                </div>
                                <div>&nbsp;&nbsp;</div>
                                <div class="flx-1">
                                    <?php echo $form["age_to"]->getInputTag()   ?>
                                </div>
                            </div>
                        </div>
                        <div class="col-s-12 col-m-3 form-field" data-interview>
                            <label for="genre"><?php _e("GÉNEROS", "ubiqa") ?></label>
                            <?php echo $form["genre"]->getInputTag()   ?>
                        </div>
                        <div class="col-s-12 col-m-3 form-field" data-interview>
                            <label for="language_selector"><?php _e("IDIOMAS", "ubiqa") ?></label>
                            <?php echo $form["language"]->getInputTag()   ?>
                        </div>
                    </div>
 */