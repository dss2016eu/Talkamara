<?php
/**
 * Created by PhpStorm.
 * User: Asier
 * Date: 30/07/14
 * Time: 21:51
 */

get_header();
$info_form = _u()->get("info_form");
$geo_form = _u()->get("geo_form");
$topic_form = _u()->get("topic_form");
$oembed = _u()->get("oembed");
$post = _u()->get("item");


?>
<div class="bg-white-2">
    <ul class="breadcrumb container inline">
        <li class="breadcrumb-item"><a href="<?php echo _u()->getUrl() ?>"><?php _e("inicio", "ubiqa") ?></a></li>
        <li class="breadcrumb-item"><a href="<?php echo _u()->genUrl("user_content") ?>"><?php _e("Tu contenido", "ubiqa") ?></a></li>
        <li class="breadcrumb-item"><?php _e("editar contenido", "ubiqa") ?></li>
    </ul>
</div>

<section class="bg-white-1">
    <div class="container bg-white" id="account-form">




        <div class="grid air-h" >




            <div class="col-s-12 col-m-12 col-s-12 air-h">




                <div >


                    <div class="form-block">
                        <span class="txt-bold"><?php _e("Editar contenido", "ubiqa") ?></span>
                    </div>

                    <?php if($message = _u()->get("sense.model.user")->getFlash("notice")){ ?>
                        <div class="alert alert-success"><?php echo $message ?></div>
                    <?php } ?>


                    <form method="post" action="" enctype="multipart/form-data">

                        <div class="bg-white-1 new-content-sub"  >
                            <div class="new-content-sub air-v" style="padding: 20px">


                                <div class="grid air-b">
                                        <div class="col-s-12 col-m-3 txt-bold form-field"><label for="project"><?php _e("Estado", "ubiqa") ?></label></div>
                                        <div class="col-s-12 col-m-6">
                                            <?php echo $info_form["status"]->getInputTag() ?>
                                        </div>
                                </div>
                                <div class="grid air-b"  id="step1-content-type">

                                        <div class="col-s-12 col-m-3 txt-bold form-field"><?php _e("Tipo de contenido", "ubiqa") ?></div>
                                        <div class="col-s-12 col-m-6">
                                            <?php echo $info_form["type"]->getInputTag() ?>
                                            <?php /* <ul class="tags tags-icons inline">
                                        <li class="tag"><i class="fa fa-camera fa-1dot5x"></i></li>
                                        <li class="tag"><i class="fa fa-volume-up fa-1dot5x"></i></li>
                                        <li class="tag"><i class="fa fa-code fa-1dot5x"></i></li>
                                        <li class="tag"><i class="fa fa-file fa-1dot5x"></i></li>
                                    </ul>*/ ?>
                                        </div>

                                </div>
                                    <div class="grid air-b">
                                        <div class="col-s-12 col-m-3 txt-bold form-field"><label for="project"><?php _e("Proyecto", "ubiqa") ?></label></div>
                                        <div class="col-s-12 col-m-6">
                                            <?php echo $info_form["project"]->getInputTag() ?>
                                        </div>
                                    </div>



                                <?php include 'editInfoUpload.php' ?>




                                <div id="language_tabs" data-tabs="content-language" class="air-t">

                                    <div class="container flx-h tabs-container">
                                        <?php foreach($info_form->languages as $iso=>$lang){ ?>
                                            <div class="tab <?php echo qtrans_getLanguage() == $iso?"active":"" ?>"
                                                 data-tab-show="<?php echo $iso ?>-content"> <span class=""><?php echo $lang ?></span></div>
                                        <?php } ?>

                                    </div>

                                    <?php foreach($info_form->languages as $iso=>$lang){ ?>

                                        <section id="<?php echo $iso ?>-content"  class="" data-tab-content="<?php echo $iso ?>-content"
                                                 style="<?php echo qtrans_getLanguage() != $iso?"display:none":"" ?>">
                                            <div class="grid air-b">
                                                <div class="col-12 txt-bold air-b"><label for="title"><?php _e("Título", "ubiqa") ?> (<?php echo $lang ?>)</label></div>
                                                <div class="col-12">
                                                    <?php echo $info_form["title_" . $iso]->getInputTag() ?>
                                                </div>
                                            </div>

                                            <div class="grid air-b">
                                                <div class="col-12 txt-bold air-b"><label for="description"><?php _e("Descripcion", "ubiqa") ?></label></div>
                                                <div class="col-12">
                                                    <?php echo $info_form["description_" . $iso]->getInputTag() ?>
                                                </div>
                                            </div>
                                        </section>

                                    <?php } ?>







                                </div>
                            </div>
                        </div>



                        <div class="air bg-white-1 new-content-sub" style="margin-top: 40px">
                            <div class="new-content-sub">

                                <div class="grid">
                                    <div class="col-s-12 col-m-6 air-r no-air-s-h">
                                        <div class="form-field">
                                            <label for=""><?php _e("CIUDAD", "ubiqa") ?></label>
                                            <?php echo $geo_form["city"]->getInputTag() ?>
                                        </div>
                                    </div>
                                    <div class="col-s-12 col-m-12 col-l-12">
                                        <div class="form-field">
                                            <label for=""><?php _e("DIRECCIÓN", "ubiqa") ?></label>
                                            <?php echo $geo_form["address"]->getInputTag() ?>
                                        </div>
                                    </div>
                                </div>
                                <br>
                                <div class="bg-white-2">
                                    <div id="map_container" style="height: 400px"></div>
                                </div>

                                <div class="grid air-t">
                                    <div class="col-s-12 col-m-6 air-r no-air-s-h">
                                        <div class="form-field-l form-field-m">
                                            <label for="" class="col-s-12 col-m-4 txt-right"><?php _e("LATITUD", "ubiqa") ?></label>
                                            <?php echo $geo_form["lat"]->getInputTag() ?>
                                        </div>
                                    </div>
                                    <div class="col-s-12 col-m-6 air-l no-air-s-h">
                                        <div class="form-field-l form-field-m">
                                            <label for="" class="col-s-12 col-m-4 txt-right"><?php _e("LONGITUD", "ubiqa") ?></label>
                                            <?php echo $geo_form["lon"]->getInputTag() ?>
                                        </div>
                                    </div>
                                    <div class="col-s-12 col-m-6 air-r no-air-s-h">
                                        <div class="form-field-l form-field-m">
                                            <label for="" class="col-s-12 col-m-4 txt-right"><?php _e("RUTA", "ubiqa") ?></label>
                                            <?php echo $geo_form["route"]->getInputTag() ?>
                                        </div>
                                    </div>
                                    <div class="col-s-12 col-m-6 air-l no-air-s-h">
                                        <div class="form-field-l form-field-m">
                                            <label for="" class="col-s-12 col-m-4 txt-right"><?php _e("POSICIÓN", "ubiqa") ?></label>
                                            <?php echo $geo_form["route_position"]->getInputTag() ?>
                                        </div>
                                    </div>
                                </div>


                            </div>

                        </div>


                        <div class="air bg-white-1 new-content-sub" style="margin-top: 40px">
                            <div class="new-content-sub air-v">

                                <div class="txt-bold"><?php _e("TEMAS", "ubiqa") ?></div>
                                <div id="topic_filter" class="tags tags-borderer inline">
                                    <?php echo $topic_form["topic"]->getInputTag()  ?>
                                </div>

                                <div class="grid form-row air-v">
                                    <div class="col-s-12 col-m-7 form-field">
                                        <label for="category" class="air-h"><?php _e("CATEGORIA", "ubiqa") ?></label>
                                        <?php echo $topic_form["ubiqa_category"]->getInputTag() ?>
                                    </div>
<?php if($info_form["type"]->getValue() != "image"){ ?>
                                    <div class="col-s-12 col-m-3 form-field">
                                        <label for="entrevista_ch" class="air-h"><?php _e("ENTREVISTA", "ubiqa") ?></label>
                                        <?php echo $topic_form["is_interview"]->getInputTag() ?>
                                    </div>
<?php } ?>
                                </div>

                                <?php if($info_form["type"]->getValue() != "image"){ ?>
                                <div class="grid form-row air-v">
                                    <div class="col-s-12 col-m-2 form-field" data-interview>
                                        <label for="city" class="txt-right"><?php _e("EDAD", "ubiqa") ?></label>
                                        <?php echo $topic_form["age"]->getInputTag() ?>
                                    </div>
                                    <div class="col-s-12 col-m-3 form-field" data-interview>
                                        <label for="city"><?php _e("GÉNERO", "ubiqa") ?></label>
                                        <?php echo $topic_form["genre"]->getInputTag() ?>
                                    </div>
                                    <div class="col-s-12 col-m-3 form-field" data-interview>
                                        <label for="city"><?php _e("IDIOMA", "ubiqa") ?></label>
                                        <?php echo $topic_form["language"]->getInputTag() ?>
                                    </div>
                                </div>
                                <?php } ?>
                            </div>


                        </div>
                        <div class="new-content-sub air-v txt-right">
                            <button type="submit" class="btn-rounded"><?php _e("Actualizar", "ubiqa") ?></button>
                        </div>






                    </form>


                </div>

            </div>
        </div>

    </div>
</section>

    <script type="text/javascript">
        var map_config = <?php echo json_encode(_u()->get("map_config", array())) ?>;

    </script>
    <script type="text/javascript">

        <?php if($geo_form["lat"]->getValue()){ ?>
        var latlon = {lat: <?php echo $geo_form["lat"]->getValue() ?>,lon: <?php echo $geo_form["lon"]->getValue() ?>};
        <?php } ?>

        var oembed_url = "<?php echo _u()->genUrl("ajax_embed_preview") ?>";
    </script>
<?php
get_footer();