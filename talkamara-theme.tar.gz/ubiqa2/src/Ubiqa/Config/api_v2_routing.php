<?php


$router->addRule('api2_login', '/api/v2/auth', array("__controller" => "Ubiqa\Controller\Api2Controller", "__action" => "login"));
$router->addRule('api2_account', '/api/v2/account', array("__controller" => "Ubiqa\Controller\Api2Controller", "__action" => "login"));

$router->addRule('api2_config', '/api/v2/configuration', array("__controller" => "Ubiqa\Controller\Api2Controller", "__action" => "config"));
$router->addRule('api2_taxonomies', '/api/v2/taxonomies', array("__controller" => "Ubiqa\Controller\Api2Controller", "__action" => "taxonomies"));
$router->addRule('api2_contents_edit', '/api/v2/contents/{id}/edit', array("__controller" => "Ubiqa\Controller\Api2Controller", "__action" => "contentEdit"));
$router->addRule('api2_contents_detail', '/api/v2/contents/{id}', array("__controller" => "Ubiqa\Controller\Api2Controller", "__action" => "contentDetail"));
$router->addRule('api2_contents', '/api/v2/contents', array("__controller" => "Ubiqa\Controller\Api2Controller", "__action" => "contents"));
