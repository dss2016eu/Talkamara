<?php get_header() ?>

    <section class="bg-white">
        <div class="grid container">
            <div class="col-m-8 col-l-9">
                <div class="container">
                    <div class="flx-h-m">
                        <div class="flx-1">
                            <h1><?php _e("resetear clave", "ubiqa") ?></h1>
                        </div>
                    </div>
                </div>
                <hr>


                <form class="panel-body" method="post" action="">

                    <?php if($error = _u()->get("error")){ ?>
                        <div class="alert alert-danger">
                            <p>
                                <?php echo $error ?>
                            </p>
                        </div>
                    <?php } ?>

                    <div class="row">
                        <div class="col-xs-12">
                            <?php if($message = _u()->getUserModel()->getFlash("notice")){ ?>
                                <div class="alert alert-success"><?php echo $message ?></div>
                            <?php } ?>
                        </div>
                    </div>

                    <div class="row form-group">

                        <div class="col-xs-12">
                            <input name="username" type="text" class="form-control" placeholder="<?php _e("Email o nombre de usuario", "ubiqa") ?>">
                        </div>

                    </div>
                    <div class="row form-group"  style="margin-top: 10px">

                        <div class="col-xs-12">
                            <button type="submit" class="btn btn-primary btn-rounded"><?php _e("Resetear contraseña", "ubiqa") ?></button> <?php _e("o", "ubiqa") ?>
                            <a href="<?php echo _u()->genUrl("login") ?>"><?php _e("iniciar sesión", "ubiqa") ?></a>
                        </div>

                    </div>

                </form>



            </div>
        </div>
    </section>

<?php get_footer() ?>