<?php
/**
 * Created by PhpStorm.
 * User: Asier
 * Date: 30/07/14
 * Time: 21:51
 */

get_header();

$form = _u()->get("form");
$item = _u()->get("item");
$step = 3;

?>



    <div class="bg-white-2">
        <ul class="breadcrumb container inline">
            <li class="breadcrumb-item"><a href="<?php echo _u()->getUrl() ?>"><?php _e("inicio", "ubiqa") ?></a></li>
            <li class="breadcrumb-item"><a href="<?php echo CONTENTS_URL ?>"><?php _e("contenido", "ubiqa") ?></a></li>
            <li class="breadcrumb-item"><?php _e("nuevo contenido", "ubiqa") ?></li>
        </ul>
    </div>


    <section class="bg-white-2" id="new-content">

        <form method="post" action="" enctype="multipart/form-data">

                <div class="container bg-white">
                    <?php include 'newSteps.php' ?>
                    <div class="air bg-white-1 new-content-sub">
                        <div class="new-content-sub air-v">

                            <div class="txt-bold"><?php _e("TEMAS", "ubiqa") ?></div>
                            <div id="topic_filter" class="tags tags-borderer inline">
                                <?php echo $form["topic"]->getInputTag()  ?>
                            </div>

                            <div class="grid form-row air-v">

<?php if(_u()->getConfigOption("has_ubiqa_category")){ ?>
                                <div class="col-s-12 col-m-7 form-field">
                                    <label for="category" class="air-h"><?php _e("CATEGORIA", "ubiqa") ?></label>
                                    <?php echo $form["ubiqa_category"]->getInputTag() ?>
                                </div>
<?php } ?>

<?php  if(_u()->getConfigOption("has_interview") && _u()->get("content_type")!="image"){ ?>
                                <div class="col-s-12 col-m-3 form-field">
                                    <label for="entrevista_ch" class="air-h"><?php _e("ENTREVISTA", "ubiqa") ?></label>
                                    <?php echo $form["is_interview"]->getInputTag() ?>
                                </div>
<?php } ?>
                            </div>
<?php  if(_u()->getConfigOption("has_interview") && _u()->get("content_type")!="image"){ ?>
                            <div class="grid form-row air-v">
                                <div class="col-s-12 col-m-2 form-field" data-interview>
                                    <label for="city" class="txt-right"><?php _e("EDAD", "ubiqa") ?></label>
                                    <?php echo $form["age"]->getInputTag() ?>
                                </div>
                                <div class="col-s-12 col-m-3 form-field" data-interview>
                                    <label for="city"><?php _e("GÉNERO", "ubiqa") ?></label>
                                    <?php echo $form["genre"]->getInputTag() ?>
                                </div>
                                <div class="col-s-12 col-m-3 form-field" data-interview>
                                    <label for="city"><?php _e("IDIOMA", "ubiqa") ?></label>
                                    <?php echo $form["language"]->getInputTag() ?>
                                </div>
                            </div>
                        </div>
<?php } ?>

                    </div>
                    <div class="new-content-sub air-v txt-right">
                        <button type="submit" class="btn-rounded"><?php _e("Finalizar", "ubiqa") ?></button>
                    </div>
                </div>



        </form>

    </section>


<?php
get_footer();