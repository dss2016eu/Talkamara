<?php

$items = _u()->get("items");
if(_u()->get("for_home")){



    include get_template_directory() . "/includes/content-cards-home.php";

}else  {

    foreach($items as $post){

        include get_template_directory() . "/includes/content-card.php";

    }
}




?>