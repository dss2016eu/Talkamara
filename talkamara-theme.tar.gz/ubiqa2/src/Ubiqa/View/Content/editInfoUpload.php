<div class="url">
    <div class="grid air-b">
        <div class="col-s-12 col-m-3 txt-bold form-field"><label for="link_content"><?php _e("enlazar contenido", "ubiqa") ?></label></div>
            <div class="col-s-12 col-m-9 ">




            <?php echo $info_form["url"]->getInputTag() ?>

            <div id="video_help" class="alert alert-info">
                <p><?php _e("Si ya dispone de un enlace, puede insertarlo en el campo 'Enlazar contenido'.", "ubiqa") ?></p>
            </div>


            <?php echo $info_form["oembed_data"]->getInputTag() ?>

            <div id="has_oembed_container" data-edit_mode="1" <?php if(!$oembed["has_value"]){ ?>style="display: none"<?php } ?>>
                <div class="content">
                    <?php echo $oembed["data"] ?>
                </div>
                <label>
                    <input type="checkbox" value="1" name="has_oembed" checked="checked" style="height: 15px">
                    <?php _e("Utilizar este contenido externo", "ubiqa") ?>
                </label>
            </div>

            <div id="vimeo_loading" class="alert alert-warning">
                <p><?php _e("Subiendo video a vimeo, esta operación tardará unos minutos. En cuanto dicho proceso acabe, automáticamente se establecerá el enlace en el campo anterior y podrá continuar subiendo el contenido.", "ubiqa") ?></p>

            </div>


            <iframe src="<?php echo _u()->genUrl("vimeo_iframe")?>"
                    id="vimeo_iframe"
                    style="height: 160px; border: none; background: #ccc; border-radius: 4px; width: 100%; margin-top: 10px; overflow: hidden!important"></iframe>




            <hr>
            <span class="upload_toggle"><?php _e("También puedes", "ubiqa") ?> <a class="underline" data-rel="file" href="#"><?php _e("subir un archivo desde tu ordenador", "ubiqa") ?></a></span>


        </div>


    </div>
</div>

<div class="file " style="display: none">
    <div class="grid air-b">
        <div class="col-s-12 col-m-3 txt-bold form-field"><label for="link_file"><?php _e("subir archivo", "ubiqa") ?></label></div>
        <div class="col-s-12 col-m-9">





            <div class="alert alert-info">
                <?php _e("Puedes subir archivos de imagen (jpeg, png, gif) y de audio (wave, mp3, ogg) de hasta 8MB", "ubiqa") ?>
            </div>


            <div class="filebox">
                <input type="text" id="filename" name="filename" disabled>
                <div class="button">
                    <span><?php _e("Examinar", "ubiqa") ?></span>
                    <?php echo $info_form["file"]->getInputTag() ?>
                </div>
            </div>
            <hr>
            <span class="upload_toggle"><?php _e("También puedes", "ubiqa") ?> <a class="underline" data-rel="url" href="#"><?php _e("enlazar a un archivo externo", "ubiqa") ?></a></span>


        </div>



    </div>
</div>


