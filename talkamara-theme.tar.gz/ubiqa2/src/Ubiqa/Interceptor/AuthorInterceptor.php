<?php
/**
 * Created by PhpStorm.
 * User: asierm
 * Date: 15/08/14
 * Time: 18:14
 */

namespace Ubiqa\Interceptor;


use Sense\AbstractInterceptor;
use Sense\AssetManager;

class AuthorInterceptor extends AbstractInterceptor {


    function execute(\WP_Query $wp_query){


        if(!$this->isExecuted()){


            /**
             * @var $asset_manager AssetManager
             */
            $asset_manager = $this->get("sense.theme_assets");
            $asset_uri     = $this->get("%wp.template_uri%");

            $asset_manager->addScript('author', $asset_uri . '/js/author.js', 1, true, array());


        }


    }

} 