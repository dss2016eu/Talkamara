<?php

$carousel_posts = _u()->get("content")->getCarouselPosts();
if($total = count($carousel_posts)){

?>

<div id="carousel">
    <div class="move prev" style=""></div>
    <div class="move next" style=""></div>
    <div class="owl-carousel">

        <?php foreach($carousel_posts as $i=>$_post){ \setup_postdata($GLOBALS['post'] = $_post) ?>


                <div class="item">
                    <img src="<?php echo wp_get_attachment_url( get_post_thumbnail_id($_post->ID) ) ?>">
                    <div class="owl-info-outter">
                        <div class="owl-info">
                            <h4><b><a href="<?php the_permalink() ?>"><?php the_title() ?></a></b></h4>

                            <p><?php the_excerpt() ?></p>
                        </div>
                    </div>
                </div>


           <?php \wp_reset_postdata();

        } ?>

    </div>

</div>

<?php

}

?>