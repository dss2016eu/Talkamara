* He añadido el archivo /style/fixes.css

* No tengo una clase para poner como activa una sección

* Si el carousel tiene un sólo elemento Uncaught TypeError: Cannot read property 'clone' of undefined

* Disposición rara de título y texto en algunas slides del carousel

* En el carousel no hay enlace maquetado

* los cards de posts no tienen enlace maquetado

* los cards de featured no tienen enlace maquetado

* si refrescas, aleatoriamente no salen las imagenes en los card featured

* ¿cuáles son los iconos de imagen y video?

* El contenedor del logo (header-logo) es un div background image en lugar de una imagen, se debe cambiar para que muestre bien un logo o un texto ya que el usuario puede cambiarlo (lo he modificado)

* no he tenido forma de implementar controles básicos de bootstrap como drowpdowns en los botones, salen sin estilo, tampoco en los formularios se usan las clases de bootstrap

* En Tu cuenta, el subir archivo queda desplazado a la derecha

* En tu cuenta, si la imagen no es cuadrada, se redimensiona sin proporción

* En tu cuenta, cambiar contraseña, los campos de contraseña no aparecen con estilo, parece que no se ha tenido en cuenta el estilo de bootstrap y no se ha estilado el tipo password

* No están estilados los alert de bootstrap

* Tu contenido: no maquetada y no tengo estilos de tabla ni de paginación

* Tus favoritos: no maquetada y no tengo estilos de tabla ni de paginación

* Login: no tenía estilo para type password ni para los botones de bootstrap btn btn-primary btn-default etc 

* Registro: no tengo estilos para campos tipo email, contraseña etc

* los posts no muestran la imagen al cargarlos por ajax en el grid, he quitado el lazy-img de 

* en el detalle de post, si la imagen es grande, se sale del contenido del post

* al hacer click en compartir post, se cierra el menú

* Al cargar las rutas en el grid, si no tienen foto no se redondea la imagen de avatar de usuario y queda cortada. No se ve tampoco el botón de ver ruta.

* En detalle de contenido no se redondea el avatar, he quitado el lazy-img porque no se cargaba tampoco

* En el detalle de contenido, si el contenido es un vídeo, no se muestra (se carga con un iframe) he quitado el <p class="lazy img" por un <div id="content_container">

* Me falta marker para rutas

* Contenidos: no se muestran los filtros por tipo de contenido, tener en cuenta que esto serían checkboxes por detrás

* Contenidos: me faltan iconos para los markers.

* En la home, no se ajusta bien el masonry por el card con el doble de tamaño. Esto no sé si es debido al contenido en sí.

* No tengo diseño de perfil de usuario

* Nuevo contenido, cuando el usuario inicia sesión, no tengo opción diseñada para subir contenido o de información de cuenta, he puesto unos provisionales
