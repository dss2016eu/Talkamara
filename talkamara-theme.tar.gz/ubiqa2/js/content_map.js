jQuery(document).ready(function($){


    var ajaxurl = window.ajaxurl;

    var interview_checkbox = $("#filter_is_interview_1 input").first();

    if($(interview_checkbox).is(":checked")){
        $("#interview_fields").show();
    }else{
        $("#interview_fields").hide();
        $("#interview_fields").find("select").each(function(){
            $(this).val("");
        });
    }

    $(interview_checkbox).click(function(){
        $("#interview_fields").toggle();
    });

    var MapManager = function(){

        var map    = null;
        var bounds = null;
        var map_config = window.map_config;

        var osmUrl    = map_config.tile_url;
        var osmAttrib = map_config.attribution;
        var osm       = new L.TileLayer(osmUrl, {minZoom: 1, maxZoom: 19, attribution: osmAttrib});
        var latlon = [];



        return {

            'init': function(id){

                map = L.map(id, {
                    scrollWheelZoom: false,
                    zoomControl: false
                });
                new L.Control.Zoom({ position: 'bottomright' }).addTo(map);


                map.addLayer(osm);



                var self = this;
                var marker_cluster = L.markerClusterGroup();

                for(var i in window.positions){

                    (function(){
                            var post_id = window.positions[i].id;
                            var type = window.positions[i].type;

                            var position = new L.latLng((window.positions[i].lat), (window.positions[i].lon));
                            latlon.push(position);
                        //.addTo(map)
                            var marker = L.marker(position, {icon: self.getIcon(type)}).on("click", function() {


                               self.showContent(post_id, position);


                            });
                            marker_cluster.addLayer(marker);
                    })();

                }
                map.addLayer(marker_cluster);



                var _initial_position = latlon[0] || new L.latLng(43.26,-2.94);

                map.setView(_initial_position, 14);

                bounds = L.latLngBounds(latlon);
                if(latlon.length>1){
                    map.fitBounds(bounds);
                }

                $("#map_container").animate({height: 200},100, function(){
                    self.updateSize();
                });

            },
            'getMap': function(){
                return map;
            },
            showContent: function(post_id, position){

                var self = this;
                console.log(ajaxurl);

                $.ajax({
                    url:  ajaxurl,
                    type: 'POST',
                    data: {action: 'ubiqa.content.singlecontent', id: post_id},
                    dataType: 'json',
                    success: function(item){



                        var content = $('#modal_content');

                        content.find(".title").first().html(item.title);
                        content.find(".project").first().html(item.project_name);
                        content.find(".content").first().html(item.content);
                        content.find(".link").first().attr("href", item.link);

                        var embed = content.find(".content_prev_html").first();

                        if(item.has_oembed){
                            embed.html(item.has_oembed);
                        }else{
                            switch (item.type){

                                case 'video':

                                    embed.html(item.embed_html);

                                    break;


                                case 'image':

                                    embed.html(item.thumb_html);

                                    break;

                                case 'audio':

                                    embed.html(item.audio_html);


                            }
                        }



                        content.find(".related_list").html("");
                        if(item.related.length){

                            content.find(".related").first().show();
                            for(var i in item.related){
                                var list = $("<li></li>")
                                    .append(

                                        $("<a></a>")
                                            .attr("href", item.related[i].url)
                                            .attr("data-rel", item.related[i].id)
                                            .html(item.related[i].title)
                                            .click(function(e){
                                                e.preventDefault();

                                                self.showContent($(this).attr("data-rel"), new L.latLng((item.related[i].lat), (item.related[i].lon)))

                                            })


                                    );

                                content.find(".related_list").first().append(list);
                            }

                        }else{
                            content.find(".related").first().hide();
                        }



                        if($("#map_container").height()<500){
                            $("#map_height_toggle").trigger("click", [function(){
                                $('#modal_content').show();
                            }, position]);
                        }else{
                            $('#modal_content').show();
                            map.setView(position, map.getZoom());

                        }



                    }
                });
            },
            getIcon: function(type){

                switch (type){
                    case 'image':
                        var icon = L.AwesomeMarkers.icon({
                            icon: 'glyphicon-camera',
                            markerColor: 'green'
                        });
                    break;
                    case 'video':
                        var icon = L.AwesomeMarkers.icon({
                            icon: 'glyphicon-facetime-video',
                            markerColor: 'blue'
                        });
                    break;
                    case 'audio':
                        var icon = L.AwesomeMarkers.icon({
                            icon: 'glyphicon-volume-up',
                            markerColor: 'orange'
                        });
                    break;
                }

                return icon;


            },
            updateSize: function(force_position){
                map.invalidateSize();

                if(force_position){
                    map.setView(force_position, 17);
                }else if(latlon.length>1){
                    map.fitBounds(bounds);
                }
            }

        };


    };


    var mapManager = new MapManager();
    mapManager.init("map_container");




    $(".close-content").click(function(e){
        $('#modal_content').hide();
        $("#modal_content")
            .find(".content_prev_html").html("");        //$("#map_height_toggle").trigger("click");

    });



    $("#map_height_toggle").click(function(e, callback, force_position){
        e.preventDefault();

        var text = $(this).attr("data-text-alt");
        var _text = $(this).html();

        $(this).attr("data-text-alt", _text).html(text);

        var height = 200;

        if($("#map_container").height()<500){
            height = 500;
        }else if($("#map_container").height()>200){
            $('#modal_content').hide();
        }



        $("#map_container").animate({height: height},100, function(){
            mapManager.updateSize(force_position);


        });

        if(callback){
            callback();
        }
    });

    $('#topic_filter p.choice-item').each(function(){



        var input      = $(this).find("input");
        var label      = $(this).find("label");
        input.appendTo("#topic_filter");




        input.iCheck({
            checkboxClass: 'icheckbox_line-blue',
            radioClass: 'iradio_line-blue',
            insert: '<div class="icheck_line-icon"></div>' + label.text()
        });

        label.remove();
        this.remove();
    });

});