<?php
/**
 * Created by PhpStorm.
 * User: Asier
 * Date: 7/07/14
 * Time: 14:34
 */

namespace Ubiqa\Model;


use Sense\Model\AbstractModel;

class ProjectModel extends AbstractModel {


    protected $post_type_name = "subproject";

    private $_list = null;

    function getList(){

        if(!$this->_list){
            $this->_list = $this->createQueryBuilder()->limit(-1)->getArray();
        }

        return $this->_list;
    }

    function getTopicList(\WP_Query $query){


        $sql = $query->request;
        $sql = str_replace("SQL_CALC_FOUND_ROWS", "", $sql);
        $sql = substr($sql, 0, strpos($sql, "ORDER"));


        /**
         * @var $wpdb \wpdb;
         */
        global $wpdb;

        $postids = $wpdb->get_col(
            "
	SELECT DISTINCT   t.term_id

	FROM  $wpdb->posts    p
    INNER JOIN  $wpdb->term_relationships tr ON tr.object_id = p.ID
    INNER JOIN  $wpdb->term_taxonomy tt ON tt.term_taxonomy_id = tr.term_taxonomy_id
    INNER JOIN  $wpdb->terms    t ON tt.term_id = t.term_id
	INNER JOIN  $wpdb->postmeta pm ON pm.post_id = p.ID
    WHERE tt.taxonomy = 'topic' AND p.ID IN($sql)
	");


        return $postids;


    }



} 