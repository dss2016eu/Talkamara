<?php
/**
 * Created by PhpStorm.
 * User: Asier
 * Date: 26/07/14
 * Time: 17:56
 */

namespace Ubiqa\Metabox;


use Sense\AbstractMetabox;
use Sense\Sense;
use Ubiqa\Model\AgendaModel;

class AgendaMetabox extends AbstractMetabox {



    function setUp(){

        \add_meta_box('ubiqa_event_data', __( 'Datos del evento', 'ubiqa' ), array($this, "HTML"), 'agenda', 'side', 'high' );
    }

    function HTML($post){
        include __DIR__ . "/../View/metabox/event_data.php";
    }



    function save($post_id){


        // If this is an autosave, our form has not been submitted, so we don't want to do anything.
        if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
            return;
        }


        if(isset($_POST["ubiqa_event_data"])){
            if(isset($_POST["ubiqa_event_data"]["date"]) && $_POST["ubiqa_event_data"]["date"]){
                $this->getModel()->setMeta($post_id, "ubiqa_event_data_date", $_POST["ubiqa_event_data"]["date"]);
                $this->getModel()->setMeta($post_id, "ubiqa_event_data_time", $_POST["ubiqa_event_data"]["time"]);


                $datetime = \DateTime::createFromFormat('d-m-Y H:i', $_POST["ubiqa_event_data"]["date"] . " " . $_POST["ubiqa_event_data"]["time"]);
                $this->getModel()->setMeta($post_id, "ubiqa_event_data_datetime", $datetime->format("Y-m-d H:i:s"));
            }
            if(isset($_POST["ubiqa_event_data"]["subproject"]) && $_POST["ubiqa_event_data"]["subproject"]){
                $this->getModel()->setMeta($post_id, "ubiqa_content_subproject", $_POST["ubiqa_event_data"]["subproject"]);
            }
        }


    }



}