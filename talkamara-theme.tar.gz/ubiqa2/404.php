<?php get_header() ?>

<section class="bg-white">
    <div class="grid container">
        <div class="col-m-8 col-l-9">
            <div class="container">
                <div class="flx-h-m">
                    <div class="flx-1">
                        <h1><?php _e("Contenido no encontrado", "ubiqa") ?></h1>
                    </div>
                </div>
            </div>
            <hr>
        </div>
    </div>
</section>




<?php get_footer() ?>