<?php
/**
 * Created by PhpStorm.
 * User: asierm
 * Date: 01/09/14
 * Time: 12:13
 */

namespace Ubiqa;


use Sense\Model\UserModel;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;

class HTTPAuthenticator {


    private  $_user;

    private $_is_authenticated=false;



    /**
     * @var UserModel
     */
    private $_model;

    function __construct(UserModel $model){
        $this->_model = $model;
    }


    function init(Request $request){


        if($request->server->get("PHP_AUTH_USER") && $request->server->get("PHP_AUTH_PW")){


            If($user = $this->_model->authenticate($request->server->get("PHP_AUTH_USER"), $request->server->get("PHP_AUTH_PW"))){

                $this->_is_authenticated = true;
                $this->_user = $user;

            }else{
                $this->authenticate();
            }



        }else{
            $this->authenticate();
        }


    }

    function authenticate() {

        $response = new Response("Unauthorized", 401);
        $response->headers->set("WWW-Authenticate", 'Basic realm="Test Authentication System"');
        $response->send();
        exit();
    }

    function isAuthenticated(){
        return $this->_is_authenticated;
    }

    function getUser(){
        return $this->_user;
    }





} 