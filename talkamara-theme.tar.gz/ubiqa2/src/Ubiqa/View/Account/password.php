<?php
/**
 * Created by PhpStorm.
 * User: Asier
 * Date: 30/07/14
 * Time: 21:51
 */

get_header();
$form = _u()->get("form");


?>
<div class="bg-white-2">
    <ul class="breadcrumb container inline">
        <li class="breadcrumb-item"><a href="<?php echo _u()->getUrl() ?>"><?php _e("inicio", "ubiqa") ?></a></li>
        <li class="breadcrumb-item"><?php _e("tu cuenta", "ubiqa") ?></li>
    </ul>
</div>

<section class="bg-white-1">
    <div class="container bg-white" id="account-form">




        <div class="grid air-h" data-tabs="account-tabs">

            <?php
                $active = "password";
                include '_sidebar.php'
            ?>


            <div class="col-s-12 col-m-9 col-s-12 air-h">




                <div data-tab-content="cambio-pass">
                    <div class="form-block">
                        <span class="txt-bold"><?php _e("Cambiar contraseña", "ubiqa") ?></span>
                    </div>
                    <?php if($message = _u()->get("model")->getFlash("notice")){ ?>
                        <div class="alert alert-success"><?php echo $message ?></div>
                    <?php } ?>
                    <?php if($message = _u()->get("error")){ ?>
                        <div class="alert alert-danger"><?php echo $message ?></div>
                    <?php } ?>


                    <form method="post" action="" >


                        <div class="flx-h-m air-t">
                            <label class="txt-bold form-label flx-1"><?php _e("Nueva contraseña", "ubiqa") ?></label>
                            <div class="flx-2">
                                <input name="password" type="password" class="full-w" value="">
                            </div>
                        </div>
                        <div class="flx-h-m air-t">
                            <label class="txt-bold form-label flx-1"><?php _e("Repetir la contraseña", "ubiqa") ?></label>
                            <div class="flx-2">
                                <input name="password_repeat" type="password" class="full-w" value="">
                            </div>
                        </div>

                        <button type="submit" class="btn btn-default air-t float-right"><?php _e("Cambiar contraseña", "ubiqa") ?></button>
                    </form>
                </div>

            </div>
        </div>

    </div>
</section>
<?php
get_footer();