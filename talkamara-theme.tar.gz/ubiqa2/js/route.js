jQuery(document).ready(function($){
    var tab_open = 0;
    var getIconUrl = function(type){

        var iconUrl =   "";

        switch (type){



            case 'image':
                iconUrl =  window.images_url + '/markers/num-img-marker.png';
                break;
            case 'video':
                iconUrl =  window.images_url + '/markers/num-video-marker.png';
                break;
            case 'audio':
                iconUrl =  window.images_url + '/markers/num-audio-marker.png';
                break;

            default :

        }

        return iconUrl;


    };

    L.NumberedDivIcon = L.Icon.extend({
        options: {
            number: '',
            type: '',
            shadowUrl: null,
            iconSize: new L.Point(58, 66),
            iconAnchor: new L.Point(26.65, 62),
            /*
             iconAnchor: (Point)
             popupAnchor: (Point)
             */
            className: ''
        },



        createIcon: function () {
            var div = document.createElement('div');
            var img = this._createImg(getIconUrl(this.options['type']));
            var numdiv = document.createElement('div');
            numdiv.setAttribute ( "class", "number" );
            numdiv.innerHTML = this.options['number'] || '';
            div.appendChild ( img );
            div.appendChild ( numdiv );
            this._setIconStyles(div, 'icon');
            return div;
        },

        //you could change this to add a shadow like in the normal marker if you really wanted
        createShadow: function () {
            return null;
        }
    });

    var markers = {};

    if($("#map").attr("id")){

        var map    = null;
        var bounds = null;

        var osmUrl    ='https://{s}.tiles.mapbox.com/v3/simettric.jcc2bc4j/{z}/{x}/{y}.png';
        //http://otile1.mqcdn.com/tiles/1.0.0/map/{z}/{x}/{y}.png
        //https://stamen-tiles-{s}.a.ssl.fastly.net/toner/{z}/{x}/{y}.png
        //http://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png
        var osmAttrib ='';
        var osm       = new L.TileLayer(osmUrl, {minZoom: 1, maxZoom: 19, attribution: osmAttrib});
        var latlon    = [];


        map = L.map("map", {
            scrollWheelZoom: false
        });

        map.addLayer(osm);

        //var _overlap = new OverlappingMarkerSpiderfier(map);
        //map.addLayer(_overlap);


        var position_number = 0;

        var marker_cluster = L.markerClusterGroup();

        for(var i in window.markers_info){



            if(window.markers_info[i].lat && window.markers_info[i].lon){

                position_number++;

                (function(){
                    var post_id = window.markers_info[i].id;
                    var type = window.markers_info[i].type;
                    var route_position = position_number; //window.markers_info[i].position ;
                    var position = new L.latLng((window.markers_info[i].lat), (window.markers_info[i].lon));//


                    latlon.push(position);
                    markers[route_position] = L.marker(position, {icon:	new L.NumberedDivIcon({number: route_position.toString(), type: type })});
                    //marker.bindPopup('<p style="text-align: center; font-size: 16px">#' + route_position.toString() + '<p>').openPopup();
                    markers[route_position].on("click", function(event) {


                        $("#title_"+post_id).trigger('open');




                    });


                    marker_cluster.addLayer(markers[route_position]);



                })();

                map.addLayer(marker_cluster);

            }



        }

        /*var firstpolyline = new L.Polyline(latlon, {
            color: '#000000',
                weight: 6,
                opacity: 0.5,
            smoothFactor: 1

        });
*/
        //map.addLayer(firstpolyline);

        var _initial_position = latlon[0] || new L.latLng(43.26,-2.94);

        map.setView(_initial_position, 12);

        bounds = L.latLngBounds(latlon);
        if(latlon.length>1){
            map.fitBounds(bounds);
        }




    };

    $(".route_title").click(function(e){
        e.preventDefault();

        $(this).trigger("open");
    });


    $(".route_title").on("open", function(e){
            e.preventDefault();



        var marker_id = $(this).attr("data-pos");

        if(tab_open != marker_id){

            tab_open = marker_id;
        }else{
            return;
        }

            var self = this;
            $('.route_title').each(function(){

                $(this).removeClass("active");
                $("#"+$(this).attr("data-slide-activate")).hide();

            });




            $(this).addClass("active").addClass("rActive");
            $("#"+$(this).attr("data-slide-activate")).show();






            $parentDiv = $("#ruta-left");
            $innerListItem = $(this);

            $("body").animate({ scrollTop: $parentDiv.offset().top  }, 200, "swing", function(){




                $parentDiv.scrollTop($parentDiv.scrollTop() + $innerListItem.position().top-100);

                map.setView(markers[marker_id].getLatLng(), 18);

            });





        e.stopPropagation();

    });




});