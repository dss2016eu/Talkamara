<?php
/**
 * Created by PhpStorm.
 * User: Asier
 * Date: 7/07/14
 * Time: 14:34
 */

namespace Ubiqa\Model;


use Sense\Model\AbstractModel;

class RouteModel extends AbstractModel {


    protected $post_type_name = "route";

    private $_list = null;

    function getList(){

        if(!$this->_list){
            $this->_list = $this->createQueryBuilder()->limit(-1)->getArray();
        }

        return $this->_list;
    }

    function getContentsArray(\WP_Post $route){

        return $this->createQueryBuilder("content")->whereMeta("ubiqa_content_route", $route->ID)->orderByMeta("ubiqa_content_route_position", "ASC", true)->limit(-1)->getArray();

    }



} 