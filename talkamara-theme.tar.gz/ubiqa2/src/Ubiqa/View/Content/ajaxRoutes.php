<?php foreach(_u()->get("items") as $post){

    include get_template_directory() . "/includes/route-card.php";

} ?>