<?php
$user    = _u()->get("sense.model.user")->getUser();


$user_id = $user?$user->ID:time();
$likes = (string)(int) _u()->get("content")->getMeta(get_the_ID(), "ubiqa_likes");
$is_like = $user ? _u()->get("content")->isLike(get_the_ID(), $user) : null;




setup_postdata( $post );

$related = _u()->get("related");


?>


        <div class="container  air-t">
            <div class="full-w txt-right"><i id="close_preview" class="fa fa-times" data-action="close"></i> </div>
            <a href="<?php the_permalink() ?>"><h2><?php the_title() ?></h2></a>

                <div>
                    <?php echo _u()->getContentView($post->ID) ?>
                </div>

            <?php the_content() ?>

            <?php if(count($related)){ ?>
            <div class="next-content">
                <h3><?php _e("Otros contenidos", "ubiqa") ?></h3>
                <ul>
                    <?php foreach($related as $related_post){ ?>
                    <li><a class="next_content_item" data-rel="<?php echo $related_post->ID ?>" href="#"><?php echo get_the_title($related_post) ?></a></li>
                    <?php } ?>
                </ul>
            </div>
            <?php } ?>
        </div>
        <div class="txt-right air-r">

            <a href="#"

               data-url-rel="<?php echo _u()->genUrl("like_content", array( "content_id" => get_the_ID(), "user_id"    => $user_id))?>"
               data-rel="<?php echo get_the_ID() ?>"
               class="btn-rounded like-item icon_in_i s">
                <i class="fa like-count  <?php echo($is_like ? "fa-heart" : "fa-heart-o") ?>"></i> &nbsp;Like
            </a>


            <?php include "single-share.php" ?>
        </div>


