<?php
/**
 * Created by PhpStorm.
 * User: Asier
 * Date: 30/07/14
 * Time: 21:51
 */

get_header();

$form = _u()->get("form");

$step = 1;

?>



    <div class="bg-white-2">
        <ul class="breadcrumb container inline">
            <li class="breadcrumb-item"><a href="<?php echo _u()->getUrl() ?>"><?php _e("inicio", "ubiqa") ?></a></li>
            <li class="breadcrumb-item"><a href="<?php echo CONTENTS_URL ?>"><?php _e("contenido", "ubiqa") ?></a></li>
            <li class="breadcrumb-item"><?php _e("nuevo contenido", "ubiqa") ?></li>
        </ul>
    </div>


    <section class="bg-white-2" id="new-content">

        <form method="post" action="" enctype="multipart/form-data">

            <div class="container bg-white">


                <?php include 'newSteps.php' ?>

                <div class="bg-white-1 new-content-sub">
                    <div class="new-content-sub air-v">


                        <div class="grid air-b">
                            <div class="col-s-12 col-m-7 form-field" id="step1-content-type">
                                <div class="col-s-12 col-m-6 txt-bold form-field"><?php _e("Tipo de contenido", "ubiqa") ?></div>
                                <div class="col-s-12 col-m-6">
                                    <?php echo $form["type"]->getInputTag() ?>
                                    <?php /* <ul class="tags tags-icons inline">
                                        <li class="tag"><i class="fa fa-camera fa-1dot5x"></i></li>
                                        <li class="tag"><i class="fa fa-volume-up fa-1dot5x"></i></li>
                                        <li class="tag"><i class="fa fa-code fa-1dot5x"></i></li>
                                        <li class="tag"><i class="fa fa-file fa-1dot5x"></i></li>
                                    </ul>*/ ?>
                                </div>
                            </div>
                            <div class="col-s-12 col-m-5 form-field">
                                <div class="col-s-12 col-m-4 txt-bold form-field"><label for="project"><?php _e("Proyecto", "ubiqa") ?></label></div>
                                <div class="col-s-12 col-m-8">
                                    <?php echo $form["project"]->getInputTag() ?>
                                </div>
                            </div>
                        </div>


                        <?php include 'newInfoUpload.php' ?>




                        <div id="language_tabs" data-tabs="content-language" class="air-t  depends-video">

                            <div class="container flx-h tabs-container">
                                <?php foreach($form->languages as $iso=>$lang){ ?>
                                    <div class="tab <?php echo qtrans_getLanguage() == $iso?"active":"" ?>"
                                         data-tab-show="<?php echo $iso ?>-content"> <span class=""><?php echo $lang ?></span></div>
                                <?php } ?>

                            </div>

                            <?php foreach($form->languages as $iso=>$lang){ ?>

                                <section id="<?php echo $iso ?>-content" class="" data-tab-content="<?php echo $iso ?>-content"
                                         style="<?php echo qtrans_getLanguage() != $iso?"display:none":"" ?>">
                                    <div class="grid air-b">
                                        <div class="col-12 txt-bold air-b"><label for="title"><?php _e("Título", "ubiqa") ?> (<?php echo $lang ?>)</label></div>
                                        <div class="col-12">
                                            <?php echo $form["title_" . $iso]->getInputTag() ?>
                                        </div>
                                    </div>

                                    <div class="grid air-b">
                                        <div class="col-12 txt-bold air-b"><label for="description"><?php _e("Descripcion", "ubiqa") ?></label></div>
                                        <div class="col-12">
                                            <?php echo $form["description_" . $iso]->getInputTag() ?>
                                        </div>
                                    </div>
                                </section>

                            <?php } ?>


                        </div>
                    </div>
                </div>
                <div class="new-content-sub air-v txt-right">
                    <button type="submit" class="btn-rounded" ><?php _e("Siguiente", "ubiqa") ?></button>
                </div>
            </div>

        </form>

    </section>


    <script type="text/javascript">
        var oembed_url = "<?php echo _u()->genUrl("ajax_embed_preview") ?>";

    </script>



<?php
get_footer();