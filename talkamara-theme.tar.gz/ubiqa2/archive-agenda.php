<?php get_header() ?>

    <div class="bg-white-2">
        <ul class="breadcrumb container inline">
            <li class="breadcrumb-item"><a href="<?php echo _u()->getUrl() ?>"><?php _e("inicio", "ubiqa") ?></a></li>
            <li class="breadcrumb-item"><?php _e("agenda", "ubiqa") ?></li>
        </ul>
    </div>

    <section class="bg-white no-air-t" id="agenda_view">
        <div class="grid container air-t">
            <div class="col-12">
                <h1><?php _e("Agenda", "ubiqa") ?></h1>
                <hr>
            </div>
            <div class="col-m-8 col-l-9 air2x-h calendar_container">
                <div id="calendar" class="calendar"></div>
            </div>

            <div class="col-s-12 col-m-4 col-l-3 txt-center">
                <div class="auto-margin-s txt-left">
                    <div class="form-block">
                        <div class="">
                            <b class="txt-big"><?php _e("PROXIMOS EVENTOS", "ubiqa") ?> <?php /*<span class="tag bg-grey txt-white">3</span>*/ ?></b>
                        </div>
                    </div>
                    <?php if ( have_posts() ) { while ( have_posts() ) { the_post(); ?>

                        <div class="form-block blocksons">
                            <a href="<?php the_permalink() ?>"><b class=""><?php the_title() ?></b></a>
                            <span class="txt-italic txt-dark air-r"><?php echo _u()->getMeta("ubiqa_event_data_date") ?>, <?php echo _u()->getMeta("ubiqa_event_data_time") ?></span>
                            <div class="step-number air-h" data-slide-activate="description<?php the_ID() ?>">
                                <div  class="btn-circle">
                                    <i class="fa"></i>
                                </div>
                            </div>
                            <p id="description<?php the_ID() ?>" class="date-content air-t">
                                <?php echo strip_tags(get_the_excerpt())?>
                            </p>
                        </div>


                    <?php } }else{ ?>
                        <p><?php _e("No hay eventos próximos", "ubiqa") ?></p>
                    <?php } ?>


                </div>
            </div>
        </div>
    </section>


    <script type="text/javascript">

        var ajaxurl = '<?php echo admin_url('admin-ajax.php'); ?>';

        var monthNames = <?php

       echo json_encode(array(
            __("Enero", "ubiqa"),__("Febrero", "ubiqa"),__("Marzo", "ubiqa"), __("Abril", "ubiqa"), __("Mayo", "ubiqa"), __("Junio", "ubiqa"), __("Julio", "ubiqa"), __("Agosto", "ubiqa"), __("Septiembre", "ubiqa"), __("Octubre", "ubiqa"), __("Noviembre", "ubiqa"), __("Diciembre", "ubiqa"),
       ));

   ?>;


        var monthNamesShort = <?php

       echo json_encode(array(
            __("Ene", "ubiqa"),__("Feb", "ubiqa"),__("Mar", "ubiqa"), __("Abr", "ubiqa"), __("May", "ubiqa"), __("Jun", "ubiqa"), __("Jul", "ubiqa"), __("Ago", "ubiqa"), __("Sep", "ubiqa"), __("Oct", "ubiqa"), __("Nov", "ubiqa"), __("Dic", "ubiqa"),
       ));

   ?>;

        var dayNames = <?php

       echo json_encode(array(
            __("Domingo", "ubiqa"),__("Lunes", "ubiqa"),__("Martes", "ubiqa"), __("Miércoles", "ubiqa"), __("Jueves", "ubiqa"), __("Viernes", "ubiqa"), __("Sábado", "ubiqa")
       ));

   ?>;

        var dayNamesShort = <?php

       echo json_encode(array(
            __("Dom", "ubiqa"),__("Lun", "ubiqa"),__("Mar", "ubiqa"), __("Mié", "ubiqa"), __("Jue", "ubiqa"), __("Vie", "ubiqa"), __("Sab", "ubiqa")
       ));

   ?>;

        var buttonText = <?php

       echo json_encode(array(

            'prevYear' => '&laquo;',
            'nextYear' => '&raquo;',
            'today'=> __("Hoy", "ubiqa"),
            'month'=> __("mes", "ubiqa"),
            'week' => __("semana", "ubiqa"),
            'day'  => __("día", "ubiqa"),
       ));

   ?>;







    </script>

<?php get_footer() ?>