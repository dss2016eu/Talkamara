<p>
    <label><?php _e("Fecha del evento", "ubiqa") ?></label>
    <input value="<?php echo($this->_model->getMeta($post->ID, "ubiqa_event_data_date")) ?>"
            type="text"
            class="datepicker"
            required="required"
            name="ubiqa_event_data[date]">

</p>

<p>
    <label><?php _e("Hora del evento", "ubiqa") ?></label>
    <input value="<?php echo($this->_model->getMeta($post->ID, "ubiqa_event_data_time")) ?>"
           type="text"
           class="timepicker"
           required="required"
           name="ubiqa_event_data[time]">

</p>

<hr>

<h3><?php _e("Proyecto", "ubiqa") ?></h3>
<p>
    <select style="margin-top: -2px"  name="ubiqa_event_data[subproject]">
        <option><?php _e("Ningún proyecto asociado", "ubiqa") ?></option>
        <?php foreach($this->_container["model.project"]->getList() as $project ){ ?>
            <option <?php if($this->_model->getMeta($post->ID, "ubiqa_content_subproject")  == $project->ID) echo "selected='selected'" ?>
                value="<?php echo $project->ID ?>"><?php echo \get_the_title($project) ?></option>
        <?php } ?>
    </select>
</p>