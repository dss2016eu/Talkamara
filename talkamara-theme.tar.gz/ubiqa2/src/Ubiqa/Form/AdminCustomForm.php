<?php
/**
 * Created by PhpStorm.
 * User: Asier
 * Date: 5/08/14
 * Time: 12:50
 */

namespace Ubiqa\Form;

use SimpleForm\AbstractForm;
use SimpleForm\FormBuilder;
use Symfony\Component\Validator\Constraints\Email;
use Symfony\Component\Validator\Constraints\NotBlank;
use Symfony\Component\Validator\Constraints\NotNull;
use Symfony\Component\Validator\Constraints\Length;
use Ubiqa\Model\ContentModel;

class AdminCustomForm extends AbstractForm{




    function configure(){



        $this->setName("custom");

        $builder = $this->getBuilder();

        $builder->add("logo", "input", array("type"=>"hidden", "label"=>__("Imagen para el logo"), "class"=>"", "required"=>false));
        $builder->add("h1_color", "input", array("type"=>"text", "label"=>__("Color del título principal (h1)"), "class"=>"regular-text", "required"=>false));
        $builder->add("h2_color", "input", array("type"=>"text", "label"=>__("Color de segundo título principal (h2)"), "class"=>"regular-text", "required"=>false));
        $builder->add("h4_color", "input", array("type"=>"text", "label"=>__("Color de títulos secundarios (h4)"), "class"=>"regular-text", "required"=>false));
        $builder->add("a_color", "input", array("type"=>"text", "label"=>__("Color de los enlaces"), "class"=>"regular-text", "required"=>false));
        $builder->add("button_color", "input", array("type"=>"text", "label"=>__("Color de los botones principales"), "class"=>"regular-text", "required"=>false));
        $builder->add("button_text_color", "input", array("type"=>"text", "label"=>__("Color del texto de los botones principales"), "class"=>"regular-text", "required"=>false));

    }


} 