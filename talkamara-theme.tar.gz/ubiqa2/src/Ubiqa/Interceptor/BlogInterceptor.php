<?php
/**
 * Created by PhpStorm.
 * User: Asier
 * Date: 26/07/14
 * Time: 17:40
 */

namespace Ubiqa\Interceptor;


use Sense\AbstractInterceptor;
use Sense\AssetManager;
use Ubiqa\Model\AgendaModel;

class BlogInterceptor extends AbstractInterceptor {


    function execute(\WP_Query $query){


        /**
         * @var $asset_manager AssetManager
         */
        $asset_manager = $this->get("sense.theme_assets");
        $asset_uri     = $this->get("%wp.template_uri%");


        $asset_manager->addScript('blog', $asset_uri . '/js/blog.js', 1, true, array());


    }

} 