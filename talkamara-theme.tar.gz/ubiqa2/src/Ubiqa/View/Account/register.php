<?php get_header() ?>

    <section class="bg-white">
        <div class="grid container">
            <div class="col-m-8 col-l-9">
                <div class="container">
                    <div class="flx-h-m">
                        <div class="flx-1">
                            <h1><?php _e("crear cuenta", "ubiqa") ?></h1>
                        </div>
                    </div>
                </div>
                <hr>


                <form class="panel-body" method="post" action="">

                    <div class="row">
                        <div class="col-xs-12">
                            <?php if($message = _u()->get("model")->getFlash("notice")){ ?>
                                <div class="alert alert-success"><?php echo $message ?></div>
                            <?php } ?>
                        </div>
                    </div>

                    <?php $form = _u()->get("form"); ?>




                    <?php foreach(array("login", "user_email", "first_name", "last_name", "password", "password_repeat") as $field){ ?>
                        <div class="row form-group" style="margin-top: 10px">

                            <div class="col-xs-12">
                                <?php echo $form[$field] ?>
                            </div>

                        </div>
                    <?php } ?>

                    <div class="row form-group"  style="margin-top: 10px">

                        <div class="col-xs-12">
                            <label>
                                <?php echo $form["accept_tos"]->getInputTag() ?>
                                <?php printf(__("Acepto %slos términos y condiciones%s al registrarme.", "ubiqa"), '<a href="'. LEGAL_URL .'">', '</a>')?>
                            </label>
                        </div>

                    </div>

                    <div class="row form-group"  style="margin-top: 20px">

                        <div class="col-xs-6">
                            <button type="submit" class="btn btn-primary btn-rounded"><?php _e("Crear cuenta", "ubiqa") ?></button>
                        </div>

                    </div>

                    <hr>
<?php if(_requisites()){ ?>
                    <h5><?php _e("También puedes acceder con", "ubiqa") ?></h5>

                    <div class="btn-group">

                        <a class="btn btn-default btn-rounded"  href="<?php echo _u()->genUrl("social_redirect", array("service"=>"facebook")) ?>"><?php _e("Facebook", "ubiqa") ?></a>
                        <a class="btn btn-default btn-rounded"  href="<?php echo _u()->genUrl("social_redirect", array("service"=>"twitter")) ?>"><?php _e("Twitter", "ubiqa") ?></a>
                        <a class="btn btn-default btn-rounded" href="<?php echo _u()->genUrl("social_redirect", array("service"=>"google")) ?>"><?php _e("Google", "ubiqa") ?></a>


                    </div>
<?php } ?>
                </form>



            </div>
        </div>
    </section>

<?php get_footer() ?>