<?php



define("AGENDA_URL", get_post_type_archive_link( "agenda" ));
define("PROJECTS_URL", get_post_type_archive_link( "subproject" ));
define("ROUTES_URL", get_post_type_archive_link( "route" ));
define("CONTENTS_URL", get_post_type_archive_link( "content" ));

define("BLOG_URL", get_permalink( get_option( 'page_for_posts', -1 ) ));
define("ABOUT_URL", get_permalink( get_option("about_page_id", -1) ));
define("LEGAL_URL", get_permalink( _u()->getConfigOption("tos_page_id") ));
define("PRIVACY_URL", get_permalink( get_option("privacy_page_id", -1) ));

define("FACEBOOK_URL", _u()->getConfigOption("facebook_url"));
define("TWITTER_URL", _u()->getConfigOption("twitter_url"));
define("INSTAGRAM_URL",  _u()->getConfigOption("instagram_url"));

?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no, maximum-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title><?php wp_title(''); if(!is_front_page()){ echo " - "; } bloginfo("name") ?></title>
    <?php wp_head() ?>
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->

    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
    <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
    <style>
        <?php echo _u()->getCustomStyles() ?>
    </style>



    <script type="text/javascript">
        var map_config = <?php echo json_encode(_u()->get("map_config", array())) ?>;

    </script>

    <link rel="stylesheet" href="//cdn.leafletjs.com/leaflet-0.7.5/leaflet.css" />
    <script src="//cdn.leafletjs.com/leaflet-0.7.5/leaflet.js"></script>
</head>
<body>

<?php include 'includes/top.php' ?>