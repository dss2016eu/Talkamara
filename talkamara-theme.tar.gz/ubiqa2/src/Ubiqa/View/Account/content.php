<?php
/**
 * Created by PhpStorm.
 * User: Asier
 * Date: 30/07/14
 * Time: 21:51
 */

get_header();
$form = _u()->get("form");


?>
<div class="bg-white-2">
    <ul class="breadcrumb container inline">
        <li class="breadcrumb-item"><a href="<?php echo _u()->getUrl() ?>"><?php _e("inicio", "ubiqa") ?></a></li>
        <li class="breadcrumb-item"><?php _e("tu cuenta", "ubiqa") ?></li>
    </ul>
</div>

<section class="bg-white-1">
    <div class="container bg-white" id="account-form">




        <div class="grid air-h" data-tabs="account-tabs">

            <?php
                $active = "content";
                include '_sidebar.php'
            ?>


            <div class="col-s-12 col-m-9 col-s-12 air-h">




                <div data-tab-content="contents">


                    <div class="form-block">
                        <span class="txt-bold"><?php _e("Tu contenido", "ubiqa") ?></span>
                    </div>

                    <?php if($message = _u()->get("sense.model.user")->getFlash("notice")){ ?>
                        <div class="alert alert-success"><?php echo $message ?></div>
                    <?php } ?>


                    <div data-tab-content="contents" style="display: block;">
                        <div class="form-block contents-header">
                            <div class="content-title">
                                <?php _e("Título de contenido", "ubiqa") ?>
                            </div>
                            <div>
                                <?php _e("Fecha", "ubiqa") ?>
                            </div>
                        </div>
                        <ul class="contents-data">
                            <?php while(have_posts()){ the_post();  //foreach(_u()->get("items") as $item){ \setup_postdata($GLOBALS['post'] = $item)  ?>


                                <li>
                                    <div class="content-title"><?php the_title() ?></div>
                                    <div><?php echo get_the_date("d-m-Y H:i") ?></div>
                                    <div class="content-buttons">
                                        <a href="<?php echo _u()->genUrl("user_content_edit", array("content_id"=>get_the_ID())) ?>" class="edit"><i class="fa fa-pencil"></i></a>
                                        <a href="<?php echo _u()->genUrl("user_content_remove", array("content_id"=>get_the_ID())) ?>"  onclick="return confirm('<?php _e("¿estás seguro/a?", "ubiqa") ?>')" class="trash"><i class="fa fa-trash-o"></i></a>
                                    </div>
                                </li>


                            <?php } ?>


                        </ul>
                        <div class="account_pagination">
                            <?php echo _u()->paginateLinks() ?>
                        </div>
                    </div>



                </div>

            </div>
        </div>

    </div>
</section>
<?php
get_footer();