<?php
/**
 * Created by PhpStorm.
 * User: Asier
 * Date: 26/07/14
 * Time: 18:53
 */

namespace Ubiqa\Controller;


use Sense\AbstractController;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Ubiqa\Model\AgendaModel;

class AgendaController extends AbstractController {


    function ajaxCalendarAction(){

        $request = Request::createFromGlobals();
        if($request->get("start") && $request->get("end")){

            $model = new AgendaModel();

            $start = \DateTime::createFromFormat("Y-m-d", $request->get("start"));
            $end = \DateTime::createFromFormat("Y-m-d", $request->get("end"));
            $items = $model->ajaxEvents($start, $end);

            $response = new JsonResponse($items);
            $response->send();

            die();

        }

    }

} 