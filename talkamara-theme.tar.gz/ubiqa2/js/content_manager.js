function ContentManager(
    masonry_grid,
    map_container,
    ajax_url,
    ajax_map_url,
    ajax_map_preview_url,
    preview_container,
    loading){



    var page  = 1;
    var _count=0;

    var spiner  = loading;
    var url     = ajax_url;
    var map_url            = ajax_map_url;
    var map_preview_url    = ajax_map_preview_url;
    var grid               = masonry_grid;

    var map_container         = map_container;
    var map_content_container = preview_container;

    var map     = null;

    var bounds         = null;
    var marker_cluster = null;
    var map_items      = [];
    var latlon         = [];


    var setPage = function(filter_data){

        var page_index = -1;
        for(var i in filter_data){
            if(filter_data[i].name == "_page"){

                page_index = i;

            }
        }
        if(page_index!=-1){
            filter_data.splice(page_index, 1);
        }

        filter_data.push({
            name: "_page",
            value: page
        });


    };

    var setMapJsonIndicatorParam = function(filter_data){

        var page_index = -1;
        for(var i in filter_data){
            if(filter_data[i].name == "map_json"){

                page_index = i;

            }
        }
        if(page_index!=-1){
            filter_data.splice(page_index, 1);
        }

        filter_data.push({
            name: "map_json",
            value: true
        });


    };

    var getMarkerIcon = function(type){
        var icon = null;
        var icon_config = {
            iconUrl:   "",

            iconSize:     [58, 66],
            iconAnchor:   [26.65, 62]
        };

        switch (type){



            case 'image':
                icon_config.iconUrl =  window.images_url + '/markers/img-marker.png';
                break;
            case 'video':
                icon_config.iconUrl =  window.images_url + '/markers/video-marker.png';
                break;
            case 'audio':
                icon_config.iconUrl =  window.images_url + '/markers/audio-marker.png';
                break;

            default :

        }

        icon = L.icon(icon_config);
        return icon;


    };





    return {

        initMap: function(){


            map_content_container.hide();

            if(map) return;

            var osmUrl    = window.map_config.tile_url;
            var osmAttrib = window.map_config.attribution;
            var osm       = new L.TileLayer(osmUrl, {minZoom: 1, maxZoom: 19, attribution: osmAttrib});


            map = L.map(map_container.attr("id"), {
                scrollWheelZoom: false,
                zoomControl: false
            });

            map.addLayer(osm);
            new L.Control.Zoom({ position: 'bottomright' }).addTo(map);

            var self = this;
            marker_cluster = L.markerClusterGroup();

            var _initial_position = map_items[0] || new L.latLng(43.26,-2.94);

            map.setView(_initial_position, 14);


        },
        loadMapItems: function(filter_data){

            spiner.show();
            map.removeLayer(marker_cluster);
            marker_cluster = L.markerClusterGroup();

            setMapJsonIndicatorParam(filter_data);

            latlon    = [];
            map_items = [];




            var _this = this;

            $.ajax({
                data:   filter_data,
                method: "GET",
                url:    map_url,
                dataType: "json",
                success: function(data){

                    for(var i in map_items){
                        removeLayer(map_items[i]);
                        map_items[i] = null;
                    }

                    for(var i in data){

                        (function(){
                            var post_id = data[i].id;
                            var type    = data[i].type;

                            var position = new L.latLng((data[i].lat), (data[i].lon));
                            latlon.push(position);


                            map_items[i] = L.marker(position, {icon: getMarkerIcon(type)}).on("click", function() {


                                _this.showContent(post_id, position);


                            });

                            marker_cluster.addLayer(map_items[i]);

                        })();

                    }

                    map.addLayer(marker_cluster);
                    spiner.fadeOut();

                    _this.adjustMap(map_content_container.is(":visible")?map_content_container.height():null);


                }

            });


        },
        showContent: function(post_id, position){

            spiner.show();
            var _this = this;
            var _position = position;
            $.get(map_preview_url, {id: post_id}, function(data){

                map_content_container.html(data);
                map_content_container.show("fast", function(){

                    spiner.hide();

                    _this.adjustMap(map_content_container.find(".container").first().height(), _position, true);


                    map_content_container.find(".container").first().fitVids();
                });


            });




        },
        updateMapSize: function(force_position, not_fit) {
            map.invalidateSize();



            if (force_position) {

                map.setView(force_position, 17);

            } else if (latlon.length > 1 && !not_fit) {
                map.fitBounds(bounds);
            }



        },
        adjustMap: function(height, position, no_fit){


            var _this = this;

            if(height && height<400){
                height = 400;
            }

            $(map_container).animate({height: height?height:500},100, function(){



                if(no_fit){
                    map.invalidateSize();
                    if(position) map.panTo(position);
                    //_this.updateMapSize(position);
                }else{
                    bounds = L.latLngBounds(latlon);
                    if(latlon.length>1){
                        map.fitBounds(bounds);
                    }
                    if(position) _this.updateMapSize(position);
                }


            });

        },
        count: function(filter_data){


            $.ajax({
                url: url + "?count=1",
                async: false,
                dataType: "json",
                data: filter_data,
                success: function(data){
                    _count = data;
                }
            });
        },
        reset: function(filter_data, input){

            page = 1;
            input.show();
            spiner.show();

            this.count(filter_data);


            setPage(filter_data);
            var _this = this;

            if(_count < page){
                $(input).fadeOut();
                spiner.hide();
                return;
            }

            $.ajax({
                data:   filter_data,
                method: "GET",
                url:    url,
                dataType: "html",
                success: function(data){

                    var items = $(data);

                    _this.setGridContent(items);

                    spiner.fadeOut();
                    page++;
                    if(!data.trim() || _count < page){

                        $(input).fadeOut();
                    }

                }

            });



        },
        appendGridContent: function(items){
            var items = items;



            grid.append(items).masonry("appended", items);

            var pending_thumbs = $(grid).find(".vpending");


            if(pending_thumbs.length){


                setTimeout(function(){

                    pending_thumbs.each(function(){
                        var id = $(this).attr("data-rel");
                        var self = this;

                        $.getJSON("/update-vimeo-thumb", {id: id}, function (data) {

                            $("#card_image_" + id + " img").attr("src", data.src);
                            grid.masonry('layout');

                        });
                    })

                }, 2000);
            }

            imagesLoaded(items, function() {
                grid.masonry('layout');
            });
        },
        setGridContent: function(items){
            var items = items;
            imagesLoaded(items, function() {
                grid.html(items);
                grid.masonry("reloadItems").masonry('layout');
            });
        },
        reload: function(filter_data, input){
            spiner.show();
            if(!_count) this.count(filter_data);

            if(_count < page){
                $(input).fadeOut();
                spiner.hide();
                return;
            }



            setPage(filter_data, page);

            var _this = this;




            $.ajax({
                data:   filter_data,
                method: "GET",
                url:    url,
                dataType: "html",
                success: function(data){

                    var items = $(data);

                    page++;
                    if(!data.trim() || _count < page){

                        $(input).fadeOut();
                    }

                    if(data){
                        _this.appendGridContent(items);
                    }

                    spiner.fadeOut();






                }

            });

        }

    };



};