jQuery(document).ready(function($){





        $('.filebox input[type=file]').on('change', function(evt){
            var files = evt.originalEvent.target.files;
            var file_name = "";
            for(var i = 0, len = files.length; i < len; i++){
                file_name = files[i].name;
            }
            if(file_name !== ""){
                $("#" + evt.target.attributes.getNamedItem("data-text").value).val(file_name);
            }
        });


    $("#content_info_type").change(function(){


        if($("#has_oembed_container").attr("data-edit_mode")){
            $("#has_oembed_container").removeAttr("data-edit_mode");
        }else{
            $("#has_oembed_container").addClass("hide");
            $("#content_info_oembed_data").val("");
            $("#has_oembed_container").find(".content").html("");
        }



        if($(this).val() == "video"){

            $(".upload_toggle").hide();
            $(".url input").attr("required", "required");
            $("#vimeo_loading").hide();
            $("#vimeo_help").show();
            $("#vimeo_iframe").show();
            $(".depends-video").hide();

            $(".url").show();
            $(".file").hide();
            $(".url input").attr("required", "required");
            $(".file input").removeAttr("required");

        }else{

            $(".upload_toggle").show();
            $(".url input").removeAttr("required");
            $("#vimeo_iframe").hide();
            $("#vimeo_loading").hide();
            $("#vimeo_help").hide();
            $(".depends-video").show();

        }
    }).trigger("change");


    function update_info_url(object){



        if($("#content_info_type").val()=="video"){



            if($(object).val() != ""){
                $(".depends-video").show();
                $("#vimeo_iframe").hide();
                $("#vimeo_loading").hide();
                $("#vimeo_help").hide();
            }else{
                $(".depends-video").hide();
                $("#vimeo_iframe").show();
                $("#vimeo_loading").hide();
                $("#vimeo_help").show();
            }

        }
    };

    $("#language_tabs .tab").click(function(){
        $("#language_tabs").find("input, textarea").removeAttr("required");

        $("#" + $(this).attr("data-tab-show") ).find("input").each(function(){
            $(this).attr("required", "required");

        });

    });
    $("#language_tabs .tab.active").trigger("click");

    $("#content_info_url").on("paste keyup", function(e){

        var self = this;
        var url = "";
        setTimeout(function(e) {
            url = $(self).val();
            $.get(window.oembed_url,{url: url}, function(data){
                if(data){
                    $("#has_oembed_container").removeClass("hide");
                    $("#has_oembed_container").find(".content").html(data);
                }else{
                    $("#has_oembed_container").addClass("hide");
                    $("#has_oembed_container").find(".content").html("");
                }
                $("#content_info_oembed_data").val(data);

            });
        }, 1500);




    });

    $("#content_info_url").blur(function(){


            update_info_url(this);


    });

    $("#content_info_url").bind("iframe_update", function(){



        update_info_url(this);


    });



    $(".upload_toggle a").click(function(e){
        e.preventDefault();

        var rel = $(this).attr("data-rel");

        if(rel=="file"){
            $(".file").show();
            $(".url").hide();
            $(".file input").attr("required", "required");
            $(".url input").removeAttr("required");
        }else{
            $(".url").show();
            $(".file").hide();
            $(".url input").attr("required", "required");
            $(".file input").removeAttr("required");
        }


    });

    $(".url input").attr("required", "required");





});