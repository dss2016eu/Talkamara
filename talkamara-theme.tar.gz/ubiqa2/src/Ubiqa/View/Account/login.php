<?php get_header() ?>

    <section class="bg-white">
        <div class="grid container">
            <div class="col-m-8 col-l-9">
                <div class="container">
                    <div class="flx-h-m">
                        <div class="flx-1">
                            <h1><?php _e("iniciar sesión", "ubiqa") ?></h1>
                        </div>
                    </div>
                </div>
                <hr>


                <form class="panel-body" method="post" action="">

                    <?php if($error = _u()->get("error")){ ?>
                        <div class="alert alert-danger">
                            <p>
                                <?php echo $error ?>
                            </p>
                        </div>
                    <?php } ?>

                    <div class="row">
                        <div class="col-xs-12">
                            <?php if($message = _u()->getUserModel()->getFlash("notice")){ ?>
                                <div class="alert alert-success"><?php echo $message ?></div>
                            <?php } ?>
                        </div>
                    </div>

                    <div class="row form-group">

                        <div class="col-xs-12">
                            <input name="username" type="text" class="form-control" placeholder="<?php _e("Email o nombre de usuario", "ubiqa") ?>">
                        </div>

                    </div>
                    <div class="row form-group">

                        <div class="col-xs-6">
                            <input name="password" type="password" class="form-control" placeholder="<?php _e("Clave de usuario", "ubiqa") ?>">
                        </div>
                        <div class="col-xs-6" style="margin-top: 10px">
                            <a href="<?php echo _u()->genUrl("resetPassword") ?>"><?php _e("¿olvidaste la contraseña?", "ubiqa") ?></a>
                        </div>
                    </div>
                    <div class="row form-group" style="margin-top: 20px">

                        <div class="col-xs-6">
                            <button type="submit" class=" btn-rounded "><?php _e("Iniciar sesión", "ubiqa") ?></button> <?php _e("o", "ubiqa") ?>
                            <a href="<?php echo _u()->genUrl("register") ?>"><?php _e("crear cuenta", "ubiqa") ?></a>
                        </div>

                    </div>

                    <hr>

                    <?php if(_requisites()){ ?>
                        <h5><?php _e("También puedes acceder con", "ubiqa") ?></h5>

                        <div class="btn-group">

                            <a class="btn btn-default  btn-rounded"  href="<?php echo _u()->genUrl("social_redirect", array("service"=>"facebook")) ?>"><?php _e("Facebook", "ubiqa") ?></a>
                            <a class="btn btn-default  btn-rounded"  href="<?php echo _u()->genUrl("social_redirect", array("service"=>"twitter")) ?>"><?php _e("Twitter", "ubiqa") ?></a>
                            <a class="btn btn-default  btn-rounded" href="<?php echo _u()->genUrl("social_redirect", array("service"=>"google")) ?>"><?php _e("Google", "ubiqa") ?></a>


                        </div>
                    <?php } ?>
                </form>



            </div>
        </div>
    </section>

<?php get_footer() ?>