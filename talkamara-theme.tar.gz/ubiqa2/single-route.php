<?php get_header(); if ( have_posts() ) { while ( have_posts() ) { the_post(); ?>


<div class="bg-white-2">
    <ul class="breadcrumb container inline">
        <li class="breadcrumb-item"><a href="<?php echo _u()->getUrl() ?>"><?php _e("inicio", "ubiqa") ?></a></li>
        <li class="breadcrumb-item"><a href="<?php echo ROUTES_URL ?>"><?php _e("rutas", "ubiqa") ?></a></li>
        <li class="breadcrumb-item"><?php the_title() ?></li>
    </ul>
</div>

<div class="bg-white-2">

    <article class="app-content flx-h-m container">
        <div class="flx-1 scroll bg-white air" id="ruta-left">
            <div class="container">
                <h1 class="air-v"><b><?php the_title() ?></b></h1>
                <?php the_content() ?>

            </div>
            <div class="container">
                <div id="route_steps" data-tabs="steps">

                    <?php $number = 0; foreach(_u()->get("contents") as $step=>$content){
                        setup_postdata( $content ); include "includes/route-step.php"; } ?>

                </div>

            </div>
        </div>

        <div id="ruta-right" class="content-map routes-map">
            <div id="map" class="content-right-map"></div>
        </div>
    </article>
    <br>
    <br>
</div>

<script type="text/javascript">

    var markers_info = <?php echo json_encode(_u()->get("markers_info")) ?>;



</script>

<?php }} get_footer() ?>


