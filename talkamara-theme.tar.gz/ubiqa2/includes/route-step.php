<?php

//$number = _u()->get("content")->getMeta($content->ID, "ubiqa_content_route_position")?:$step;



if(_u()->get("content")->getMeta($content->ID, "ubiqa_content_lat") &&  _u()->get("content")->getMeta($content->ID, "ubiqa_content_lon")){

    $number++;
?>


<hr>
<div id="title_<?php echo $content->ID ?>"
     class="flx-h route_title"
     data-pos="<?php echo $number ?>"
     data-slide-activate="step-<?php echo $content->ID ?>">
    <div class="step-number btn-circle"><?php echo $number ?></div>
    <div class="step-title flx-<?php echo $content->ID ?>">
        <b><?php echo get_the_title($content) ?></b>
    </div>
    <div class="step-number air-h">
        <div class="btn-circle">
            <i class="fa"></i>
        </div>
    </div>
</div>
<div class="step-content" id="step-<?php echo $content->ID ?>">
    <div class="container">
        <div><?php echo _u()->getContentView($content->ID) ?></div>

    </div>
    <p><?php echo get_the_content() ?></p>
    <a href="<?php echo get_the_permalink($content->ID) ?>" class="btn-rounded">
        <i class="fa fa-eye"></i> <span>&nbsp;<?php _e("Ver Más", "ubiqa") ?></span>
    </a>
</div>

<?php } ?>