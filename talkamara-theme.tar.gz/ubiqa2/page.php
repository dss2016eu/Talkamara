<?php get_header();  if ( have_posts() ) { while ( have_posts() ) { the_post();   ?>

    <section class="bg-white">

        <div class="container grid air-b">
            <div class="col-s-12 col-m-12 col-l-12">
                <div class="container">
                    <div class="flx-h-m">
                        <div class="flx-1">
                            <h1><?php the_title() ?></h1>
                        </div>
                        <div>
                            <?php include 'includes/single-share.php' ?>
                        </div>
                    </div>
                </div>
                <hr>
                <div class="txt-big">
                    <?php the_content() ?>
                </div>
            </div>
        </div>

    </section>



<?php }} get_footer() ?>