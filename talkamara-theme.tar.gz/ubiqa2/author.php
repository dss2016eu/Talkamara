<?php get_header();



$user_profile = _u()->get("sense.model.user")->getUser($author);
?>


    <div class="bg-white-2">
        <ul class="breadcrumb container inline">
            <li class="breadcrumb-item"><a href="<?php echo _u()->getUrl() ?>"><?php _e("inicio", "ubiqa") ?></a></li>
            <li class="breadcrumb-item"><?php _e("usuario", "ubiqa") ?></li>
        </ul>
    </div>

    <section id="contenidos" class="bg-white">
    <div class="grid container">
    <div id="user-content" class="user-content col-m-8 col-l-9">
        <div class="container">
            <div class="flx-h-m">
                <div class="flx-1">
                    <h3><?php _e("Contenidos de", "ubiqa") ?> <span class="capitalize"><?php echo $user_profile->display_name ?></span></h3>
                </div>
            </div>
        </div>
        <hr>
        <div class="content-container">
            <!-- bloque de contenidos de usuario -->
            <!-- contenidos de usuario -->
            <section class="bg-white-1" data-tab-content="content-cards">

                <div class="container">

                    <div id="user_grid" class="grid masonry cards">


                    </div>
                    <div class="air">
                        <div id="user_loading" class="spinner" style="display: none"><div></div></div>
                        <button id="user_load_more" class="btn-default full-w"><?php _e("Ver más", "ubiqa") ?></button>
                    </div>
                </div>
            </section>

        </div>
    </div>
    <div id="user-name" class="col-s-12 col-m-4 col-l-3 txt-center">
        <div class="form-blocks auto-margin-s no-margin-r-l">
            <div class="form-block">
                <div class="lazy-img img-rounded auto-margin">
                    <img src="<?php echo _u()->getAvatarUrl($user_profile, array(400,200)) ?>" alt="">
                </div>
                <br>
                <div class="air">
                    <b class="txt-big"><?php echo $user_profile->display_name ?></b>
                </div>
                <div>
                    <span class="txt-italic"><?php echo $user_profile->description ?></span>
                </div>
                <div class="air-t">
                    <a href="#contenidos" class="btn-rounded"><span><?php _e("CONTENIDOS SUBIDOS", "ubiqa") ?></span></a>
                </div>
                <div class="air-t">
                    <a href="#favoritos" class="btn-rounded"><span><?php _e("FAVORITOS", "ubiqa") ?></span></a>
                </div>
            </div>

        </div>
    </div>
    </div>
    </section>

    <section id="favoritos" class="bg-white">
        <div class="grid container">
            <div class="col-m-8 col-l-9">
                <div class="container">
                    <div class="flx-h-m">
                        <div class="flx-1">
                            <h3><?php _e("Favoritos de", "ubiqa") ?> <span><?php echo $user_profile->display_name ?></span></h3>
                        </div>
                    </div>
                </div>
                <hr>
                <div class="content-container">
                    <!-- bloque de contenidos de usuario -->
                    <!-- contenidos de usuario -->
                    <section class="bg-white-1" data-tab-content="content-cards">

                        <div class="container">

                            <div id="fav_grid" class="grid masonry cards">

                            </div>
                            <div class="air">
                                <div id="fav_loading" class="spinner" style="display: none"><div></div></div>
                                <button id="fav_load_more" class="btn-default full-w"><?php _e("Ver más", "ubiqa") ?></button>
                            </div>
                        </div>
                    </section>
                    <!-- Favoritos de Usuario -->

                </div>
            </div>
        </div>
    </section>


    <script type="text/javascript">
        var  user_url = "<?php echo _u()->genUrl("ajax_author") ?>";
        var  user_favs_url = "<?php echo _u()->genUrl("ajax_author_favs") ?>";
        var user_id = <?php echo $user_profile->ID ?>;
    </script>

<?php get_footer() ?>