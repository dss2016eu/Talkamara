<?php
/**
 * Created by PhpStorm.
 * User: Asier
 * Date: 26/07/14
 * Time: 17:40
 */

namespace Ubiqa\Interceptor;


use Sense\AbstractInterceptor;
use Sense\AssetManager;
use Ubiqa\Model\AgendaModel;

class AgendaInterceptor extends AbstractInterceptor {


    function execute(\WP_Query $query){

        /**
         * @var $asset_manager AssetManager
         */
        $asset_manager = $this->get("sense.theme_assets");
        $asset_uri     = $this->get("%wp.template_uri%");


        //$asset_manager->addScript('fullcalendar', $asset_uri . '/js/fullcalendar/fullcalendar.min.js');
        $asset_manager->addScript('agenda', $asset_uri . '/js/agenda.js', 1, true, array("jquery-ui-datepicker"));
        //$asset_manager->addStyle('fullcalendar', $asset_uri . '/js/fullcalendar/fullcalendar.css');

        $model = new AgendaModel();
        $query->query_vars = $model->agendaEventsQB(new \DateTime("yesterday"))->limit(5)->getWPQueryVars();



//        $query->query_vars["meta_query"] = array(
//            array(
//                'key' => 'ubiqa_event_data_datetime',
//                'value' => date('Y-m-d H:i:s'),
//                'compare' => '>=',
//                'type' => 'datetime'
//            )
//        );
//
//
//        $query->query_vars["orderby"] = "ubiqa_event_data_datetime";
//        $query->query_vars["order"]   = "ASC";





    }

} 