<?php
/**
 * Created by PhpStorm.
 * User: Asier
 * Date: 28/07/14
 * Time: 22:36
 */

namespace Ubiqa\Config;


use Sense\Router;

class RoutingConfig {


    function setRoutes(Router $router){


        $router->addRule('api_login', '/api/v1/authenticate', array("__controller" => "Ubiqa\Controller\ApiController", "__action" => "login"));
        $router->addRule('api_config', '/api/v1/configuration', array("__controller" => "Ubiqa\Controller\ApiController", "__action" => "config"));
        $router->addRule('api_projects', '/api/v1/projects', array("__controller" => "Ubiqa\Controller\ApiController", "__action" => "projects"));
        $router->addRule('api_topics', '/api/v1/topics', array("__controller" => "Ubiqa\Controller\ApiController", "__action" => "topics"));
        $router->addRule('api_contents', '/api/v1/contents', array("__controller" => "Ubiqa\Controller\ApiController", "__action" => "contents"));
        $router->addRule('api_contents_edit', '/api/v1/contents/{id}/edit', array("__controller" => "Ubiqa\Controller\ApiController", "__action" => "contentEdit"));
        $router->addRule('api_contents_remove', '/api/v1/contents/{id}/remove', array("__controller" => "Ubiqa\Controller\ApiController", "__action" => "contentRemove"));
        $router->addRule('api_project_contents', '/api/v1/projects/{project_id}/contents', array("__controller" => "Ubiqa\Controller\ApiController", "__action" => "contents"));


        include "api_v2_routing.php";


        $router->addRule('vimeo_iframe', '/vimeo-form', array("__controller" => "Ubiqa\Controller\SocialController", "__action" => "vimeoIframe"));
        $router->addRule('social_twitter_email', '/social-auth/twitter-email', array("__controller" => "Ubiqa\Controller\SocialController", "__action" => "twitterEmail"));
        $router->addRule('social_auth', '/social-auth', array("__controller" => "Ubiqa\Controller\SocialController", "__action" => "oauthBack"));


        $router->addRule('social_redirect', '/login-redirect/{service}', array("__controller" => "Ubiqa\Controller\SocialController", "__action" => "loginRedirect"));


        $router->addRule('login', '/login', array("__controller" => "Ubiqa\Controller\AccountController", "__action" => "login"));
        $router->addRule('register', '/registro', array("__controller" => "Ubiqa\Controller\AccountController", "__action" => "register"));
        $router->addRule('resetPassword', '/resetear-clave', array("__controller" => "Ubiqa\Controller\AccountController", "__action" => "resetPassword"));
        $router->addRule('password', '/tu-cuenta/clave', array("__controller" => "Ubiqa\Controller\AccountController", "__action" => "password"));
        $router->addRule('account', '/tu-cuenta', array("__controller" => "Ubiqa\Controller\AccountController", "__action" => "index"));


        $router->addRule('user_content', '/tu-cuenta/contenido/?', array("__controller" => "Ubiqa\Controller\ContentController", "__action" => "user"));
        $router->addRule('user_content_paged', '/tu-cuenta/contenido/page/{paged}/?', array("__controller" => "Ubiqa\Controller\ContentController", "__action" => "user"), array("paged"=>'(\d+)'));



        $router->addRule('user_content_edit', '/tu-cuenta/contenido/{content_id}', array("__controller" => "Ubiqa\Controller\ContentController", "__action" => "edit"));
        $router->addRule('user_content_remove', '/tu-cuenta/contenido/{content_id}/remove', array("__controller" => "Ubiqa\Controller\ContentController", "__action" => "remove"));

        $router->addRule('user_favs', '/tu-cuenta/favoritos', array("__controller" => "Ubiqa\Controller\ContentController", "__action" => "userFavs"));
        $router->addRule('user_favs_pages', '/tu-cuenta/favoritos/page/{paged}', array("__controller" => "Ubiqa\Controller\ContentController", "__action" => "userFavs"));


        $router->addRule('fav_content', '/fav-content/{content_id}', array("__controller" => "Ubiqa\Controller\ContentController", "__action" => "addFav"));
        $router->addRule('fav_content_remove', '/fav-content/{content_id}/remove', array("__controller" => "Ubiqa\Controller\ContentController", "__action" => "removeFav"));
        $router->addRule('like_content', '/like-content/{user_id}-{content_id}', array("__controller" => "Ubiqa\Controller\ContentController", "__action" => "addLike"));
        $router->addRule('like_content_remove', '/like-content/{user_id}-{content_id}/remove', array("__controller" => "Ubiqa\Controller\ContentController", "__action" => "removeLike"));

        $router->addRule('ajax_embed_preview', '/ajax/embed_preview', array("__controller" => "Ubiqa\Controller\ContentController", "__action" => "ajaxEmbedPreview"));

        $router->addRule('ajax_blog_items', '/ajax/blog-items', array("__controller" => "Ubiqa\Controller\BlogController", "__action" => "ajaxItems"));

        $router->addRule('ajax_route_items', '/ajax/route-items', array("__controller" => "Ubiqa\Controller\ContentController", "__action" => "ajaxRoutes"));

        $router->addRule('ajax_project_items', '/ajax/project-items', array("__controller" => "Ubiqa\Controller\ContentController", "__action" => "ajaxProjects"));

        $router->addRule('ajax_content_items', '/ajax/content-items', array("__controller" => "Ubiqa\Controller\ContentController", "__action" => "ajaxContentItems"));

        $router->addRule('ajax_author', '/ajax/author-items', array("__controller" => "Ubiqa\Controller\ContentController", "__action" => "ajaxAuthorItems"));

        $router->addRule('ajax_author_favs', '/ajax/author-fav-items', array("__controller" => "Ubiqa\Controller\ContentController", "__action" => "ajaxAuthorFavItems"));


        $router->addRule('ajax_content_mapitem', '/ajax/content-item-map', array("__controller" => "Ubiqa\Controller\ContentController", "__action" => "mapPreview"));

        $router->addRule('ajax_content_topic_ids', '/ajax/content-topic-ids', array("__controller" => "Ubiqa\Controller\ContentController", "__action" => "ajaxTopicIds"));

        $router->addRule('ajax_search', '/ajax/search', array("__controller" => "Ubiqa\Controller\ContentController", "__action" => "ajaxSearch"));



        $router->addRule('add_content_login', '/nuevo-contenido', array("__controller" => "Ubiqa\Controller\ContentController", "__action" => "newLogin"));
        $router->addRule('add_content_info', '/nuevo-contenido/paso1', array("__controller" => "Ubiqa\Controller\ContentController", "__action" => "newInfo"));
        $router->addRule('add_content_geo', '/nuevo-contenido/{content_id}/paso2', array("__controller" => "Ubiqa\Controller\ContentController", "__action" => "newGeo"));
        $router->addRule('add_content_topics', '/nuevo-contenido/{content_id}/paso3', array("__controller" => "Ubiqa\Controller\ContentController", "__action" => "newTopics"));
        $router->addRule('update_vimeo_thumb', '/update-vimeo-thumb', array("__controller" => "Ubiqa\Controller\ContentController", "__action" => "ajaxSetVimeoThumbnail"));

    }

} 
