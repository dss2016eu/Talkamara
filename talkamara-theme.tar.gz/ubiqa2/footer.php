<!-- footer -->
<footer id="main-footer" class="container air">
    <div class="grid">
        <div id="footer-col-1" class="footer-col col-6 col-m-3">

            <?php dynamic_sidebar("footer_left") ?>

        </div>
        <div id="footer-col-2" class="footer-col col-6 col-m-3 flx-h">
            <div class="flx-1">&nbsp;</div>
            <div>
                <?php dynamic_sidebar("footer_center") ?>
            </div>
            <div class="flx-1">&nbsp;</div>
        </div>
        <div id="footer-col-3" class="footer-col col-6 col-m-3 flx-h">
            <div class="flx-1">&nbsp;</div>
            <div>
                <?php dynamic_sidebar("footer_right") ?>
            </div>
            <div class="flx-1">&nbsp;</div>
        </div>
        <div id="footer-col-4" class="footer-col col-6 col-m-3">
            <?php dynamic_sidebar("footer_credits") ?>
        </div>
    </div>
</footer>
<!-- /footer -->
<div id="sub-footer" class="bg-dark txt-white">
    <?php _e("Plataforma desarrollada con Ubiqarama", "ubiqa") ?>
    <?php if(LEGAL_URL){ ?> | <a href="<?php echo LEGAL_URL ?>"><?php _e("Términos y condiciones", "ubiqa") ?></a><?php } ?>

</div>







<script type="text/javascript">

    var markers_info = <?php echo json_encode(_u()->get("markers_info")) ?>;
    var images_url = "<?php echo get_template_directory_uri() . "/images/"; ?>";
    var contents_ajax_url =  "<?php echo _u()->genUrl("ajax_content_items") ?>";
    var validator_messages = {
        required: "<?php _e("el campo es obligatorio", "ubiqa") ?>",
        email: "<?php _e("el campo debe ser una dirección de email", "ubiqa") ?>",
        url: "<?php _e("el campo debe ser una url", "ubiqa") ?>"
    };
</script>



<?php wp_footer() ?>



</body>
</html>