jQuery(document).ready(function() {

    var grid   = $("#content_grid");
    var map           = null;
    var map_container = $("#map");
    var spiner = $(".spinner");



    var map_view = false;


    var content = new ContentManager(
        grid,
        map_container,
        window.contents_ajax_url,
        window.contents_map_ajax_url,
        window.preview_ajax_url,
        $("#map_content_preview"),
        spiner );


    $("#map_content_preview").on("click", "#close_preview", function(){
        $("#map_content_preview").html("").hide();
        content.updateMapSize(null, true);
    });

    $('#topic_filter p.choice-item').each(function(){

        var input      = $(this).find("input");
        var label      = $(this).find("label");
        input.appendTo("#topic_filter");


        /*<ul class="tags tags-borderer inline">
         <li class="tag active"><?php _e("Ocio", "ubiqa") ?></li>
         </ul>*/

        input.attr("id", "topic_" + input.val());

        input.iCheck({
            checkboxClass: 'tag topic-row',
            radioClass: 'iradio_line-blue',
            activeClass: 'active',
            insert: label.text(),
            inheritID: true
        });

        label.remove();
        this.remove();
    });
    function updateTopics(){


        $.getJSON(window.topic_ajax_ids_url,  $("#filter_form").serializeArray(), function(json){

            $(".topic-row").each(function(){


                var selected = false;

                for(var i in json){

                    var id = json[i];

                    if($(this).attr("id") == "iCheck-topic_" + id){
                        $(this).show();
                        selected = true;
                        break;
                    }


                }

                if(!selected) $(this).hide();

            });



        });

    }

    $("#filter_form :input").change(function() {

        updateTopics();

        if(map_view){
            content.loadMapItems($("#filter_form").serializeArray());
        }else{
            content.reset($("#filter_form").serializeArray(), $("#load_more"));
        }

    });
    $("#topic_filter input").on('ifToggled', function(event){

        if(map_view){
            content.loadMapItems($("#filter_form").serializeArray());
        }else{
            content.reset($("#filter_form").serializeArray(), $("#load_more"));
        }

    });

    $("#filter_search").keypress(function(e) {

        if(e.which == 13) {
            e.preventDefault();
            if(map_view){
                content.loadMapItems($("#filter_form").serializeArray());
            }else{
                content.reset($("#filter_form").serializeArray(), $("#load_more"));
            }
        }
    });

    $("#filter_is_interview_1 :input").change(function() {

        if($(this).is(":checked")){
            $("div[data-interview]").css("visibility", "visible");
        }else{
            $("div[data-interview]").css("visibility", "hidden");
        }

    });

    $("#load_more").click(function(e){

        content.reload($("#filter_form").serializeArray(), this);


    }).trigger("click");



    Ubq.Tabs.get('content-main').onChange(function(uid) {
        if(uid == 'content-map') {



            //map_container.width = $("#map_wrapper").width + 'px';
            content.initMap();

            content.loadMapItems($("#filter_form").serializeArray());

            map_view = true;

        } else {

            map_view = false;
            //MasonryLoader.init();

            grid.html("");
            content.reset($("#filter_form").serializeArray(), $("#load_more"));

        }
    });

    $(document).on("click", ".next_content_item", function(e){
        e.preventDefault();
        var id = $(this).attr("data-rel");
        content.showContent(id);
    });

    var interview_checkbox = $('#filter_is_interview');
    interview_checkbox.on('change', function(){

        if(interview_checkbox[0].checked){
            $('[data-interview]').addClass("show");
        }else{
            $('[data-interview]').removeClass("show");
        }
    });






    $('.checkbox_container > input[type=checkbox]').on('change', function(){
        if (this.checked){
            $(this).parent().addClass('checked');
        }else{
            $(this).parent().removeClass('checked');
        }
    });

});