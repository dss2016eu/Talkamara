module.exports = function(grunt) {

  grunt.initConfig ({
    pkg     : grunt.file.readJSON("package.json"),

// # =========================================================================

    cssmin: {
      options: {
        sourceMap: true
      },
      target: {
        files: {
          'style/ubiqarama.min.css': ['style/ubiqarama.css']
        }
      }
    },

    uglify: {
      options: {
        mangle: false
      },
      my_target: {
        files: {
          'js/ubiqarama.min.js': ['js/ubiqarama.js']
        }
      }
    },

    watch: {
      css: {
        files: ["style/ubiqarama.css"],
        tasks: ["cssmin"]
      },
      js: {
        files: ['js/ubiqarama.js'],
        tasks: ["uglify"]
      }
    }

  });
  grunt.loadNpmTasks('grunt-contrib-uglify');
  grunt.loadNpmTasks('grunt-contrib-cssmin');
  grunt.loadNpmTasks("grunt-contrib-watch");
  grunt.registerTask("default", ["cssmin", "uglify"]);

};
