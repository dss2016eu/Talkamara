<?php
/**
 * Created by PhpStorm.
 * User: Asier
 * Date: 5/08/14
 * Time: 12:50
 */

namespace Ubiqa\Form;

use SimpleForm\AbstractForm;
use SimpleForm\FormBuilder;
use Symfony\Component\Validator\Constraints\Email;
use Symfony\Component\Validator\Constraints\NotBlank;
use Symfony\Component\Validator\Constraints\NotNull;
use Symfony\Component\Validator\Constraints\Length;
use Ubiqa\Model\ContentModel;

class ContentTopicForm extends AbstractForm{



    public $topics = array();
    public $categories = array();
    public $languages = array();


    function __construct($data=array(), FormBuilder $builder, $topics, $categories=array()){

        $this->topics = $topics;
        $this->categories = $categories;
        $this->languages[0]= __("No definido", "ubiqa");
        foreach(_u()->getLanguages(true) as $iso=>$label){
            $this->languages[$iso] = $label;
        }

        parent::__construct($data, $builder);

    }

    function setValues(\WP_Post $post, ContentModel $model){

        $this["is_interview"]->setValue($model->getMeta($post->ID, "ubiqa_content_is_interview"));
        $this["genre"]->setValue($model->getMeta($post->ID, "ubiqa_content_genre"));
        $this["language"]->setValue($model->getMeta($post->ID, "ubiqa_content_language"));
        $this["age"]->setValue($model->getMeta($post->ID, "ubiqa_content_age"));

        $topics = array();
        $terms = wp_get_post_terms($post->ID, "topic");
        foreach($terms as $term){
            $topics[] = $term->term_id;
        }

        $cats = wp_get_post_terms($post->ID, "ubiqa_category");

        foreach($cats as $ucat){
            $this["ubiqa_category"]->setValue($ucat->term_id);
            break;
        }



        if(count($topics)) $this["topic"]->setValue($topics);


    }

    function configure(){


        $this->setName("content_topic");

        $builder = $this->getBuilder();

        $builder->add("topic", "choice", array("choices"=>$this->topics, "label"=> __("Temáticas", "ubiqa"), "class"=>"form-control", "multiple"=>true, "expanded"=>true, "required"=>false));

        $builder->add("ubiqa_category", "choice", array("choices"=>$this->categories, "label"=> __("Categoría principal", "ubiqa"), "class"=>"form-control", "required"=>false));


        $builder->add("language", "choice", array("choices"=>$this->languages,
            "label"=>__("Idioma", "ubiqa"), "class"=>"form-control","required"=> false,));

        $builder->add("route_position", "input", array("type"=>"number", "label"=>__("Posición en la ruta", "ubiqa"), "required"=> false, "class"=>"form-control"));

        $builder->add("is_interview", "input", array("type"=>"checkbox", "label"=>__("Es una entrevista", "ubiqa"), "required"=> false, "checked_value"=>1));
        $builder->add("age", "input", array("type"=>"number", "label"=>__("Edad", "ubiqa"), "required"=> false, "class"=>"form-control"));
        $builder->add("genre", "choice", array("choices"=>array(__("No definido", "ubiqa"), "male"=>__("Hombre", "ubiqa"),"female"=>__("Mujer", "ubiqa")), "label"=>__("Género"), "class"=>"form-control", "required"=>false));



    }

    function save(\WP_Post $post, ContentModel $model){
        $metas = array(
            "ubiqa_content_is_interview" => $this["is_interview"]->getValue(),
            "ubiqa_content_genre"        => $this["genre"]->getValue(),
            "ubiqa_content_language"     => $this["language"]->getValue(),
            "ubiqa_content_age"          => $this["age"]->getValue()
        );


        if($this["ubiqa_category"]->getValue()){

            //$res = wp_set_object_terms($post->ID, array((int)$this["ubiqa_category"]->getValue()), "ubiqa_category");
            $model->addTaxonomyTerms($post, array((int)$this["ubiqa_category"]->getValue()), "ubiqa_category", false);

        }


        $model->updateMetas($post, $metas);

        if($this["topic"]->getValue() && count($this["topic"]->getValue()))
            $model->addTaxonomyTerms($post, $this["topic"]->getValue(), "topic", false);





        return $post;
    }


}