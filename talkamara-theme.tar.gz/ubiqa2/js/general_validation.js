jQuery(document).ready(function($){


    jQuery.extend(jQuery.validator.messages, window.validator_messages);

    if(!window.disable_general_validation){

        $("form").each(function(){
            $(this).validate();
        });

    }

});
