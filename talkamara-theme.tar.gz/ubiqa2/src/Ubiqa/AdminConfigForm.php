<?php
/**
 * Created by PhpStorm.
 * User: Asier
 * Date: 5/08/14
 * Time: 12:50
 */

namespace Ubiqa\Form;

use SimpleForm\AbstractForm;
use SimpleForm\FormBuilder;
use Symfony\Component\Validator\Constraints\Email;
use Symfony\Component\Validator\Constraints\NotBlank;
use Symfony\Component\Validator\Constraints\NotNull;
use Symfony\Component\Validator\Constraints\Length;
use Ubiqa\Model\ContentModel;

class AdminConfigForm extends AbstractForm{



//    function setValues(\WP_Post $post, ContentModel $model){
//
//        $this["tile_url"]->setValue($model->getMeta($post->ID, "ubiqa_content_type"));
//        $this["url"]->setValue($model->getMeta($post->ID, "ubiqa_content_content_url"));
//
//
//        $this["project"]->setValue($model->getMeta($post->ID, "ubiqa_content_subproject"));
//
//        $titles = \qtrans_split($post->post_title);
//        $descriptions = \qtrans_split($post->post_content);
//
//        foreach($titles as $iso=>$title){
//            $this["title_" . $iso]->setValue($title);
//        }
//        foreach($descriptions as $iso=>$description){
//            $this["description_" . $iso]->setValue($description);
//        }
//
//    }

    function configure(){

        $options = array(__("Desactivado", "ubiqa"), __("Activado", "ubiqa"));

        $this->setName("config");

        $builder = $this->getBuilder();

        $builder->add("map_tile_url", "input", array("type"=>"url", "label"=>__("Url de mapa"), "class"=>"regular-text"));
        $builder->add("map_attribution", "text", array("label"=>__("Atribución y créditos del mapa", "ubiqa"), "class"=>"large-text", "required"=>false));

        $builder->add("vimeo_api_token", "text", array("label"=>__("Token de la API de Vimeo", "ubiqa"), "class"=>"regular-text", "required"=>false));

        $builder->add("has_category", "choice", array("choices"=>$options, "label"=>__("Activar categoría principal", "ubiqa"), "required"=> false, "class"=>"form-control "));
        $builder->add("has_interview", "choice", array("choices"=>$options, "label"=>__("Activar entrevistas", "ubiqa"), "required"=> false, "class"=>"form-control "));
        $builder->add("has_geo", "choice", array("choices"=>$options, "label"=>__("Activar localización de contenido", "ubiqa"), "required"=> false, "class"=>"form-control "));
        $builder->add("has_routes", "choice", array("choices"=>$options, "label"=>__("Activar rutas", "ubiqa"), "required"=> false, "class"=>"form-control "));


    }

//    /**
//     * @param ContentModel $model
//     * @param \WP_User $user
//     * @return \WP_Post
//     */
//    function save(ContentModel $model, \WP_User $user, \WP_Post $post=null){
//        $titles = $contents = array();
//        $first_lang = "";
//        foreach($this->languages as $iso=>$lang){
//
//            if(!$first_lang){
//                $first_lang = $iso;
//            }
//
//            $titles[$iso] = $this->getValue("title_" . $iso);
//            $contents[$iso] = $this->getValue("description_".$iso);
//        }
//
//
//
//        $data = array(
//            "post_title" => \qtrans_join($titles),
//            "post_content" => \qtrans_join($contents),
//            "post_author" => $user->ID,
//            "post_type" => "content",
//            "post_date" => \date("Y-m-d H:i:s")
//        );
//
//        if(!$post || $post->post_name){
//            $data["post_name"] = \sanitize_title($titles[$first_lang]);
//        }
//
//
//        $post = !$post ? $model->create($data) : $model->update($post, $data);
//
//        $metas = array(
//            "ubiqa_content_type" => $this["type"]->getValue(),
//            "ubiqa_content_subproject" => $this["project"]->getValue(),
//            "ubiqa_content_content_url" => $this["url"]->getValue()
//        );
//
//        $model->updateMetas($post, $metas);
//
//        return $post;
//
//    }

} 