jQuery(document).ready(function($) {



    //if($('#calendar').attr("id")){
        $('#calendar').fullCalendar({
            firstDay: 1,
            dayClick: function(date, allDay, jsEvent, view) {

                $('#calendar').fullCalendar('changeView', 'agendaDay')
                    .fullCalendar('gotoDate', date.getFullYear(), date.getMonth(), date.getDate());

            },
            buttonText:  window.buttonText,
            events:      ajaxurl + '?action=ubiqa.agenda.calendar',
            monthNames: window.monthNames,
            monthNamesShort: window.monthNamesShort,
            dayNames: window.dayNames,
            dayNamesShort: window.dayNamesShort,
            header: {
                left:   'prev',
                center: 'title',
                right:  'next'
            },
            contentHeight: "auto"
        });

    //}



});