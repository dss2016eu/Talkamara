jQuery(document).ready(function($){


    var interview_checkbox = $('#content_topic_is_interview');
    interview_checkbox.on('change', function(){
        if(interview_checkbox[0].checked){
            $('[data-interview]').addClass("show");
        }else{
            $('[data-interview]').removeClass("show");
        }
    }).trigger("change");

    $('#topic_filter p.choice-item').each(function(){

        var input      = $(this).find("input");
        var label      = $(this).find("label");
        input.appendTo("#topic_filter");


        /*<ul class="tags tags-borderer inline">
         <li class="tag active"><?php _e("Ocio", "ubiqa") ?></li>
         </ul>*/

        input.iCheck({
            checkboxClass: 'tag',
            radioClass: 'iradio_line-blue',
            activeClass: 'active',
            insert: label.text()
        });

        label.remove();
        this.remove();
    });



    if($("#map_container").attr("id")){

        console.log("test");

        var map    = null;
        var bounds = null;

        var osmUrl    = window.map_config.tile_url;
        //http://otile1.mqcdn.com/tiles/1.0.0/map/{z}/{x}/{y}.png
        //https://stamen-tiles-{s}.a.ssl.fastly.net/toner/{z}/{x}/{y}.png
        //http://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png
        var osmAttrib = window.map_config.attribution;
        var osm       = new L.TileLayer(osmUrl, {minZoom: 1, maxZoom: 19, attribution: osmAttrib});
        var latlon    = L.latLng(window.latlon?window.latlon.lat:43.26, window.latlon?window.latlon.lon:-2.94);


        map = L.map("map_container", {
            scrollWheelZoom: false
        });

        map.addLayer(osm);
        var marker = L.marker(latlon,{draggable: true}).addTo(map).on('dragend', function(event){
            var marker = event.target;
            var position = marker.getLatLng();
            //marker.setLatLng(new L.LatLng(position.lat, position.lng),{draggable:'true'});
            map.panTo(new L.LatLng(position.lat, position.lng));

            $("#content_geo_lat").val(position.lat);
            $("#content_geo_lon").val(position.lng);



        });
        map.setView(latlon, 15);


        $(".geo_input").on("change keyup", function(e){


            if(window.latlon && window.latlon.lat && window.latlon.lon) return;

            if($("#content_geo_city").val()){

                var query = $("#content_geo_city").find(":selected").text() ;

                if($("#content_geo_address").val()){
                    query = $("#content_geo_address").val() + "," + query;
                }




                $.getJSON("http://nominatim.openstreetmap.org/search/" + query + "?format=json", function(data){

                    if(data.length){
                        var latlon = L.latLng(data[0].lat, data[0].lon);
                        marker.setLatLng(latlon);
                        map.panTo(latlon);

                        $("#content_geo_lat").val(latlon.lat);
                        $("#content_geo_lon").val(latlon.lng);
                    }

                });


            }


        });


    }




});