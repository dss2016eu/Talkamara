<?php

$blog_posts = _u()->get("content")->getBlogPosts(4);
if(count($blog_posts)==4){

    ?>
    <!-- posts section -->
    <section class="bg-white-1">
        <div class="container">
            <h2 class="txt-center"><?php _e("front_last_posts", "ubiqa") ?></h2>

            <div class="grid cards masonry">


                <?php



                foreach($blog_posts as $_post){ \setup_postdata($GLOBALS['post'] = $_post)
                    ?>

                    <div class="col-m-6 col-l-3">
                        <div class="card">
                            <div class="card-image lazy-img loaded">
                                <?php

                                if($thumb = get_the_post_thumbnail(get_the_ID(),"ubiqa_blog_thumb", array("data-aspect-ratio"=>"1"))){
                                    echo $thumb;
                                }else{ ?>
                                    <img src="<?php echo _u()->getDefaultImageSrc(get_the_ID()) ?>" data-aspect-ratio="1">
                                <?php
                                }

                                ?>
                                <div class="image-overlay">
                                    <div class="pos-center txt-center">
                                        <button class="btn-rounded"><?php _e("read_more", "ubiqa") ?></button>
                                    </div>
                                    <div class="pos-br">
                                        <i class="fa fa-comment-o txt-big"></i> <b><?php comments_number( '0', '1', '%' ); ?></b>
                                    </div>
                                </div>
                            </div>
                            <div class="card-info">
                                <?php the_title() ?>
                            </div>
                        </div>
                    </div>
                <?php } ?>




            </div>

        </div>
    </section>
    <!-- /posts section -->

<?php } ?>




