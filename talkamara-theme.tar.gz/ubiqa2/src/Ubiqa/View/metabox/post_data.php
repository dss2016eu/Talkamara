
<h3><?php _e("Proyecto", "ubiqa") ?></h3>
<p>
    <select style="margin-top: -2px"  name="ubiqa_event_data[subproject]">
        <option><?php _e("Ningún proyecto asociado", "ubiqa") ?></option>
        <?php foreach($this->_container["model.project"]->getList() as $project ){ ?>
            <option <?php if($this->_model->getMeta($post->ID, "ubiqa_content_subproject")  == $project->ID) echo "selected='selected'" ?>
                value="<?php echo $project->ID ?>"><?php echo \get_the_title($project) ?></option>
        <?php } ?>
    </select>
</p>