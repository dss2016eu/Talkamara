<?php
/**
 * Created by PhpStorm.
 * User: Asier
 * Date: 26/07/14
 * Time: 18:53
 */

namespace Ubiqa\Controller;


use Sense\AbstractController;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Validator\Constraints\DateTime;
use Ubiqa\Form\ContentGeoForm;
use Ubiqa\Form\ContentInfoForm;
use Ubiqa\Form\ContentTopicForm;
use Ubiqa\HTTPAuthenticator;
use Ubiqa\Model\AdminModel;
use Ubiqa\Model\AgendaModel;
use Ubiqa\Model\ContentModel;

class ApiController extends AbstractController {


    function loginAction(Request $request){
        if(!$this->getSecurity()->isAuthenticated()){
            return $this->resultResponse(new Response("Not authenticated", 403));
        }



        $user = $this->getSecurity()->getUser();

        $avatar_url = _u()->getAvatarUrl($user);

        $model = $this->get("sense.model.user");
        $user  = $model->toArray($user);
        $user["avatar_url"] = $avatar_url;
        $user["language"]   = qtrans_getLanguage()?qtrans_getLanguage():"es";


        return $this->resultResponse(new JsonResponse($user));

    }


    function configAction(Request $request){


        /**
         * @var $model AdminModel
         */
        $model   = $this->get("model.admin");

        $array["configuration"] = $model->getConfigOptions();
        $array["configuration"]["site_name"] = \get_bloginfo("name");
        $array["configuration"]["vimeo_client_id"] = "3ae21c6ca4a477db3024e09a78673eca876ce752";
        $array["configuration"]["vimeo_client_secret"] = "17c6e6dd08c208b99b360d303ca8fa3a4a2bd98e";
        $array["styles"] = $model->getCustomOptions();



        return $this->resultResponse(new JsonResponse($array));

    }

    function topicsAction(Request $request){

        if(!$this->getSecurity()->isAuthenticated()){
            return $this->resultResponse(new Response("Not authenticated", 403));
        }

        $terms = array();
        foreach(get_terms("topic", array("hide_empty"=>false)) as $term){
            $terms[] = array(
                "id"   => $term->term_id,
                "name" => \qtrans_use(\qtrans_getLanguage(), $term->name, true)
            );
        }


        return $this->resultResponse(new JsonResponse($terms));

    }

    function projectsAction(Request $request){

        if(!$this->getSecurity()->isAuthenticated()){
            return $this->resultResponse(new Response("Not authenticated", 403));
        }

        $projects = array();
        foreach($this->get("model.project")->getList() as $project){
            $projects[] = array(
                'id'          => $project->ID,
                'name'        => \get_the_title($project),
                'description' =>  \qtrans_use(\qtrans_getLanguage(), $project->post_content, true),
                'image'       => get_the_post_thumbnail($project->ID),
                'url'         => get_permalink($project->ID)
            );
        }

        return $this->resultResponse(new JsonResponse($projects));

    }

    function contentsAction(Request $request, \WP_Query $wpquery){


        if(!$this->getSecurity()->isAuthenticated()){
            return $this->resultResponse(new Response("Not authenticated", 403));
        }

        $user = $this->getSecurity()->getUser();
        $data = array();

        if($request->getMethod()=="POST"){



            $post = $this->saveContent($user, $request);
            if($post instanceof \WP_Post){
                return $this->resultResponse(new JsonResponse($this->getContentModel()->toArray($post)));
            }else{
                return $this->resultResponse(new JsonResponse($post, 400));
            }

        }


        //$query = $this->getContentModel()->getUserContentQB($user->ID, $request->get("page"));
        $query = $this->getContentModel()->getAllQB($request->get("page", 1));

        if(isset($wpquery->query_vars["project_id"])){
                $query->whereMeta("ubiqa_content_subproject", $wpquery->query_vars["project_id"]);

        }


        $items = $query->getArray();

        foreach($items as $post){

            $data[] = $this->contentToArray($post);

        }

        return $this->resultResponse(new JsonResponse($data));



    }


    function contentEditAction(Request $request, \WP_Query $wpquery){


        if(!$this->getSecurity()->isAuthenticated()){
            return $this->resultResponse(new Response("Not authenticated", 403));
        }

        $user = $this->getSecurity()->getUser();

        $post = get_post($request->get("id"));

        if($post->post_author != $user->ID){
            return $this->resultResponse(new Response("Not authenticated", 404));
        }


        if($request->getMethod()=="POST"){



            $post = $this->saveContent($user, $request, $post);
            if($post instanceof \WP_Post){
                return $this->resultResponse(new JsonResponse($this->getContentModel()->toArray($post)));
            }


            return $this->resultResponse(new JsonResponse($post, 400));


        }else{
            return $this->resultResponse(new JsonResponse("Invalid method", 400));
        }





    }


    /**
     *
     *
     * @param \WP_User $user
     * @param Request $request
     * @param \WP_Post $post
     * @return \WP_Post|array the content or an array of form errors
     */
    private function saveContent(\WP_User $user, Request $request, \WP_Post $post=null){

        $projects = array();
        foreach($this->get("model.project")->getList() as $project){
            $projects[$project->ID] = \get_the_title($project);
        }
        $info_form = new ContentInfoForm(array(), $this->get("sense.form.builder"), $projects);
        $geo_form = new ContentGeoForm(array(), $this->get("sense.form.builder"));

        $terms = array();
        foreach(get_terms("topic", array("hide_empty"=>false)) as $term){
            $terms[$term->term_id] = \qtrans_useDefaultLanguage($term->name);
        }

        $topic_form = new ContentTopicForm(array(), $this->get("sense.form.builder"), $terms);

        $info_form->bind(array(
            'title_' . \qtrans_getLanguage()       => $request->get("content_name"),
            'description_' . \qtrans_getLanguage() => $request->get("description"),
            'type'           => $request->get("content_type"),
            'url'            => $request->get("content_url"),
            'project'        => $request->get("project_id")
        ));

        $location = $request->get("location");

        $geo_form->bind(array(
            'city'           => $request->get("city"),
            'address'        => $request->get("address"),
            'country'        => $request->get("country"),
            'lon'            => isset($location["lon"]) ? $location["lon"]: null,
            'lat'            => isset($location["lat"]) ?$location["lat"] : null,
        ));

        $topic_form->bind(array(
            'is_interview'     => $request->get("is_interview"),
            'genre'            => $request->get("genre"),
            'language'         => $request->get("language"),
            'age'              => $request->get("age"),
            'topic'            => $request->get("topics", array())
        ));

        $model = $this->getContentModel();

        if($topic_form->isValid() && $geo_form->isValid() && $topic_form->isValid()){




            $post  = $info_form->save($model, $user, $post);
            $geo_form->save($post, $model);
            $topic_form->save($post,$model);

            if($request->get("local_video_url")){
                $model->setMeta($post->ID, "ubiqa_local_video_url", $request->get("local_video_url"));
            }



            if(false !== array_search($request->get("content_status"), array("publish", "pending", "draft"))){
                $model->update($post, array("post_status"=> $request->get("content_status")));
            }




            if(isset($_FILES["file"]["tmp_name"])){

                $model->uploadToMediaFromFile($_FILES["file"], $post, $model->getMeta($post->ID, "ubiqa_content_type") == "image");

            }



        }else{

            foreach($info_form->getErrors() as $key=>$error){
                $errors[$key] = $error;
            }
            foreach($geo_form->getErrors() as $key=>$error){
                $errors[$key] = $error;
            }
            foreach($topic_form->getErrors() as $key=>$error){
                $errors[$key] = $error;
            }

            return array("errors"=>$errors);
        }



        return $post;

    }

    function contentRemoveAction(Request $request, \WP_Query $query){

        if(!get_post($query->query_vars["id"])){
            return $this->resultResponse("Not found", 404);
        }
        $this->getContentModel()->remove($query->query_vars["id"], $this->getSecurity()->getUser());

        return $this->resultResponse("Removed", 204);

    }



    private function contentToArray(\WP_Post $post){

        $topics = array();
        $terms = wp_get_post_terms($post->ID, "topic");
        foreach($terms as $term){
            $topics[] = $term->term_id;
        }

        $type = $this->getContentModel()->getMeta($post->ID, "ubiqa_content_type");

        return array(

            'id'            => $post->ID,
            'content_name'  => get_the_title($post->ID),
            'date'          => $post->post_date,
            'post_url'      => get_permalink($post),
            'local_url'     => '',
            'description'   => \qtrans_use(\qtrans_getLanguage(), $post->post_content, true),
            'content_url'   => $this->getContentModel()->getMeta($post->ID, "ubiqa_content_content_url"),
            'embed_html'    => $type == "video"  ?$this->getContentModel()->getOembedHtml($post->ID, "ubiqa_video_oembed_data", "100%", "500"):'',
            'thumb_html'    => \get_the_post_thumbnail($post->ID, "full", array("class"=>"img-responsive") ),
            'audio_html'    => $type == "audio" ?'<audio controls>
                                   <source src="' .$this->getContentModel()->getMeta($post->ID, "ubiqa_content_content_url") .'" type="audio/mpeg">
                                   <a target="_blank" href="' .$this->getContentModel()->getMeta($post->ID, "ubiqa_content_content_url") .'">'. __("Escuchar audio", "ubiqa") .'</a>
                             </audio>': '',

            'type'          => $type,
            'topics'        => $topics,
            'user_id'       => $post->post_author,
            'project_id'    => $this->getContentModel()->getMeta($post->ID, "ubiqa_content_subproject"),
            'content_status'=> $post->post_status,
            'language'      => $this->getContentModel()->getMeta($post->ID, "ubiqa_content_language"),
            'age'           => $this->getContentModel()->getMeta($post->ID, "ubiqa_content_age"),
            'genre'         => $this->getContentModel()->getMeta($post->ID, "ubiqa_content_genre"),
            'city'          => $this->getContentModel()->getMeta($post->ID, "ubiqa_content_city"),
            'address'       => $this->getContentModel()->getMeta($post->ID, "ubiqa_content_address"),
            'country'       => $this->getContentModel()->getMeta($post->ID, "ubiqa_content_country"),
            'location'      => array(
                'lat' => $this->getContentModel()->getMeta($post->ID, "ubiqa_content_lat"),
                'lon' => $this->getContentModel()->getMeta($post->ID, "ubiqa_content_lon"),
            ),
            'is_interview'    => $this->getContentModel()->getMeta($post->ID, "ubiqa_content_is_interview"),
            'local_video_url' => $this->getContentModel()->getMeta($post->ID, "ubiqa_local_video_url")


        );

    }




    /**
     * @return ContentModel
     */
    function getContentModel(){

        return $this->get("model.content");
    }

    /**
     * @return HTTPAuthenticator
     */
    function getSecurity(){

        return $this->get("security.http");
    }

} 