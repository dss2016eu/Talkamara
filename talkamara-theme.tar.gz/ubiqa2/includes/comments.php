<section class="bg-white-2">
    <div id="postcomments" class="container">

        <h2><?php _e("Comentarios", "ubiqa") ?> <span class="tag bg-brand txt-white"><?php echo get_comments_number($post_id) ?></span></h2>

        <hr>
        <?php foreach(get_approved_comments($post_id) as $comment){ ?>
        <div class="post air">
            <div class="flx-h">
                <div class="lazy-img img-rounded small">
                    <?php get_avatar($comment->comment_author_email) ?>
                </div>
                <div class="flx-1 air-h">
                    <p class="txt-big">
                        <b class="txt-bold"><?php echo $comment->comment_author ?></b>
                        <span class="txt-italic air-h"><i class="fa fa-clock-o"></i> <?php echo date("d-m-Y H:i", strtotime($comment->comment_date)) ?></span>
                    </p>
                    <p class="txt-serif"><?php echo $comment->comment_content ?></p>
                    <?php /*<i class="fa fa-comment-o"></i> RESPONDER*/?>
                </div>
            </div>
        </div>
        <?php } ?>




        <div class="comment-form">


            <div class="air flx-h">
            <?php comment_form( array("class_submit"=>"btn-rounded"), $post_id ); ?>
            </div>
        </div>

    </div>
</section>