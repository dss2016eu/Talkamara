<?php setup_postdata( $post ); $author = get_the_author();  ?>

<div class="col-m-6 col-l-3">
    <div class="card card-route">
        <div class="card-image lazy-img loaded" style="height: 256px">
            <?php

            if($thumb = get_the_post_thumbnail(get_the_ID(),"ubiqa_blog_thumb", array("data-aspect-ratio"=>"1", "class"=>"aspect-rated"))){
                echo $thumb;
            }else{ ?>
                <img src="<?php echo _u()->getDefaultImageSrc(get_the_ID()) ?>" data-aspect-ratio="1">
            <?php
            }

            ?>
            <div class="image-overlay">
                <div class="pos-center txt-center">
                    <a  class="btn-rounded" href="<?php echo get_permalink($post) ?>"><?php _e("Ver ruta", "ubiqa") ?></a>
                </div>
            </div>
        </div>
        <div class="card-info">
            <div class="card-rounded-image lazy-img loaded">
                <?php   ?>
                <img src="<?php echo _u()->getAuthorAvatar($post) ?:"" ?>">
            </div>
            <p class="route-title"><a  href="<?php echo get_permalink($post) ?>"><?php the_title() ?></a></p>
            <?php  the_excerpt() ?>
        </div>
    </div>
</div>