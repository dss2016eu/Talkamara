<?php
/**
 * Created by PhpStorm.
 * User: Asier
 * Date: 26/07/14
 * Time: 17:40
 */

namespace Ubiqa\Interceptor;


use Sense\AbstractInterceptor;
use Sense\AssetManager;
use Ubiqa\Model\AgendaModel;

class ProjectInterceptor extends AbstractInterceptor {


    function execute(\WP_Query $query){


        if($this->isExecuted()) return;

        /**
         * @var $asset_manager AssetManager
         */
        $asset_manager = $this->get("sense.theme_assets");
        $asset_uri     = $this->get("%wp.template_uri%");
        $asset_manager->addScript('projects', $asset_uri . '/js/projects.js', 1, true, array());


    }

    function executeDetail(\WP_Query $query){


        if($this->isExecuted()) return;

        $_item = $this->get("model.content")->getOneBy("name", $query->query_vars["name"], "subproject");
        if($_item instanceof \WP_Post){
            $visit = (int) get_post_meta($_item->ID, "ubiqa_visit", true);
            update_post_meta($_item->ID, "ubiqa_visit", ++$visit);
        }

        /**
         * @var $asset_manager AssetManager
         */
        $asset_manager = $this->get("sense.theme_assets");
        $asset_uri     = $this->get("%wp.template_uri%");

        $asset_manager->addScript('content_manager', $asset_uri . '/js/content_manager.js', 1, true, array());
        $asset_manager->addScript('projects', $asset_uri . '/js/project.js', 1, true, array());


    }

} 