/**
 * Created by Asier on 21/07/14.
 */
jQuery(document).ready(function($){


    $("#content_type_metas .content_type").click(function(){

        var self = this;
        $("#content_type_metas .content_type_option").show();
        $("#content_type_metas .hide-" + $(self).attr("data-rel")).hide();

    });
    $("#content_type_metas .content_type").filter(":checked").trigger("click");


    if($('.timepicker').length) $( ".datepicker" ).datepicker({ dateFormat: "dd-mm-yy", firstDay: 1 });
    if($('.timepicker').length) $('.timepicker').timepicker({timeFormat: 'H:i'});

});