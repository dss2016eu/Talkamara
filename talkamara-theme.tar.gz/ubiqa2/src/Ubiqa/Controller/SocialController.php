<?php
/**
 * Created by PhpStorm.
 * User: asierm
 * Date: 19/10/14
 * Time: 16:59
 */

namespace Ubiqa\Controller;


use Sense\AbstractController;
use Sense\Model\UserModel;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use Ubiqa\WPMultiLogin;

class SocialController extends AbstractController{

    static $has_called_before=false;


    function loginRedirectAction(Request $request, \WP_Query $query){

        $auth = $this->get("social.authenticator");
        $url = $auth->getLoginUrl($query->query_vars["service"]);


        return $this->resultRedirect($url);

    }

    function oauthBackAction(Request $request, \WP_Query $query){



        /**
         * @var $auth WPMultiLogin
         */
        $auth         = $this->get("social.authenticator");
        $redirect_url = $this->generateUrl("login");
        $user_model   = new UserModel();
        $this->getTheme()->assign("model", $user_model);


        $social_result = $auth->loginListener();


        $result = null;
        if( "twitter_email_required" == $social_result ){

            $this->getTheme()->assign("error", __("Necesitamos tu email para finalizar el registro con Twitter", "ubiqa"));


            $redirect_url = $this->get("router")->generateUrl("social_twitter_email");

        }

        return $this->resultRedirect($redirect_url);


    }

    function twitterEmailAction(Request $request, \WP_Query $query){

        /**
         * @var $auth WPMultiLogin
         */
        $auth         = $this->get("social.authenticator");
        $redirect_url = $this->generateUrl("login");
        $user_model   = new UserModel();
        $this->getTheme()->assign("model", $user_model);

        if($request->getMethod()=="POST" && isset($_SESSION["twitter_user_id"])){

            if($_SESSION["twitter_user_id"]  && $email = $request->get("email_for_twitter")){

                if(filter_var($email, FILTER_VALIDATE_EMAIL)){

                    $auth->setTwitterIdToEmailUser($email, $_SESSION["twitter_user_id"]);
                    $auth->removeTwitterSessionVariables();

                    $redirect_url = $auth->getRedirectToInSession();
                    return $this->resultRedirect($redirect_url);
                }

            }

        }

        return $this->resultTemplate("Social/email.php");

    }

    function vimeoIframeAction(Request $request, \WP_Query $query){

        /**
         * @var $vimeo \Vimeo
         */
        $vimeo = $this->get("vimeo");
        $this->getTheme()->assign("form_link", false);

        if($vimeo){

            if(!$request->get("video_uri")){


                $data = $vimeo->request("/me/videos",array("redirect_url"=>_u()->getUrl( $this->generateUrl("vimeo_iframe")). "?output=embed") , "POST");

                if(isset($data["body"]["upload_link_secure"])){
                    $this->getTheme()->assign("form_link", $data["body"]["upload_link_secure"]);
                }


            }else{
                $data = $vimeo->request($request->get("video_uri"));


                $this->getTheme()->assign("video_link", $data["body"]["link"]);
            }

        }




        return $this->resultTemplate("Social/vimeo.php");

    }


} 