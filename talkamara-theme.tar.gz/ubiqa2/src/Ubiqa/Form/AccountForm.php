<?php
/**
 * Created by PhpStorm.
 * User: Asier
 * Date: 5/08/14
 * Time: 12:50
 */

namespace Ubiqa\Form;

use SimpleForm\AbstractForm;
use SimpleForm\FormBuilder;
use Symfony\Component\Validator\Constraints\Email;
use Symfony\Component\Validator\Constraints\NotBlank;
use Symfony\Component\Validator\Constraints\NotNull;
use Symfony\Component\Validator\Constraints\Length;

class AccountForm extends AbstractForm{

    private $_langs;

    function __construct($data, FormBuilder $builder, $languages=array()){
        $this->_langs = $languages;
        parent::__construct($data, $builder);
    }

    function configure(){

        $this->setName("profile");

        $builder = $this->getBuilder();



        $builder->add("photo", "input", array("type"=>"file", "class"=>"hide","label"=>__("Avatar", "ubiqa"), "required"=>false));
        $builder->add("first_name", "text", array("label"=>__("Nombre", "ubiqa"), "class"=>"flx-3"));

        $builder->add("language", "choice", array("label"=>__("Idioma", "ubiqa"), "class"=>"flx-3", "choices"=>$this->_langs));

        $builder->add("last_name", "text", array(
            "label"=>__("Apellidos", "ubiqa"),
            "class"=>"flx-3",
            "validators"=>array(new  NotBlank(), new Length(array("min"=>3)
            ))
        ));
        $builder->add("user_email", "text", array("label"=>__("Email", "ubiqa"),"type"=>"text", "class"=>"flx-3", "required"=>true, "validators"=> array(new NotNull(), new Email())));
        $builder->add("description", "textarea", array("label"=>__("Acerca de tí", "ubiqa"), "class"=>"form-control", "rows"=>10, "required"=>false));




    }

    function getFile($key){

        $file_data = array();
        if(isset($_FILES[$this->getName()])){
            foreach($_FILES[$this->getName()] as $_key=>$value){
                $file_data[$_key] = $value[$key];
            }
        }
        return $file_data;
    }

} 