<?php
/**
 * Created by PhpStorm.
 * User: Asier
 * Date: 1/07/14
 * Time: 23:30
 */

namespace Ubiqa\Model;


use Sense\Model\AbstractModel;
use Sense\Model\QueryBuilder;

class ContentModel  extends  AbstractModel{

    const META_FEATURE_CONTENT = "ubiqa_feature_content";
    const META_FEATURE_SLIDER  = "ubiqa_feature_slider";

    protected $post_type_name = "content";

    private $_project_list = array();

    private $_favorites    = null;
    private $_likes        = null;


    function __construct(){

        add_action( 'add_attachment', array($this, "rotateAttachment") );

    }


    function updateMetas(\WP_Post $post, $data=array()){
        foreach($data as $key=>$value){
            $this->setMeta($post->ID, $key, $value);

            if($key == "ubiqa_content_content_url" && !\get_post_thumbnail_id($post->ID)){

                $type = $this->getMeta($post->ID, "ubiqa_content_type");

                if($type == "image"){

                    $this->setExternalImageToPost($value, $post->ID, (\get_the_title($post->ID) . time()), true);

                }else if($type == "video"){

                    $_data = $this->getVideoData($value);
                    $this->setMeta($post->ID, "ubiqa_video_oembed_data", $_data);


                    if(isset($_data->thumbnail_url)){
                        $this->setExternalImageToPost($_data->thumbnail_url, $post->ID, (\get_the_title($post->ID).time()), true);
                    }
                }
            }


        }




    }




    function toArray(\WP_Post $post){

        $project = get_post($this->getMeta($post->ID, "ubiqa_content_subproject"));
        $type = $this->getMeta($post->ID, "ubiqa_content_type");
        $embed = $this->getOembedHtml($post->ID, "ubiqa_video_oembed_data", "100%", "500");

        return array(

            'id' => $post->ID,
            'title' => get_the_title($post->ID),
            'link' => get_permalink($post),
            'content' => \qtrans_use(\qtrans_getLanguage(), $post->post_content, true),
            'content_url' => $this->getMeta($post->ID, "ubiqa_content_content_url"),
            'embed_html' => $type == "video" ? ($embed?$embed:_u()->getContentThumb($post->ID)) :null,
            'thumb_html' => get_the_post_thumbnail($post->ID, "full", array("class"=>"img-responsive") ),
            'audio_html' => _u()->getAudioTag($post->ID),
            'has_oembed' => _u()->get("content")->getMeta($post->ID, "ubiqa_content_has_oembed")?_u()->get("content")->getMeta($post->ID, "ubiqa_content_oembed"):null,
            'type' => $type,
            'project_name' => get_the_title($project)

        );


    }


    function getOEmbedHtml($post_id, $meta_key, $width, $height){

        //die(var_dump($this->getMeta($post_id, $meta_key)));

        if($data = $this->getMeta($post_id, $meta_key)){
            // $html = \preg_replace('/width=["\']?([^"\' ]*)["\' ]/', $width , $data->html);
            // \preg_replace('/height=["\']?([^"\' ]*)["\' ]/', '\1"' . $height . '"\2', $html);

            return $data->html;
        }
    }





    function getProjects(){


        return $this->createQueryBuilder("subproject")->orderBy("post_title", "DESC")->getArray();


    }


    function remove($content_id, \WP_User $user){

        if($item = \get_post($content_id)){

            if($item->post_author = $user->ID){
                wp_delete_post($content_id, true);
            }

        }


    }

    function getFavoritesArray(\WP_User $user, $limit=9){
        $query = $this->getBaseQB();
        return $query->whereMeta("ubiqa_user_fav", $user->ID)->getArray();


    }

    function getFavorites(\WP_User $user){


        if(!$this->_favorites){
            $query = $this->getBaseQB();
            $items = $query->whereMeta("ubiqa_user_fav", $user->ID)->getArray();
            foreach($items as $item){
                $this->_favorites[] = $item->ID;
            }
        }



        return $this->_favorites?:array();

    }





    function getLikes(\WP_User $user=null){


        if(!$user)
            return array();

        if(!$this->_likes){
            $query = $this->getBaseQB();
            $items = $query->whereMeta("ubiqa_user_like", $user->ID)->getArray();
            foreach($items as $item){
                $this->_likes[] = (int) $item->ID;
            }
        }



        return $this->_likes?:array();

    }

    function addLike($content_id, $user_id){

        $this->setMeta( $content_id, "ubiqa_user_like", $user_id, true);

        $likes = (int) $this->getMeta( $content_id, "ubiqa_likes");;

        $this->setMeta( $content_id,  "ubiqa_likes", ++$likes);


    }

    function removeLike($content_id, $user_id){

        $this->removeMeta( $content_id, "ubiqa_user_like", $user_id);

        $likes = (int) $this->getMeta( $content_id, "ubiqa_likes");;

        $this->setMeta( $content_id,  "ubiqa_likes", --$likes);


    }

    function addFav($content_id, $user_id){

        $this->setMeta( $content_id, "ubiqa_user_fav", $user_id, true);

        $likes = (int) $this->getMeta( $content_id, "ubiqa_favs");;

        $this->setMeta( $content_id,  "ubiqa_favs", ++$likes);


    }

    function removeFav($content_id, $user_id){

        $this->removeMeta( $content_id, "ubiqa_user_fav", $user_id);

        $likes = (int) $this->getMeta( $content_id, "ubiqa_favs");;

        $this->setMeta( $content_id,  "ubiqa_favs", --$likes);


    }

    function isFavorite($content_id, \WP_User $user){

        $items = $this->getBaseQB()->where($content_id, "p")->whereMeta("ubiqa_user_fav", $user->ID)->getArray();

        return (bool)count($items);

    }

    function isLike($content_id, \WP_User $user=null){
        $items = $this->getBaseQB()->where($content_id, "p")->whereMeta("ubiqa_user_like", $user->ID)->getArray();

        return (bool)count($items);

    }


    /**
     * @return QueryBuilder
     */
    function getBaseQB(){

        return $this->createQueryBuilder("content")->orderBy("date", "DESC");
    }
    function getAllQB($page){
        $qb =    $this->getBaseQB()->where("any", "post_status");
        return $qb->page($page);

    }

    function getRelatedArray($lat, $lon, $id){
        $posts = $this->getBaseQB()->whereMeta("ubiqa_content_lat", $lat)->whereMeta("ubiqa_content_lon", $lon)->getArray();

        foreach($posts as $i=>$_post){

            if($_post->ID == $id){
                unset($posts[$i]);
            }

        }


        return $posts;
    }

    function getTopicIds($values=array()){



        global $wpdb;

        $sql = <<<SQL


	SELECT   DISTINCT   t.term_id
	FROM        $wpdb->terms t

	INNER JOIN  $wpdb->term_taxonomy tt
	            ON tt.term_id = t.term_id
	            AND tt.taxonomy = "topic"

    INNER JOIN  $wpdb->term_relationships tr
            ON t.term_id = tr.term_taxonomy_id

	INNER JOIN  $wpdb->posts p
	            ON p.ID = tr.object_id AND p.post_type = "content"

	            %inner_join%

	WHERE       1=1

	%where%


SQL;

        $inner_join = "";
        $where      = "";

        if(isset($values["content_type"]) && $values["content_type"]){

            $inner_join .= " INNER JOIN {$wpdb->postmeta} ct ON ct.post_id = p.ID AND ct.meta_key = 'ubiqa_content_type'";

            $where .= " AND ct.meta_value = '{$values["content_type"]}' ";

        }
        if(isset($values["subproject"]) && $values["subproject"]){




            $inner_join .= " INNER JOIN {$wpdb->postmeta} sp ON sp.post_id = p.ID AND sp.meta_key = 'ubiqa_content_subproject'";

            $where .= " AND sp.meta_value = '{$values["subproject"]}' ";

        }

        if(isset($values["is_interview"]) && count($values["is_interview"])){


            $inner_join .= " INNER JOIN {$wpdb->postmeta} ii ON ii.post_id = p.ID AND ii.meta_key = 'ubiqa_content_is_interview'";

            $where .= " AND ii.meta_value = '{$values["is_interview"][0]}' ";
        }



        if(isset($values["ubiqa_category"]) && $values["ubiqa_category"]){

            //$query->whereTaxonomy("ubiqa_category", array($values["ubiqa_category"]));

            $inner_join .= "
                INNER JOIN $wpdb->terms tc
            	INNER JOIN  $wpdb->term_taxonomy ttc
	            ON ttc.term_id = tc.term_id
	            AND ttc.taxonomy = 'ubiqa_category'

    INNER JOIN  $wpdb->term_relationships trc
            ON tc.term_id = trc.term_taxonomy_id
            AND trc.object_id = p.ID
            ";

            $where .= " AND tc.term_id = {$values["ubiqa_category"]} ";
        }

        if(isset($values["genre"]) && $values["genre"]){


            $inner_join .= " INNER JOIN {$wpdb->postmeta} cg ON cg.post_id = p.ID AND cg.meta_key = 'ubiqa_content_genre'";

            $where .= " AND cg.meta_value = '{$values["genre"]}' ";

        }

        if(isset($values["language"]) && $values["language"]){


            $inner_join .= " INNER JOIN {$wpdb->postmeta} cl ON cl.post_id = p.ID AND cl.meta_key = 'ubiqa_content_language'";

            $where .= " AND cl.meta_value = '{$values["language"]}' ";

        }



        if(isset($values["city"]) && $values["city"]){


            $inner_join .= " INNER JOIN {$wpdb->postmeta} cc ON cc.post_id = p.ID AND cc.meta_key = 'ubiqa_content_city'";

            $where .= " AND cc.meta_value = '{$values["city"]}' ";

        }

        $sql = str_replace("%inner_join%", $inner_join, $sql);
        $sql = str_replace("%where%", $where, $sql);


        //die($sql);

        $ids=$wpdb->get_col( $sql );



        return $ids?:array();

    }

    function getFilterQueryVars($values=array()){

        $query = $this->getBaseQB();

        $query->limit(30);

        if(isset($values["content_type"])){

                $query->whereMeta("ubiqa_content_type", $values["content_type"], "IN");

        }
        if(isset($values["subproject"]) && $values["subproject"]){

            $query->whereMeta("ubiqa_content_subproject", $values["subproject"]);

        }

        if(isset($values["is_interview"]) && count($values["is_interview"])){

            $query->whereMeta("ubiqa_content_is_interview", $values["is_interview"][0]);

        }
        if(isset($values["age"]) && $values["age"]){

            $query->whereMeta("ubiqa_content_age", $values["age"]);

        }

        if(isset($values["age_from"]) && $values["age_from"]){

            if($values["age_from"] == $values["age_to"]){
                $query->whereMeta("ubiqa_content_age", $values["age"]);
            }else{
                $query->whereMeta("ubiqa_content_age", $values["age_from"], ">=");
                $query->whereMeta("ubiqa_content_age", $values["age_to"], "<=");
            }


        }

        if(isset($values["ubiqa_category"]) && $values["ubiqa_category"]){

            $query->whereTaxonomy("ubiqa_category", array($values["ubiqa_category"]));
        }

        if(isset($values["genre"]) && $values["genre"]){



            $query->whereMeta("ubiqa_content_genre", $values["genre"]);

        }

        if(isset($values["language"]) && $values["language"]){

            $query->whereMeta("ubiqa_content_language", $values["language"]);

        }



        if(isset($values["city"]) && $values["city"]){

            $query->whereMeta("ubiqa_content_city", $values["city"]);

        }

        if(isset($values["topic"])){

            $query->whereTaxonomy("topic", $values["topic"]);

        }

        if(isset($values["search"]) && $values["search"]){

            $query->search($values["search"]);

        }

        return $query->getWPQueryVars();

    }

    function getBlogPosts($limit=10){
        return $this->createQueryBuilder("post")->orderBy("date", "DESC")->limit($limit)->getArray();
    }

    /**
     * @param $user_id
     * @param int $page
     * @return QueryBuilder
     */
    function getUserContentQB($user_id, $page=1)
    {


        return $this->createQueryBuilder("content")
            ->where($user_id, "author")
            ->where("any","post_status")
            ->page($page)
            ->limit(10)->orderBy("ID", "DESC");

    }

    function getUserFavsQB($user_id, $page)
    {
        return $this->createQueryBuilder("content")
            ->whereMeta("ubiqa_user_fav", $user_id)
            ->page($page)->limit(10)->orderBy("ID", "DESC");

    }


    function getCarouselPosts($limit=10){
        //$qb = $this->getBaseQB()->limit($limit);
        $qb = $this->createQueryBuilder("any")->orderBy("date", "DESC")->limit($limit);
        return $qb->whereMeta(static::META_FEATURE_SLIDER, 1)->getArray();
    }

    function getFeaturedPosts(){
        $qb = $this->createQueryBuilder("any")->orderBy("date", "DESC");
        return $qb->whereMeta(static::META_FEATURE_CONTENT, 1)->limit(2)->orderBy("rand")->getArray();
    }

    function getLast(){
        return $this->getBaseQB()->getArray();
    }

    function getSubprojectLast($project_id){
        return $this->getBaseQB()->whereMeta("ubiqa_content_subproject", $project_id, "INTEGER")->getArray();
    }

    function getVideoData($url){


            $is_vimeo   = false!==strpos($url, 'vimeo');
            $is_youtube = false!==strpos($url, 'youtube');

            if(!$is_vimeo && !$is_youtube){
                return null;
            }else{
                if($is_vimeo){
                    return \json_decode($this->getOembedData("http://vimeo.com/api/oembed.json?url=" . $url));
                }else{
                    return \json_decode($this->getOembedData("http://www.youtube.com/oembed?url=" . $url));
                }
            }


    }

    private function getOembedData($url){
        // create curl resource
        $ch = curl_init();

        // set url
        curl_setopt($ch, CURLOPT_URL, $url);

        //return the transfer as a string
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);

        // $output contains the output string
        $output = curl_exec($ch);

        // close curl resource to free up system resources
        curl_close($ch);

        return $output;
    }

    function uploadToMediaFromFile($file_array, \WP_Post $content, $thumbnail=false){


        if($data = $this->uploadToMediaLibrary($file_array, $content)){




            $this->setMeta($content->ID, "ubiqa_content_content_url", $data["url"]);
            if($thumbnail){

                $this->setPostThumbnail($content->ID, $data["id"]);
            }



        }
    }


    function getLanguages(){
        return array(
            'aa' => 'Afar',
            'ab' => 'Abkhaz',
            'ae' => 'Avestan',
            'af' => 'Afrikaans',
            'ak' => 'Akan',
            'am' => 'Amharic',
            'an' => 'Aragonese',
            'ar' => 'Arabic',
            'as' => 'Assamese',
            'av' => 'Avaric',
            'ay' => 'Aymara',
            'az' => 'Azerbaijani',
            'ba' => 'Bashkir',
            'be' => 'Belarusian',
            'bg' => 'Bulgarian',
            'bh' => 'Bihari',
            'bi' => 'Bislama',
            'bm' => 'Bambara',
            'bn' => 'Bengali',
            'bo' => 'Tibetan Standard, Tibetan, Central',
            'br' => 'Breton',
            'bs' => 'Bosnian',
            'ca' => 'Catalan; Valencian',
            'ce' => 'Chechen',
            'ch' => 'Chamorro',
            'co' => 'Corsican',
            'cr' => 'Cree',
            'cs' => 'Czech',
            'cu' => 'Old Church Slavonic, Church Slavic, Church Slavonic, Old Bulgarian, Old Slavonic',
            'cv' => 'Chuvash',
            'cy' => 'Welsh',
            'da' => 'Danish',
            'de' => 'German',
            'dv' => 'Divehi; Dhivehi; Maldivian;',
            'dz' => 'Dzongkha',
            'ee' => 'Ewe',
            'el' => 'Greek, Modern',
            'en' => 'English',
            'eo' => 'Esperanto',
            'es' => 'Spanish',
            'et' => 'Estonian',
            'eu' => 'Euskera',
            'fa' => 'Persian',
            'ff' => 'Fula; Fulah; Pulaar; Pular',
            'fi' => 'Finnish',
            'fj' => 'Fijian',
            'fo' => 'Faroese',
            'fr' => 'French',
            'fy' => 'Western Frisian',
            'ga' => 'Irish',
            'gd' => 'Scottish Gaelic; Gaelic',
            'gl' => 'Galician',
            'gn' => 'GuaranÃƒÂ­',
            'gu' => 'Gujarati',
            'gv' => 'Manx',
            'ha' => 'Hausa',
            'he' => 'Hebrew (modern)',
            'hi' => 'Hindi',
            'ho' => 'Hiri Motu',
            'hr' => 'Croatian',
            'ht' => 'Haitian; Haitian Creole',
            'hu' => 'Hungarian',
            'hy' => 'Armenian',
            'hz' => 'Herero',
            'ia' => 'Interlingua',
            'id' => 'Indonesian',
            'ie' => 'Interlingue',
            'ig' => 'Igbo',
            'ii' => 'Nuosu',
            'ik' => 'Inupiaq',
            'io' => 'Ido',
            'is' => 'Icelandic',
            'it' => 'Italian',
            'iu' => 'Inuktitut',
            'ja' => 'Japanese (ja)',
            'jv' => 'Javanese (jv)',
            'ka' => 'Georgian',
            'kg' => 'Kongo',
            'ki' => 'Kikuyu, Gikuyu',
            'kj' => 'Kwanyama, Kuanyama',
            'kk' => 'Kazakh',
            'kl' => 'Kalaallisut, Greenlandic',
            'km' => 'Khmer',
            'kn' => 'Kannada',
            'ko' => 'Korean',
            'kr' => 'Kanuri',
            'ks' => 'Kashmiri',
            'ku' => 'Kurdish',
            'kv' => 'Komi',
            'kw' => 'Cornish',
            'ky' => 'Kirghiz, Kyrgyz',
            'la' => 'Latin',
            'lb' => 'Luxembourgish, Letzeburgesch',
            'lg' => 'Luganda',
            'li' => 'Limburgish, Limburgan, Limburger',
            'ln' => 'Lingala',
            'lo' => 'Lao',
            'lt' => 'Lithuanian',
            'lu' => 'Luba-Katanga',
            'lv' => 'Latvian',
            'mg' => 'Malagasy',
            'mh' => 'Marshallese',
            'mi' => 'Maori',
            'mk' => 'Macedonian',
            'ml' => 'Malayalam',
            'mn' => 'Mongolian',
            'mr' => 'Marathi (MarÄá¹­hÄ«)',
            'ms' => 'Malay',
            'mt' => 'Maltese',
            'my' => 'Burmese',
            'na' => 'Nauru',
            'nb' => 'Norwegian BokmÃ¥l',
            'nd' => 'North Ndebele',
            'ne' => 'Nepali',
            'ng' => 'Ndonga',
            'nl' => 'Dutch',
            'nn' => 'Norwegian Nynorsk',
            'no' => 'Norwegian',
            'nr' => 'South Ndebele',
            'nv' => 'Navajo, Navaho',
            'ny' => 'Chichewa; Chewa; Nyanja',
            'oc' => 'Occitan',
            'oj' => 'Ojibwe, Ojibwa',
            'om' => 'Oromo',
            'or' => 'Oriya',
            'os' => 'Ossetian, Ossetic',
            'pa' => 'Panjabi, Punjabi',
            'pi' => 'Pali',
            'pl' => 'Polish',
            'ps' => 'Pashto, Pushto',
            'pt' => 'Portuguese',
            'qu' => 'Quechua',
            'rm' => 'Romansh',
            'rn' => 'Kirundi',
            'ro' => 'Romanian, Moldavian, Moldovan',
            'ru' => 'Russian',
            'rw' => 'Kinyarwanda',
            'sa' => 'Sanskrit (Saá¹ská¹›ta)',
            'sc' => 'Sardinian',
            'sd' => 'Sindhi',
            'se' => 'Northern Sami',
            'sg' => 'Sango',
            'si' => 'Sinhala, Sinhalese',
            'sk' => 'Slovak',
            'sl' => 'Slovene',
            'sm' => 'Samoan',
            'sn' => 'Shona',
            'so' => 'Somali',
            'sq' => 'Albanian',
            'sr' => 'Serbian',
            'ss' => 'Swati',
            'st' => 'Southern Sotho',
            'su' => 'Sundanese',
            'sv' => 'Swedish',
            'sw' => 'Swahili',
            'ta' => 'Tamil',
            'te' => 'Telugu',
            'tg' => 'Tajik',
            'th' => 'Thai',
            'ti' => 'Tigrinya',
            'tk' => 'Turkmen',
            'tl' => 'Tagalog',
            'tn' => 'Tswana',
            'to' => 'Tonga (Tonga Islands)',
            'tr' => 'Turkish',
            'ts' => 'Tsonga',
            'tt' => 'Tatar',
            'tw' => 'Twi',
            'ty' => 'Tahitian',
            'ug' => 'Uighur, Uyghur',
            'uk' => 'Ukrainian',
            'ur' => 'Urdu',
            'uz' => 'Uzbek',
            've' => 'Venda',
            'vi' => 'Vietnamese',
            'vo' => 'VolapÃ¼k',
            'wa' => 'Walloon',
            'wo' => 'Wolof',
            'xh' => 'Xhosa',
            'yi' => 'Yiddish',
            'yo' => 'Yoruba',
            'za' => 'Zhuang, Chuang',
            'zh' => 'Chinese',
            'zu' => 'Zulu',
        );
    }


    function imageRotation( $source ) {


        if(!function_exists("exif_read_data")){

            return null;
        }

        ini_set('memory_limit', '512M');

        $destination = $source;

        $size = getimagesize( $source );

        $width = $size[0];
        $height = $size[1];

        $sourceImage = imagecreatefromjpeg( $source );

        $destinationImage = imagecreatetruecolor( $width, $height );

        imagecopyresampled( $destinationImage, $sourceImage, 0, 0, 0, 0, $width, $height, $width, $height );

        $exif = exif_read_data( $source );

        if(isset($exif['Orientation'])){
            $ort = $exif['Orientation'];

            switch ( $ort ) {

                case 2:
                    $this->flipImage( $destinationImage );
                    break;
                case 3:
                    $destinationImage = imagerotate( $destinationImage, 180, -1 );
                    break;
                case 4:
                    $this->flipImage( $destinationImage );
                    break;
                case 5:
                    $this->flipImage( $destinationImage );
                    $destinationImage = imagerotate( $destinationImage, -90, -1 );
                    break;
                case 6:
                    $destinationImage = imagerotate( $destinationImage, -90, -1 );
                    break;
                case 7:
                    $this->flipImage( $destinationImage );
                    $destinationImage = imagerotate( $destinationImage, -90, -1 );
                    break;
                case 8:
                    $destinationImage = imagerotate( $destinationImage, 90, -1 );
                    break;
            }
        }



        return imagejpeg( $destinationImage, $destination, 100 );
    }

    function flipImage( $image ) {

        $x = 0;
        $y = 0;
        $height = null;
        $width = null;

        if ( $width  < 1 )
            $width  = imagesx( $image );

        if ( $height < 1 )
            $height = imagesy( $image );

        if ( function_exists('imageistruecolor') && imageistruecolor( $image ) )
            $tmp = imagecreatetruecolor( 1, $height );
        else
            $tmp = imagecreate( 1, $height );

        $x2 = $x + $width - 1;

        for ( $i = (int)floor( ( $width - 1 ) / 2 ); $i >= 0; $i-- ) {
            imagecopy( $tmp, $image, 0, 0, $x2 - $i, $y, 1, $height );
            imagecopy( $image, $image, $x2 - $i, $y, $x + $i, $y, 1, $height );
            imagecopy( $image, $tmp, $x + $i,  $y, 0, 0, 1, $height );
        }

        imagedestroy( $tmp );

        return true;
    }


    function rotateAttachment($id){

        if($attachment = get_post( $id )){



            if ( 'image/jpeg' == $attachment->post_mime_type ) {

                $file = get_attached_file($id);


                $this->imageRotation( $file );
                require_once( ABSPATH . 'wp-admin/includes/image.php' );
                require_once( ABSPATH . 'wp-admin/includes/file.php' );
                require_once( ABSPATH . 'wp-admin/includes/media.php' );
                wp_generate_attachment_metadata( $id, $file );

            }

        }


    }

} 