<?php
/**
 * Created by PhpStorm.
 * User: Asier
 * Date: 30/07/14
 * Time: 21:51
 */

get_header();
$form = _u()->get("form");


?>
<div class="bg-white-2">
    <ul class="breadcrumb container inline">
        <li class="breadcrumb-item"><a href="<?php echo _u()->getUrl() ?>"><?php _e("inicio", "ubiqa") ?></a></li>
        <li class="breadcrumb-item"><?php _e("tu cuenta", "ubiqa") ?></li>
    </ul>
</div>

<section class="bg-white-1">
    <div class="container bg-white" id="account-form">




        <div class="grid air-h" data-tabs="account-tabs">

            <?php
                $active = "data";
                include '_sidebar.php'
            ?>


            <div class="col-s-12 col-m-9 col-s-12 air-h">
                <div data-tab-content="mis-datos">
                    <div class="form-block">
                        <span class="txt-bold"><?php _e("Tus datos", "ubiqa") ?></span>
                    </div>
                    <?php if($message = _u()->get("model")->getFlash("notice")){ ?>
                        <div class="alert alert-success"><?php echo $message ?></div>
                    <?php } ?>
                    <?php if($message = _u()->get("error")){ ?>
                        <div class="alert alert-danger"><?php echo $message ?></div>
                    <?php } ?>

                    <form class="panel-body" method="post" action="" enctype="multipart/form-data">
                        <div>
                            <div class="grid">
                                <div class="col-s-12 col-m-4 air">


                                    <div id="profile_photo_selector" class="lazy-img">
                                        <i class="fa fa-camera"></i>
                                        <?php if( $src = _u()->get("model")->getUserAvatarUrlFromMediaLibrary(_u()->get("model")->getUser(), "ubiqa_avatar")){ ?>




                                            <img src="<?php echo $src ?>" class="full-w" alt="">

                                        <?php }else{ ?>


                                            <?php echo get_avatar(_u()->get("model")->getUser()->ID, 400, "","",array("class"=>"full-w"));  ?>


                                        <?php } ?>
                                    </div>





                                </div>
                                <div class="col-s-12 col-m-8">
                                    <div class="flx-h-m air-v">
                                        <label class="flx-1 txt-bold form-label"><?php _e("NOMBRE", "ubiqa") ?></label>
                                        <?php echo $form["first_name"]->getInputTag(array("class"=>"flx-3")) ?>
                                    </div>
                                    <div class="flx-h-m air-v">
                                        <label class="flx-1 txt-bold form-label"><?php _e("APELLIDOS", "ubiqa") ?></label>
                                        <?php echo $form["last_name"]->getInputTag(array("class"=>"flx-3")) ?>
                                    </div>
                                    <div class="flx-h-m air-v">
                                        <label class="flx-1 txt-bold form-label"><?php _e("EMAIL", "ubiqa") ?></label>
                                        <?php echo $form["user_email"]->getInputTag(array("class"=>"flx-3")) ?>
                                    </div>

                                    <?php echo $form["photo"]->getInputTag() ?>

                                    <div class="flx-h-m air-v">
                                        <label class="flx-1 txt-bold form-label"><?php _e("IDIOMA", "ubiqa") ?></label>
                                        <?php echo $form["language"]->getInputTag(array("class"=>"flx-3")) ?>
                                    </div>


                                </div>
                            </div>
                        </div>
                        <div class="">
                            <div class="txt-bold air-b"><?php _e("BIO", "ubiqa") ?></div>
                            <?php echo $form["description"]->getInputTag(array("rows"=>"10", "cols"=>"30")) ?>
                        </div>
                        <button type="submit" class="btn btn-default"><?php _e("Guardar", "ubiqa") ?></button>
                    </form>
                </div>

            </div>
        </div>

    </div>
</section>
<?php
get_footer();