<?php
/**
 * Created by PhpStorm.
 * User: Asier
 * Date: 30/07/14
 * Time: 21:51
 */

get_header();



?>
    <section id="page">

        <div class="container">

            <div class="row">
                <div class="col-xs-12">
                    <ol class="breadcrumb" style="margin-top: 20px">
                        <li><a href="<?php echo _u()->getUrl() ?>"><?php _e("Inicio", "ubiqa") ?></a></li>
                        <li class="active"><?php _e("Registrar con email", "ubiqa") ?></li>
                    </ol>
                </div>
            </div>

            <div class="row">

                <div class="col-sm-3">
                </div>

                <div class="col-sm-6">

                    <div class="panel">




                        <form class="panel-body" method="post" action="">

                            <div class="row">
                                <div class="col-xs-12">
                                    <?php if($message = _u()->get("model")->getFlash("notice")){ ?>
                                        <div class="alert alert-success"><?php echo $message ?></div>
                                    <?php } ?>
                                    <?php if($message = _u()->get("error")){ ?>
                                        <div class="alert alert-danger"><?php echo $message ?></div>
                                    <?php } ?>
                                </div>
                            </div>



                            <div class="row form-group">

                                <div class="col-xs-12">
                                    <input name="email_for_twitter" type="email" class="form-control" value="">
                                </div>

                            </div>



                            <div class="row form-group">

                                <div class="col-xs-6">
                                    <button type="submit" class="btn btn-primary"><?php _e("Indicar email", "ubiqa") ?></button>
                                </div>

                            </div>

                        </form>

                    </div>

                </div>

            </div>

        </div>
    </section>

<?php
get_footer();