<!-- header -->
<header id="header-wrapper">
<div id="header-top" class="flx-h">

	<a class="logo-dss" href="http://talkamara.dss2016.eu/"><img src="http://saregileak.dss2016.eu/wp-content/uploads/2016/04/dss2016eu_eur.png" alt="dss2016eu eur" /></a>
<div
<div class="flx-1 txt-right">

<div class="flx-1 logos">
            <?php if(FACEBOOK_URL){ ?><a href="<?php echo FACEBOOK_URL ?>" class="fa fa-facebook"></a><? } ?>
            <?php if(TWITTER_URL){ ?><a href="<?php echo TWITTER_URL ?>" class="fa fa-twitter"></a><? } ?>
            <?php if(INSTAGRAM_URL){ ?><a href="<?php echo INSTAGRAM_URL ?>" class="fa fa-instagram"></a><? } ?>
            <a href="<?php bloginfo('rss2_url'); ?>" class="fa fa-rss"></a>
</div>
  	
<div class="mod-languages hizkuntzak">
<ul class="lang-inline">
	<li class="lang-active" dir="ltr">
		<a href="http://talkamara.dss2016.eu/eu/">EU</a>
	</li>
	<li class="" dir="ltr">
		<a href="http://talkamara.dss2016.eu/es/">ES</a>
	</li>
</ul>
</div>

<div class="search-module">
<form role="search" method="get" class="search-form" action="<?php echo home_url( '/' ); ?>">
    <label>
        <input type="search" class="search-field-top"
            placeholder="<?php echo esc_attr_x( '…', 'placeholder' ) ?>"
            value="<?php echo get_search_query() ?>" name="s"
            title="<?php echo esc_attr_x( 'Search for:', 'label' ) ?>" />
    </label>
    <input type="submit" class="search-submit"
        value="<?php echo esc_attr_x( 'Search', 'submit button' ) ?>" />
</form>
</div>

</div>
<div class="divider-1"></div>

</div>

    <div id="header-bottom" class="flx-h">
        <div class="flx-1">

            <a href="<?php echo _u()->getUrl() ?>" >
                <?php if($logo_url = _u()->getCustomOption("logo")){ ?>

                    <img id="header-logo" src="<?php echo $logo_url ?>"  alt="<?php bloginfo("name") ?>" >

                <?php }else{ \bloginfo("name"); } ?>

            </a>
        </div>


        <?php




            wp_nav_menu( array(
                'theme_location'  => 'primary',
                'container'       => 'ul',
                'menu_class' => 'hide-s primary-menu',
                'echo'            => true,
                'items_wrap'      => '<ul id="%1$s" class="%2$s">%3$s</ul>'
            ) );


         ?>
        <div class="air-h" data-fade-activate="header-menu-search">
            <a href="#">
                <i class="fa fa-search fa-lg"></i>
            </a>
        </div>


            <?php if(!\is_user_logged_in()){ ?>
        <div class="air-h">
                <a id="session_init" href="<?php echo _u()->transUrl(_u()->genUrl("login")) ?>" class="btn-rounded"><span><?php _e("Iniciar sesión", "ubiqa") ?></span><i class="fa fa-user fa-2x"></i></a>
        </div>
            <?php }else{ $user_info = _u()->get("sense.model.user")->getUser(); ?>
            <div class="air-r">
                <a  href="<?php echo _u()->transUrl(_u()->genUrl("add_content_info")) ?>" class="btn-rounded upload"><span><?php _e("Subir contenido", "ubiqa") ?></span><i class="fa fa-cloud-upload fa-2x"></i></a>

            </div>
            <div class="no-air-r">

                <a id="session_init" href="<?php echo _u()->transUrl(_u()->genUrl("account")) ?>" class="btn-rounded"><span><?php _e("Tu cuenta", "ubiqa") ?></span><i class="fa fa-user fa-2x"></i></a>

            </div>
            <?php } ?>
        <div class="show-s air-l">
            <i class="fa fa-2x fa-bars" data-fade-activate="header-menu-mobile"></i>
        </div>
        </div>



    <div id="header-menu-mobile" class="show-s header-menu bg-white-1">
        <?php wp_nav_menu( array(
        'theme_location'  => 'primary',
        'container'       => 'ul',
        'echo'            => true,
        'items_wrap'      => '<ul id="%1$s" class="%2$s">%3$s</ul>'
        ) ); ?>
    </div>



        <form action="<?php echo _u()->getUrl() ?>" id="header-menu-search" class="header-menu air txt-right">
            <input name="s" type="search" class="inline air-h" placeholder="Buscar" value="<?php echo get_search_query() ?>">
            <button type="submit" class="txt-white-2">
                <i class="fa fa-search"></i>
            </button>
        </form>
</header>
<!-- /header -->

<style>
body {padding-top:0px!important;}
#header-wrapper{position:inherit!important;}
#header-top{height:auto!important;background-color:#fff;}
div.mod-languages.hizkuntzak {float: right;width: 106px;position: relative;top: 9px;}
ul.lang-inline li{display:inline;border-left: 1px solid #C8C8C8;color: #C8C8C8;padding: 3px 10px!important;}
.lang-active{color:#469fdc;}
.logos a{color: #C8C8C8;border-left: 1px solid #C8C8C8;}
.logos{width: 105px;position: relative;float: right;box-sizing: border-box;top: 2px;}
.search-module{height:30px;width: 100%;float: right;clear: both;margin-top: 20px;max-width:300px;}
.search-module input[type=search] {height: 30px;min-height: 30px;border: 1px solid #459FDC;font-family:defaultRegular;}
.search-module input[type="submit"]{cursor:pointer;position: relative;top: -40px;left: -2px;height: 26px;width: 30px;border: 0;font-size: 0px!important;background: #fff url("http://saregileak.dss2016.eu/wp-content/uploads/2016/04/lupa.png") center center no-repeat;}
#header-bottom ul.primary-menu+div.air-h {display:none;}
#header-bottom{width:100%;}
.logo-dss img{max-width:401px;width:100%;}
@media (max-width:800px){#header-top, a.logo-dss{display:block!important;width:100%;}#header-top a img{margin: 0 auto!important;display: block;}.logo-dss+div.flx-1.txt-right{display: block;height: 110px;width: 305px;margin: 0 auto;}}
</style>