<?php get_header() ?>


    <div class="bg-white-2">
        <ul class="breadcrumb container inline">
            <li class="breadcrumb-item"><a href="<?php echo _u()->getUrl() ?>"><?php _e("inicio", "ubiqa") ?></a></li>
            <li class="breadcrumb-item"><?php _e("buscar", "ubiqa") ?></li>
        </ul>
    </div>

    <section class="bg-white-2">
        <div class="container">
            <div class="container">
                <div class="flx-h-m">
                    <div class="flx-1">
                        <h1><?php echo sprintf(__("Resultados de la búsqueda para %s", "ubiqa"), '"<i>' . get_search_query() . '</i>"') ?></h1>
                    </div>
                </div>
            </div>
            <hr>
            <div id="search_grid" class="masonry grid routes cards">


            </div>

            <div class="air">
                <div id="loading" class="spinner" style="display: none"><div></div></div>
                <button id="load_more" class="btn-default full-w"><?php _e("Ver más", "ubiqa") ?></button>
            </div>
        </div>
    </section>


    <script type="text/javascript">
        var search_url = "<?php echo _u()->genUrl("ajax_search") ?>";
        var search = "<?php echo get_search_query() ?>";
    </script>

<?php get_footer() ?>