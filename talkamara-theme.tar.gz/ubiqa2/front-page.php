<?php get_header() ?>

<?php
    include "includes/front_carousel.php";
?>

<!-- masonry section -->
<section class="bg-white-2">
<div class="container">


<?php
    include "includes/front_featured.php";
?>



<div id="content_grid" class="masonry grid cards">



</div>


<div class="air">
    <div id="loading" class="spinner" style="display: none"><div></div></div>
    <button id="load_more" class="btn-default full-w"><?php _e("Cargar más", "ubiqa") ?></button>
</div>

</div>
</section>
<!-- /masonry section -->
<?php
$blog_posts = _u()->get("content")->getBlogPosts(4);
if(count($blog_posts)==4){ ?>
<section class="bg-white-1">
    <div class="container">
        <h2 class="txt-center"><?php _e("Últimos posts", "ubiqa") ?></h2>

        <div class="grid cards masonry">


            <?php



            foreach($blog_posts as $_post){ \setup_postdata($GLOBALS['post'] = $_post); include("includes/post-card.php"); }

            ?>


        </div>

    </div>
</section>


<?php } ?>

<script type="text/javascript">
    var is_home = true;
</script>

<?php get_footer() ?>


