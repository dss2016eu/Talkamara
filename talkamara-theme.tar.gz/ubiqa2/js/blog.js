jQuery(document).ready(function($){

    var grid = $("#blog_grid");

    var spiner = $("#loading");

    var page = 1;

    $("#load_more").click(function(){

        var self = this;
        $(self).attr("disabled", "disabled");
        spiner.show();

        $.get(window.posts_url, {_page: page}, function(data){

            var items = $(data);

            imagesLoaded(items, function() {
                grid.append(items).masonry("appended", items).masonry('layout');
            });

            spiner.fadeOut();
            $(self).removeAttr("disabled");
            page++;

            if(!data){
                $(self).fadeOut();
            }
        });

    }).trigger("click");




});
