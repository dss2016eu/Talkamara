<?php
/**
 * Created by PhpStorm.
 * User: Asier
 * Date: 1/07/14
 * Time: 23:31
 */

namespace Ubiqa\Metabox;


use Sense\AbstractMetabox;
use Sense\Model\AbstractModel;
use Sense\Sense;
use Ubiqa\Model\ContentModel;
use Ubiqa\Model\RouteModel;

class ContentMetabox extends AbstractMetabox {



    function setUp(){


        if(is_admin()){
            $sense = $this->getContainer();

            $sense["sense.admin_assets"]->addScript("content", get_template_directory_uri() . "/js/content.js","1",true, array("jquery"));
            $sense["sense.admin_assets"]->addScript("leaflet", "http://cdn.leafletjs.com/leaflet-0.7.3/leaflet.js","1",true, array("jquery"));
            $sense["sense.admin_assets"]->addScript("contentedit", get_template_directory_uri() . "/js/content_edit.js","1",true, array("jquery", "leaflet"));
            $sense["sense.admin_assets"]->addStyle("leaflet", "http://cdn.leafletjs.com/leaflet-0.7.3/leaflet.css", "1");
        }

        \add_meta_box('ubiqa_content_featured', __( 'Destacar contenido', 'ubiqa' ), array($this, "featureHTML"), null, 'normal', 'high' );
        \add_meta_box('ubiqa_content_type', __( 'Contenido asociado', 'ubiqa' ), array($this, "contentTypeHTML"), 'content', 'normal', 'high' );
    }

    function featureHTML($post){
        include __DIR__ . "/../View/metabox/feature.php";
    }

    function contentTypeHTML($post){

        $container = $this->getContainer();
        $config      = $container["model.admin"] ->getConfigOptions();
        $map_config = array(

            'tile_url' => isset($config["map_tile_url"]) ? $config["map_tile_url"] : 'http://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',
            'attribution'  => isset($config["map_attribution"]) ? $config["map_attribution"] : "Ubiqarama"

        );

        $route_model = new RouteModel();

        $cities = array(0=>"");
        foreach(get_posts(array("post_type"=>"city", "posts_per_page"=>-1)) as $city){
            $cities[$city->ID] = (get_the_title($city). ", ".get_post_meta($city->ID, "ubiqa_content_country", true) );
        }

        include __DIR__ . "/../View/metabox/content_type.php";
    }

    function save($post_id){


            // If this is an autosave, our form has not been submitted, so we don't want to do anything.
        if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
            return;
        }



            foreach(array("content", "slider") as $key){
                if(isset($_POST["ubiqa_feature"][$key])){
                    $this->getModel()->setMeta($post_id, "ubiqa_feature_" . $key, $_POST["ubiqa_feature"][$key]);
                }else{
                    $this->getModel()->setMeta($post_id, "ubiqa_feature_" . $key, 0);
                }
            }


        if(isset($_POST["ubiqa_content"]) && is_array($_POST["ubiqa_content"])){



            foreach($_POST["ubiqa_content"] as $key=>$value){
                if(isset($_POST["ubiqa_content"][$key]) && $_POST["ubiqa_content"][$key]){
                    $this->getModel()->setMeta($post_id, "ubiqa_content_" . $key, $_POST["ubiqa_content"][$key]);
                }else{
                    $this->getModel()->removeMeta($post_id, "ubiqa_content_" . $key, $_POST["ubiqa_content"][$key]);
                }
            }


            if($_POST["ubiqa_content"]["type"] == "video"){
                $this->getModel()->setMeta($post_id, "ubiqa_video_oembed_data", $this->getModel()->getVideoData($this->getModel()->getMeta($post_id, "ubiqa_content_content_url")));

            }


            if(!\get_post_thumbnail_id($post_id)){

                if($_POST["ubiqa_content"]["type"] == "image"){
                    $this->getModel()->setExternalImageToPost($this->getModel()->getMeta($post_id, "ubiqa_content_content_url"), $post_id, \get_the_title($post_id), true);
                }



                if($_POST["ubiqa_content"]["type"] == "video"){


                    $data = $this->getModel()->getMeta($post_id, "ubiqa_video_oembed_data");

                    if(isset($data->thumbnail_url)){
                        $this->getModel()->setExternalImageToPost($data->thumbnail_url, $post_id, \get_the_title($post_id), true);
                    }
                    //;
                }

            }



        }




    }



} 