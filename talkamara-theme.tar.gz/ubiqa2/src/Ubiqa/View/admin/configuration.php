<h2><?php _e("Configuración del proyecto", "ubiqa") ?></h2>

<form action="" method="post">

    <h4><?php _e("Datos generales", "ubiqa") ?></h4>


    <?php foreach(array("tos_page_id") as $key){ ?>
        <p>


            <?php echo $form[$key]->getLabelTag() ?><br>

            <?php echo $form[$key]->getInputTag() ?>
            <?php echo $form[$key]->getErrorTag() ?>
        </p>

    <?php } ?>

    <h4><?php _e("Configuración del mapa", "ubiqa") ?></h4>


    <?php foreach(array("map_tile_url", "map_attribution") as $key){ ?>
    <p>


        <?php echo $form[$key]->getLabelTag() ?><br>

        <?php echo $form[$key]->getInputTag() ?>
        <?php echo $form[$key]->getErrorTag() ?>
    </p>

    <?php } ?>


    <h4 style="margin-top: 50px"><?php _e("Configuración de vimeo", "ubiqa") ?></h4>


    <?php foreach(array("vimeo_api_client_id", "vimeo_api_client_secret", "vimeo_api_access_token") as $key){ ?>
        <p>


            <?php echo $form[$key]->getLabelTag() ?><br>

            <?php echo $form[$key]->getInputTag() ?>
            <?php echo $form[$key]->getErrorTag() ?>
        </p>

    <?php } ?>


    <h4 style="margin-top: 50px"><?php _e("Configuración de facebook", "ubiqa") ?></h4>
    <?php foreach(array("facebook_api_appid", "facebook_api_secret") as $key){ ?>
        <p>


            <?php echo $form[$key]->getLabelTag() ?><br>

            <?php echo $form[$key]->getInputTag() ?>
            <?php echo $form[$key]->getErrorTag() ?>
        </p>

    <?php } ?>


    <h4 style="margin-top: 50px"><?php _e("Configuración de google", "ubiqa") ?></h4>
    <?php foreach(array("google_api_app_name", "google_api_client_id", "google_api_client_secret", "google_api_developer_key") as $key){ ?>
        <p>


            <?php echo $form[$key]->getLabelTag() ?><br>

            <?php echo $form[$key]->getInputTag() ?>
            <?php echo $form[$key]->getErrorTag() ?>
        </p>

    <?php } ?>


    <h4 style="margin-top: 50px"><?php _e("Configuración de twitter", "ubiqa") ?></h4>
    <?php foreach(array("twitter_api_consumer_key", "twitter_api_consumer_secret") as $key){ ?>
        <p>


            <?php echo $form[$key]->getLabelTag() ?><br>

            <?php echo $form[$key]->getInputTag() ?>
            <?php echo $form[$key]->getErrorTag() ?>
        </p>

    <?php } ?>

    <hr>



    <h4 style="margin-top: 50px"><?php _e("Configuración del contenido", "ubiqa") ?></h4>

    <?php foreach(array("has_geo", "has_routes", "has_interview", "has_ubiqa_category") as $key){ ?>
        <p>


            <?php echo $form[$key]->getLabelTag() ?><br>

            <?php echo $form[$key]->getInputTag() ?>
            <?php echo $form[$key]->getErrorTag() ?>
        </p>

    <?php } ?>



    <h4 style="margin-top: 50px"><?php _e("Enlaces sociales", "ubiqa") ?></h4>
    <?php foreach(array("facebook_url", "twitter_url", "instagram_url") as $key){ ?>
        <p>


            <?php echo $form[$key]->getLabelTag() ?><br>

            <?php echo $form[$key]->getInputTag() ?>
            <?php echo $form[$key]->getErrorTag() ?>
        </p>

    <?php } ?>


    <hr>
    <p>

        <button type="submit" class="button button-primary"><?php _e("Guardar cambios", "ubiqa") ?></button>

    </p>


</form>


