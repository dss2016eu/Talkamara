

<div class="col-s-12 col-m-3 hide-s">
    <div class="form-block txt-center hide-s">
        <h2 class="txt-bold no-air-b"><?php _e("tu cuenta", "ubiqa") ?></h2>
    </div>
    <div class="form-block txt-center">
        <a href="<?php echo _u()->genUrl("account") ?>" class="txt-bold <?php echo $active=="data"?"active":"" ?>" data-tab-show="mis-datos"><?php _e("tus datos", "ubiqa") ?></a>
    </div>
    <div class="form-block txt-center">
        <a href="<?php echo _u()->genUrl("password") ?>" class="txt-bold <?php echo $active=="password"?"active":"" ?>" data-tab-show="cambio-pass"><?php _e("cambiar contraseña", "ubiqa") ?></a>
    </div>
    <div class="form-block txt-center">
        <a href="<?php echo _u()->genUrl("user_content") ?>" class="txt-bold  <?php echo $active=="content"?"active":"" ?>" data-tab-show="contents"><?php _e("tu contenido", "ubiqa") ?></a>
    </div>
    <div class="form-block txt-center">
        <a href="<?php echo _u()->genUrl("user_favs") ?>" class="txt-bold  <?php echo $active=="favs"?"active":"" ?>"  data-tab-show="favorites"><?php _e("tus favoritos", "ubiqa") ?></a>
    </div>
    <div class="form-block txt-center">
        <a href="<?php echo wp_logout_url() ?>" class="txt-bold "><?php _e("cerrar sesión", "ubiqa") ?></a>
    </div>
</div>
