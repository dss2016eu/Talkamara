<h2><?php _e("Personalizar diseño", "ubiqa") ?></h2>

<form action="" method="post" id="custom_form">

    <h4><?php _e("Logotipo", "ubiqa") ?></h4>

    <p>
        <?php  echo $form["logo"]->getInputTag()  ?>
        <input class="button" id="_upload_trigger" value="<?php _e("Seleccionar archivo", "ubiqa") ?>" />

        <div style="background: #fff; margin-top: 12px; padding: 20px" id="preview"></div>
    </p>



    <h4 style="margin-top: 30px"><?php _e("Configuración del texto", "ubiqa") ?></h4>


    <?php foreach(array("h1_color", "h2_color", "h4_color", "a_color", "button_color", "button_text_color") as $key){ ?>
        <p>


            <?php echo $form[$key]->getLabelTag() ?><br>

            <?php echo $form[$key]->getInputTag() ?>
            <?php echo $form[$key]->getErrorTag() ?>
        </p>

    <?php } ?>




    <hr>
    <p>

        <button type="submit" class="button button-primary"><?php _e("Guardar cambios", "ubiqa") ?></button> <a href="#" id="reset_form"><?php _e("volver a valores por defecto", "ubiqa") ?></a>

    </p>


</form>

<script type="text/javascript">

    var file_frame;

    jQuery(document).ready(function($){


        $("#reset_form").click(function(e){
            e.preventDefault();

            $("#custom_form input").val("");
        });


        if($("#custom_logo").val()){
            var img = $("<img>").attr("src", $("#custom_logo").val()).css({height: "60px"});
            $("#preview").html(img);
        }


        // ADJUST THIS to match the correct button
        $('#_upload_trigger').click(function(e)
        {



                e.preventDefault();

                // If the media frame already exists, reopen it.
                if ( file_frame ) {
                    file_frame.open();
                    return;
                }

                // Create the media frame.
                file_frame = wp.media.frames.file_frame = wp.media({
                    title: '<?php _e("Seleccionar archivo de logotipo", "ubiqa") ?>',
                    button: {
                        text: '<?php _e("Usar esta image", "ubiqa") ?>'
                    },
                    multiple: false,
                    type : 'image'
                });

                // When an image is selected, run a callback.
                file_frame.on( 'select', function() {
                    // We set multiple to false so only get one image from the uploader
                    attachment = file_frame.state().get('selection').first().toJSON();


                    var img = $("<img>").attr("src", attachment.url).css({height: "60px"});
                    $("#preview").html(img);
                    $("#custom_logo").val(attachment.url);

                    // Do something with attachment.id and/or attachment.url here
                });

                // Finally, open the modal
                file_frame.open();
        });




    });

</script>